"use client";
import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Bot, Mail, ArrowRight, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api/client";

const schema = z.object({ email: z.string().email("Geçerli bir e-posta girin") });

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(schema) });

  const onSubmit = async (data: { email: string }) => {
    setLoading(true);
    try {
      await api.post("/auth/forgot-password", data);
      setSent(true);
    } catch { toast.error("Gönderme başarısız. Tekrar deneyin."); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4">
      <div className="w-full max-w-md animate-slide-up">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center"><Bot size={20} className="text-white"/></div>
            <span className="font-display font-bold text-xl">HmlyTech</span>
          </Link>
          <h1 className="font-display font-bold text-2xl mb-1">Şifremi Unuttum</h1>
          <p className="text-text-secondary text-sm">E-postanıza sıfırlama linki göndereceğiz</p>
        </div>
        <div className="card p-6">
          {sent ? (
            <div className="text-center py-4">
              <CheckCircle size={40} className="text-teal-accent mx-auto mb-4"/>
              <h3 className="font-display font-semibold mb-2">E-posta Gönderildi</h3>
              <p className="text-text-secondary text-sm mb-4">Gelen kutunuzu kontrol edin. Link 1 saat geçerlidir.</p>
              <Link href="/login" className="btn-secondary w-full justify-center">Giriş Sayfasına Dön</Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit as any)} className="space-y-4">
              <div>
                <label className="label">E-posta Adresi</label>
                <div className="relative">
                  <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/>
                  <input {...register("email")} type="email" placeholder="you@example.com" className="input pl-9 w-full"/>
                </div>
                {errors.email && <p className="text-error text-xs mt-1">{errors.email.message as string}</p>}
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
                {loading ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <>Link Gönder <ArrowRight size={15}/></>}
              </button>
            </form>
          )}
        </div>
        <p className="text-center text-text-muted text-sm mt-4">
          <Link href="/login" className="text-accent hover:underline">Giriş sayfasına dön</Link>
        </p>
      </div>
    </div>
  );
}
