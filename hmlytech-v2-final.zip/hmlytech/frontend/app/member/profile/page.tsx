"use client";
import { useState, useEffect } from "react";
import { User, Lock, Key, Save, Eye, EyeOff, Copy, Check, RefreshCw, Shield } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { memberApi } from "@/lib/api/client";
import { toast } from "sonner";

export default function MemberProfilePage() {
  const { user, fetchMe } = useAuthStore();
  const [fullName, setFullName] = useState(user?.full_name || "");
  const [username, setUsername] = useState(user?.username || "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [curPwd, setCurPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [showKey, setShowKey] = useState(false);
  const [copied, setCopied] = useState(false);
  const [regenLoading, setRegenLoading] = useState(false);

  useEffect(() => {
    memberApi.getApiKey().then(r => setApiKey(r.data.api_key)).catch(() => {});
  }, []);

  const saveProfile = async () => {
    setSavingProfile(true);
    try {
      await memberApi.updateProfile({ full_name: fullName, username });
      await fetchMe();
      toast.success("Profil güncellendi");
    } catch (e: any) { toast.error(e?.response?.data?.detail || "Güncelleme başarısız"); }
    finally { setSavingProfile(false); }
  };

  const changePassword = async () => {
    if (newPwd !== confirmPwd) { toast.error("Şifreler eşleşmiyor"); return; }
    if (newPwd.length < 8) { toast.error("Şifre en az 8 karakter olmalı"); return; }
    setSavingPwd(true);
    try {
      await memberApi.changePassword({ current_password: curPwd, new_password: newPwd });
      setCurPwd(""); setNewPwd(""); setConfirmPwd("");
      toast.success("Şifre güncellendi");
    } catch (e: any) { toast.error(e?.response?.data?.detail || "Şifre değiştirme başarısız"); }
    finally { setSavingPwd(false); }
  };

  const regenKey = async () => {
    if (!confirm("API anahtarınızı yenileyin? Eski anahtar hemen devre dışı kalır.")) return;
    setRegenLoading(true);
    try {
      const r = await memberApi.regenApiKey();
      setApiKey(r.data.api_key);
      toast.success("API anahtarı yenilendi");
    } catch { toast.error("Yenileme başarısız"); }
    finally { setRegenLoading(false); }
  };

  const copyKey = () => {
    if (!apiKey) return;
    navigator.clipboard.writeText(apiKey);
    setCopied(true); setTimeout(() => setCopied(false), 2000);
    toast.success("Kopyalandı");
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display font-bold text-2xl mb-1">Profil & Güvenlik</h1>
        <p className="text-text-secondary text-sm">Hesap bilgilerinizi ve güvenlik ayarlarınızı yönetin</p>
      </div>

      {/* Profile info */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <User size={16} className="text-accent"/>
          <h2 className="font-display font-semibold">Profil Bilgileri</h2>
        </div>
        <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent/30 to-teal-accent/20 border border-accent/20 flex items-center justify-center text-2xl font-bold text-accent">
            {user?.full_name?.[0] || user?.username?.[0] || "?"}
          </div>
          <div>
            <p className="font-semibold">{user?.full_name || user?.username}</p>
            <p className="text-text-muted text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className={`badge border text-xs ${(user as any)?.is_verified ? "badge-teal" : "bg-warning/10 text-warning border-warning/20"}`}>
                {(user as any)?.is_verified ? "✓ Doğrulandı" : "Doğrulanmadı"}
              </span>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="label">Ad Soyad</label>
            <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Ada Lovelace" className="input w-full"/>
          </div>
          <div>
            <label className="label">Kullanıcı Adı</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted text-sm">@</span>
              <input value={username} onChange={e => setUsername(e.target.value)} className="input w-full pl-7"/>
            </div>
          </div>
          <button onClick={saveProfile} disabled={savingProfile} className="btn-primary">
            {savingProfile ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <Save size={14}/>}
            Profili Kaydet
          </button>
        </div>
      </div>

      {/* Password */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <Lock size={16} className="text-accent"/>
          <h2 className="font-display font-semibold">Şifre Değiştir</h2>
        </div>
        <div className="space-y-4">
          {[
            { label:"Mevcut Şifre", value:curPwd, set:setCurPwd, auto:"current-password" },
            { label:"Yeni Şifre",   value:newPwd, set:setNewPwd, auto:"new-password"     },
            { label:"Şifre Tekrar", value:confirmPwd, set:setConfirmPwd, auto:"new-password" },
          ].map(({ label, value, set, auto }) => (
            <div key={label}>
              <label className="label">{label}</label>
              <div className="relative">
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/>
                <input type={showPwd ? "text" : "password"} value={value} onChange={e => set(e.target.value)}
                  placeholder="••••••••" className="input pl-9 pr-10 w-full" autoComplete={auto}/>
                {label === "Mevcut Şifre" && (
                  <button type="button" onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors">
                    {showPwd ? <EyeOff size={14}/> : <Eye size={14}/>}
                  </button>
                )}
              </div>
            </div>
          ))}
          <button onClick={changePassword} disabled={savingPwd || !curPwd || !newPwd || !confirmPwd} className="btn-primary">
            {savingPwd ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <Shield size={14}/>}
            Şifreyi Güncelle
          </button>
        </div>
      </div>

      {/* API Key */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-2">
          <Key size={16} className="text-accent"/>
          <h2 className="font-display font-semibold">API Anahtarı</h2>
        </div>
        <p className="text-text-muted text-sm mb-5">Agent'larınızı API üzerinden çağırmak için kullanın. Gizli tutun.</p>
        <div className="bg-bg-secondary border border-border rounded-xl p-4 mb-4">
          <div className="flex items-center gap-2">
            <code className="flex-1 font-mono text-sm text-teal-accent break-all">
              {showKey ? apiKey : (apiKey ? apiKey.slice(0,8)+"•".repeat(24)+apiKey.slice(-4) : "Yükleniyor...")}
            </code>
            <button onClick={() => setShowKey(!showKey)} className="btn-ghost text-xs px-2 py-1 flex-shrink-0">{showKey?"Gizle":"Göster"}</button>
            <button onClick={copyKey} className="btn-ghost text-xs px-2 py-1 flex-shrink-0">
              {copied ? <Check size={13} className="text-teal-accent"/> : <Copy size={13}/>}
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2 p-3 bg-warning/5 border border-warning/20 rounded-lg mb-4">
          <Shield size={14} className="text-warning flex-shrink-0"/>
          <p className="text-warning text-xs">API anahtarınızı asla herkese açık yerlerde paylaşmayın.</p>
        </div>
        <button onClick={regenKey} disabled={regenLoading} className="btn-secondary text-sm">
          {regenLoading ? <span className="w-3.5 h-3.5 border border-accent/40 border-t-accent rounded-full animate-spin"/> : <RefreshCw size={13}/>}
          Yeni Anahtar Oluştur
        </button>
      </div>
    </div>
  );
}
