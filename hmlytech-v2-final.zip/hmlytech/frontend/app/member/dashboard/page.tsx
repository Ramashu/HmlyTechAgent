"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Bot, Zap, Cpu, ArrowRight, Plus, Shield, Crown } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { memberApi } from "@/lib/api/client";
import { formatNumber, formatDate } from "@/lib/utils";

const ROLE_LABELS: Record<string,string> = {super_admin:"Süper Admin",admin:"Admin",plus:"Plus Üye",member:"Üye"};
const PLAN_INFO: Record<string,{color:string;label:string;limit:string}> = {
  free:  { color:"text-text-secondary",  label:"Ücretsiz", limit:"5 agent" },
  plus:  { color:"text-accent",          label:"Plus",     limit:"25 agent" },
  pro:   { color:"text-teal-accent",     label:"Pro",      limit:"Sınırsız" },
};

export default function MemberDashboard() {
  const { user } = useAuthStore();
  const [stats, setStats] = useState<{total_agents:number;total_runs:number;total_tokens_used:number}|null>(null);

  useEffect(() => {
    memberApi.stats().then(r => setStats(r.data)).catch(() => {});
  }, []);

  const role = (user as any)?.role || "member";
  const plan = (user as any)?.plan || "free";
  const planInfo = PLAN_INFO[plan] || PLAN_INFO.free;

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="card border-gradient p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-text-muted text-sm mb-1">Hoşgeldiniz</p>
            <h1 className="font-display font-bold text-2xl">{user?.full_name || user?.username} 👋</h1>
            <div className="flex items-center gap-2 mt-2">
              <span className={`badge border text-xs ${
                role==="super_admin"?"bg-red-900/20 text-red-400 border-red-800/30":
                role==="admin"?"bg-orange-900/20 text-orange-400 border-orange-800/30":
                role==="plus"?"bg-accent/10 text-accent border-accent/20":
                "bg-bg-hover text-text-secondary border-border"
              }`}>{ROLE_LABELS[role]||role}</span>
              <span className={`badge border text-xs ${planInfo.color} bg-bg-hover border-border`}>
                {plan === "pro" ? <Crown size={9} className="mr-0.5"/> : null}
                {planInfo.label} Plan — {planInfo.limit}
              </span>
            </div>
          </div>
          {["super_admin","admin"].includes(role) && (
            <Link href="/admin/dashboard" className="btn-secondary text-sm border-red-800/30 text-red-400 hover:text-red-300">
              <Shield size={14}/>Admin Paneli
            </Link>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label:"Toplam Agent",    value:stats?.total_agents??0,      icon:Bot,  color:"accent" },
          { label:"Toplam Çalışma",  value:stats?.total_runs??0,        icon:Zap,  color:"teal"   },
          { label:"Kullanılan Token",value:stats?.total_tokens_used??0, icon:Cpu,  color:"accent" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-5">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color==="teal"?"bg-teal-accent/15":"bg-accent/15"}`}>
              <Icon size={18} className={color==="teal"?"text-teal-accent":"text-accent"}/>
            </div>
            <p className="font-display font-bold text-2xl">{formatNumber(value)}</p>
            <p className="text-text-muted text-xs mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Account info */}
      <div className="card p-6">
        <h2 className="font-display font-semibold mb-4">Hesap Bilgileri</h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          {[
            { label:"E-posta",       value:user?.email||"—"              },
            { label:"Kullanıcı Adı", value:`@${user?.username||"—"}`     },
            { label:"Plan",          value:planInfo.label                },
            { label:"Üyelik Tarihi", value:user?.created_at?formatDate(user.created_at):"—" },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-text-muted text-xs mb-0.5">{label}</p>
              <p className="font-medium">{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-2 gap-3">
        <Link href="/dashboard/agents/new" className="card-hover p-4 flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center"><Plus size={16} className="text-accent"/></div>
          <div><p className="text-sm font-medium group-hover:text-accent transition-colors">Yeni Agent Oluştur</p><p className="text-text-muted text-xs">Model, prompt ve araçları yapılandır</p></div>
          <ArrowRight size={14} className="text-text-muted ml-auto group-hover:text-accent group-hover:translate-x-0.5 transition-all"/>
        </Link>
        <Link href="/member/profile" className="card-hover p-4 flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-lg bg-teal-accent/15 flex items-center justify-center"><Zap size={16} className="text-teal-accent"/></div>
          <div><p className="text-sm font-medium group-hover:text-teal-accent transition-colors">Profil & Güvenlik</p><p className="text-text-muted text-xs">Şifre, kullanıcı adı, API anahtarı</p></div>
          <ArrowRight size={14} className="text-text-muted ml-auto group-hover:text-teal-accent group-hover:translate-x-0.5 transition-all"/>
        </Link>
      </div>
    </div>
  );
}
