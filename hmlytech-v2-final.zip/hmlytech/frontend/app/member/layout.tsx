"use client";
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuthStore } from "@/lib/store/auth";
import Cookies from "js-cookie";
import { LayoutDashboard, User, Settings, Bot, Shield, LogOut, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/member/dashboard", icon: LayoutDashboard, label: "Genel Bakış" },
  { href: "/member/profile",   icon: User,            label: "Profil & Güvenlik" },
  { href: "/dashboard",        icon: Bot,             label: "Agent Paneli" },
];

const ROLE_LABEL: Record<string, string> = {
  super_admin: "Süper Admin", admin: "Admin", plus: "Plus Üye", member: "Üye",
};
const ROLE_COLOR: Record<string, string> = {
  super_admin: "text-red-400", admin: "text-orange-400", plus: "text-accent", member: "text-text-secondary",
};

export default function MemberLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, fetchMe, logout, isLoading } = useAuthStore();

  useEffect(() => {
    const token = Cookies.get("access_token");
    if (!token) { router.replace("/login"); return; }
    if (!user) fetchMe();
  }, []);

  if (isLoading || !user) return (
    <div className="min-h-screen bg-bg flex items-center justify-center">
      <div className="flex gap-1">{[0,1,2].map(i=><div key={i} className="w-2 h-2 rounded-full bg-accent animate-bounce" style={{animationDelay:`${i*0.15}s`}}/>)}</div>
    </div>
  );

  const role = (user as any).role || "member";

  return (
    <div className="min-h-screen bg-bg flex">
      <aside className="fixed left-0 top-0 h-screen w-64 bg-bg-secondary border-r border-border flex flex-col z-40">
        <div className="h-16 flex items-center gap-2.5 px-5 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center flex-shrink-0">
            <User size={16} className="text-white"/>
          </div>
          <div><span className="font-display font-bold text-sm block leading-none">Üye Paneli</span><span className="text-text-muted text-xs">HmlyTech Agent</span></div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV.map(({ href, icon: Icon, label }) => {
            const active = pathname.startsWith(href) && href !== "/dashboard";
            return (
              <Link key={href} href={href} className={cn(active ? "sidebar-item-active" : "sidebar-item")}>
                <Icon size={17}/><span className="flex-1">{label}</span>
                {active && <ChevronRight size={13} className="opacity-50"/>}
              </Link>
            );
          })}
          {["super_admin","admin"].includes(role) && (
            <>
              <div className="my-2 h-px bg-border"/>
              <Link href="/admin/dashboard" className="sidebar-item text-xs text-red-400 hover:text-red-300">
                <Shield size={15}/>Admin Paneli
              </Link>
            </>
          )}
        </nav>

        <div className="px-4 py-3 border-t border-border">
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg group">
            <div className="w-8 h-8 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center text-accent font-bold text-sm">
              {user.full_name?.[0] || user.username?.[0] || "?"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-text-primary text-xs font-medium truncate">{user.full_name || user.username}</p>
              <p className={cn("text-xs capitalize", ROLE_COLOR[role])}>{ROLE_LABEL[role] || role}</p>
            </div>
            <button onClick={logout} className="opacity-0 group-hover:opacity-100 transition-opacity text-text-muted hover:text-error">
              <LogOut size={14}/>
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 ml-64 min-h-screen overflow-auto">
        <div className="max-w-4xl mx-auto p-6 lg:p-8 animate-fade-in">{children}</div>
      </main>
    </div>
  );
}
