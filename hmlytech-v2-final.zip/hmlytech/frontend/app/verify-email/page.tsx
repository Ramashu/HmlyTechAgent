"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { CheckCircle, XCircle, Loader2, Bot } from "lucide-react";
import { api } from "@/lib/api/client";

export default function VerifyEmailPage() {
  const params = useSearchParams();
  const token = params.get("token");
  const [status, setStatus] = useState<"loading"|"success"|"error">("loading");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!token) { setStatus("error"); setMessage("Doğrulama tokeni bulunamadı."); return; }
    api.get(`/auth/verify-email?token=${token}`)
      .then(() => setStatus("success"))
      .catch(e => { setStatus("error"); setMessage(e?.response?.data?.detail || "Doğrulama başarısız."); });
  }, [token]);

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4">
      <div className="text-center max-w-sm animate-fade-in">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center mx-auto mb-6">
          <Bot size={28} className="text-white"/>
        </div>
        {status === "loading" && <>
          <Loader2 size={32} className="text-accent animate-spin mx-auto mb-4"/>
          <h2 className="font-display font-bold text-xl mb-2">Doğrulanıyor…</h2>
          <p className="text-text-secondary text-sm">E-posta adresiniz doğrulanıyor, lütfen bekleyin.</p>
        </>}
        {status === "success" && <>
          <CheckCircle size={40} className="text-teal-accent mx-auto mb-4"/>
          <h2 className="font-display font-bold text-xl mb-2">E-posta Doğrulandı! 🎉</h2>
          <p className="text-text-secondary text-sm mb-6">Hesabınız aktif edildi. Artık giriş yapabilirsiniz.</p>
          <Link href="/login" className="btn-primary inline-flex">Giriş Yap</Link>
        </>}
        {status === "error" && <>
          <XCircle size={40} className="text-error mx-auto mb-4"/>
          <h2 className="font-display font-bold text-xl mb-2">Doğrulama Başarısız</h2>
          <p className="text-text-secondary text-sm mb-6">{message || "Link geçersiz veya süresi dolmuş."}</p>
          <Link href="/register" className="btn-secondary inline-flex">Yeniden Kayıt Ol</Link>
        </>}
      </div>
    </div>
  );
}
