"use client";
import { useEffect, useState } from "react";
import { Search, Bot, Trash2, Eye } from "lucide-react";
import { adminApi } from "@/lib/api/client";
import { formatRelativeTime, MODEL_LABELS } from "@/lib/utils";
import { toast } from "sonner";
import { useAuthStore } from "@/lib/store/auth";

interface AdminAgent { id: number; name: string; owner_id: number; model: string; total_runs: number; is_public: boolean; is_active: boolean; created_at: string; }

export default function AdminAgentsPage() {
  const { user: me } = useAuthStore();
  const [agents, setAgents] = useState<AdminAgent[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const isSA = (me as any)?.role === "super_admin";

  const load = async () => {
    setLoading(true);
    try {
      const r = await adminApi.listAgents({ search: search || undefined });
      setAgents(r.data);
    } catch { toast.error("Yüklenemedi"); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [search]);

  const deactivate = async (id: number, name: string) => {
    if (!confirm(`"${name}" agentını devre dışı bırak?`)) return;
    try { await adminApi.deleteAgent(id); toast.success("Agent devre dışı bırakıldı"); load(); }
    catch (e: any) { toast.error(e?.response?.data?.detail || "Hata"); }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl mb-1">Agent Yönetimi</h1>
        <p className="text-text-secondary text-sm">{agents.length} agent listeleniyor</p>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Agent ara..." className="input pl-9 w-full"/>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border bg-bg-secondary">{["Agent","Model","Sahip ID","Çalışma","Durum","Oluşturulma","İşlem"].map(h=><th key={h} className="text-left px-4 py-3 text-text-muted text-xs font-medium">{h}</th>)}</tr></thead>
          <tbody>
            {loading ? [...Array(5)].map((_,i)=>(
              <tr key={i} className="border-b border-border/50 animate-pulse">
                {[...Array(7)].map((_,j)=><td key={j} className="px-4 py-3"><div className="h-4 bg-bg-hover rounded w-20"/></td>)}
              </tr>
            )) : agents.map(a=>(
              <tr key={a.id} className="border-b border-border/50 hover:bg-bg-hover/40 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-accent/15 flex items-center justify-center"><Bot size={13} className="text-accent"/></div>
                    <div><p className="font-medium text-xs">{a.name}</p><p className="text-text-muted text-xs">#{a.id}</p></div>
                  </div>
                </td>
                <td className="px-4 py-3 text-text-secondary text-xs">{MODEL_LABELS[a.model]||a.model}</td>
                <td className="px-4 py-3 text-text-muted text-xs">#{a.owner_id}</td>
                <td className="px-4 py-3 text-text-secondary text-xs">{a.total_runs}</td>
                <td className="px-4 py-3">
                  <span className={`badge border text-xs ${a.is_active?"bg-teal-accent/10 text-teal-accent border-teal-accent/20":"bg-error/10 text-error border-error/20"}`}>
                    {a.is_active?"Aktif":"Pasif"}
                  </span>
                </td>
                <td className="px-4 py-3 text-text-muted text-xs">{formatRelativeTime(a.created_at)}</td>
                <td className="px-4 py-3">
                  {isSA && a.is_active && (
                    <button onClick={()=>deactivate(a.id,a.name)} className="btn-ghost p-1.5 hover:text-error" title="Devre dışı bırak">
                      <Trash2 size={13}/>
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && agents.length === 0 && (
          <div className="p-12 text-center">
            <Bot size={28} className="text-text-muted mx-auto mb-3"/>
            <p className="text-text-secondary text-sm">Henüz agent yok</p>
          </div>
        )}
      </div>
    </div>
  );
}
