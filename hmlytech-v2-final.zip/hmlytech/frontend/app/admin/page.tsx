"use client";
import { useEffect, useState } from "react";
import { Users, Bot, Zap, Cpu, TrendingUp, Shield, Crown, Star, User } from "lucide-react";
import { api } from "@/lib/api/client";
import { formatNumber } from "@/lib/utils";
import { useAuthStore } from "@/lib/store/auth";

interface Stats {
  total_users: number;
  active_users: number;
  verified_users: number;
  total_agents: number;
  total_executions: number;
  total_tokens_used: number;
  users_by_role: Record<string, number>;
}

const ROLE_CONFIG = {
  super_admin: { label: "Süper Admin", icon: Crown, color: "text-yellow-400", bg: "bg-yellow-500/15 border-yellow-500/20" },
  admin: { label: "Admin", icon: Shield, color: "text-orange-400", bg: "bg-orange-500/15 border-orange-500/20" },
  plus: { label: "Plus Üye", icon: Star, color: "text-accent", bg: "bg-accent/15 border-accent/20" },
  member: { label: "Üye", icon: User, color: "text-teal-accent", bg: "bg-teal-accent/15 border-teal-accent/20" },
};

export default function AdminDashboard() {
  const { user } = useAuthStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get("/admin/stats").then(r => setStats(r.data)).finally(() => setLoading(false));
  }, []);

  const statCards = [
    { label: "Toplam Kullanıcı", value: stats?.total_users ?? 0, icon: Users, color: "accent" as const },
    { label: "Aktif Kullanıcı", value: stats?.active_users ?? 0, icon: TrendingUp, color: "teal" as const },
    { label: "Toplam Agent", value: stats?.total_agents ?? 0, icon: Bot, color: "accent" as const },
    { label: "Toplam Çalışma", value: stats?.total_executions ?? 0, icon: Zap, color: "teal" as const },
    { label: "Toplam Token", value: stats?.total_tokens_used ?? 0, icon: Cpu, color: "accent" as const },
    { label: "Onaylı Kullanıcı", value: stats?.verified_users ?? 0, icon: Shield, color: "teal" as const },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <h1 className="font-display font-bold text-2xl">Admin Dashboard</h1>
          {user?.role === "super_admin" && (
            <span className="badge bg-yellow-500/15 text-yellow-400 border border-yellow-500/20">Süper Admin</span>
          )}
        </div>
        <p className="text-text-secondary text-sm">Platform genelinde istatistikler ve yönetim araçları</p>
      </div>

      {/* Stat grid */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3,4,5,6].map(i => <div key={i} className="card p-5 animate-pulse h-28 bg-bg-card" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {statCards.map(s => (
            <div key={s.label} className="card p-5">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${s.color === "accent" ? "bg-accent/15" : "bg-teal-accent/15"}`}>
                  <s.icon size={18} className={s.color === "accent" ? "text-accent" : "text-teal-accent"} />
                </div>
              </div>
              <p className="font-display font-bold text-2xl mb-0.5">{formatNumber(s.value)}</p>
              <p className="text-text-muted text-xs">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Role distribution */}
      {stats && (
        <div>
          <h2 className="font-display font-semibold text-base mb-4">Rol Dağılımı</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {Object.entries(ROLE_CONFIG).map(([role, cfg]) => (
              <div key={role} className={`card p-4 border ${cfg.bg}`}>
                <div className="flex items-center gap-2 mb-2">
                  <cfg.icon size={16} className={cfg.color} />
                  <span className={`text-sm font-medium ${cfg.color}`}>{cfg.label}</span>
                </div>
                <p className="font-display font-bold text-3xl">{stats.users_by_role[role] ?? 0}</p>
                <p className="text-text-muted text-xs mt-1">kullanıcı</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div>
        <h2 className="font-display font-semibold text-base mb-4">Hızlı Erişim</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { href: "/admin/users", label: "Kullanıcıları Yönet", icon: Users, desc: "Rol, izin, aktiflik" },
            { href: "/admin/agents", label: "Agentları İncele", icon: Bot, desc: "Tüm platform agentları" },
            { href: "/admin/settings", label: "Site İçeriği Düzenle", icon: Shield, desc: "Sayfa metinleri ve ayarlar" },
          ].map(l => (
            <a key={l.href} href={l.href} className="card-hover p-4 flex items-center gap-3 group">
              <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center flex-shrink-0">
                <l.icon size={16} className="text-accent" />
              </div>
              <div>
                <p className="text-sm font-medium group-hover:text-accent transition-colors">{l.label}</p>
                <p className="text-text-muted text-xs">{l.desc}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
