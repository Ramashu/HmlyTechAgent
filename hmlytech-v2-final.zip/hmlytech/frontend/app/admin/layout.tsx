"use client";
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuthStore } from "@/lib/store/auth";
import Cookies from "js-cookie";
import { LayoutDashboard, Users, Bot, Settings, Shield, LogOut, ChevronRight, Activity } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/admin/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/admin/users",     icon: Users,           label: "Kullanıcılar" },
  { href: "/admin/agents",    icon: Bot,             label: "Agentlar" },
  { href: "/admin/settings",  icon: Settings,        label: "Site Ayarları" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, fetchMe, logout, isLoading } = useAuthStore();

  useEffect(() => {
    const token = Cookies.get("access_token");
    if (!token) { router.replace("/login"); return; }
    if (!user) fetchMe();
  }, []);

  useEffect(() => {
    if (!isLoading && user && !["super_admin","admin"].includes((user as any).role ?? "")) {
      router.replace("/dashboard");
    }
  }, [user, isLoading]);

  if (isLoading || !user) return (
    <div className="min-h-screen bg-bg flex items-center justify-center">
      <div className="flex gap-1">{[0,1,2].map(i=><div key={i} className="w-2 h-2 rounded-full bg-accent animate-bounce" style={{animationDelay:`${i*0.15}s`}}/>)}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-bg flex">
      <aside className="fixed left-0 top-0 h-screen w-64 bg-bg-secondary border-r border-border flex flex-col z-40">
        <div className="h-16 flex items-center gap-2.5 px-5 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-red-600 to-accent flex items-center justify-center"><Shield size={16} className="text-white"/></div>
          <div><span className="font-display font-bold text-sm block leading-none">Admin Panel</span><span className="text-text-muted text-xs">HmlyTech Agent</span></div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV.map(({href,icon:Icon,label})=>{
            const active=pathname.startsWith(href);
            return(<Link key={href} href={href} className={cn(active?"sidebar-item-active":"sidebar-item")}><Icon size={17}/><span className="flex-1">{label}</span>{active&&<ChevronRight size={13} className="opacity-50"/>}</Link>);
          })}
          <div className="my-3 h-px bg-border"/>
          <Link href="/dashboard" className="sidebar-item text-xs"><Activity size={15}/>Üye Paneline Dön</Link>
        </nav>
        <div className="px-4 py-3 border-t border-border">
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg group">
            <div className="w-8 h-8 rounded-full bg-red-900/30 border border-red-700/30 flex items-center justify-center text-red-400 font-bold text-sm">{user.full_name?.[0]||user.username?.[0]||"A"}</div>
            <div className="flex-1 min-w-0"><p className="text-xs font-medium truncate">{user.full_name||user.username}</p><p className="text-red-400 text-xs capitalize">{((user as any).role||"").replace("_"," ")}</p></div>
            <button onClick={logout} className="opacity-0 group-hover:opacity-100 transition-opacity text-text-muted hover:text-error"><LogOut size={14}/></button>
          </div>
        </div>
      </aside>
      <main className="flex-1 ml-64 min-h-screen overflow-auto">
        <div className="max-w-7xl mx-auto p-6 lg:p-8 animate-fade-in">{children}</div>
      </main>
    </div>
  );
}
