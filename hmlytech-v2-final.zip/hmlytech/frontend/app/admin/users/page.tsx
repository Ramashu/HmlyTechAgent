"use client";
import { useEffect, useState, useCallback } from "react";
import { Search, Shield, Trash2, RefreshCw, ChevronLeft, ChevronRight as CR } from "lucide-react";
import { adminApi, AdminUser } from "@/lib/api/client";
import { formatRelativeTime, cn } from "@/lib/utils";
import { toast } from "sonner";
import { useAuthStore } from "@/lib/store/auth";

const ROLES = ["super_admin","admin","plus","member"];
const RL: Record<string,string> = {super_admin:"Süper Admin",admin:"Admin",plus:"Plus",member:"Üye"};
const RC: Record<string,string> = {
  super_admin:"bg-red-900/20 text-red-400 border-red-800/30",
  admin:"bg-orange-900/20 text-orange-400 border-orange-800/30",
  plus:"bg-accent/10 text-accent border-accent/20",
  member:"bg-bg-hover text-text-secondary border-border",
};
const SC: Record<string,string> = {
  active:"bg-teal-accent/10 text-teal-accent border-teal-accent/20",
  pending:"bg-warning/10 text-warning border-warning/20",
  suspended:"bg-error/10 text-error border-error/20",
  banned:"bg-red-900/20 text-red-400 border-red-700/30",
};
const LIMIT=20;

export default function AdminUsersPage() {
  const { user: me } = useAuthStore();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleF, setRoleF] = useState("");
  const [statusF, setStatusF] = useState("");
  const [page, setPage] = useState(0);
  const [sel, setSel] = useState<AdminUser|null>(null);
  const [saving, setSaving] = useState(false);
  const [nRole, setNRole] = useState("");
  const [nStatus, setNStatus] = useState("");
  const [nPlan, setNPlan] = useState("");
  const [nPwd, setNPwd] = useState("");

  const load = useCallback(async()=>{
    setLoading(true);
    try{
      const r=await adminApi.users({skip:page*LIMIT,limit:LIMIT,role:roleF||undefined,status:statusF||undefined,search:search||undefined});
      setUsers(r.data.users); setTotal(r.data.total);
    }catch{toast.error("Yüklenemedi");}finally{setLoading(false);}
  },[page,roleF,statusF,search]);

  useEffect(()=>{load();},[load]);

  const openEdit=(u:AdminUser)=>{setSel(u);setNRole(u.role);setNStatus(u.status);setNPlan(u.plan);setNPwd("");};

  const save=async()=>{
    if(!sel)return; setSaving(true);
    try{
      if(nRole!==sel.role){await adminApi.updateRole(sel.id,nRole);toast.success("Rol güncellendi");}
      if(nStatus!==sel.status){await adminApi.updateStatus(sel.id,nStatus);toast.success("Durum güncellendi");}
      if(nPlan!==sel.plan){await adminApi.updatePlan(sel.id,nPlan);toast.success("Plan güncellendi");}
      if(nPwd.length>=8){await adminApi.resetPassword(sel.id,nPwd);toast.success("Şifre sıfırlandı");}
      setSel(null); load();
    }catch(e:any){toast.error(e?.response?.data?.detail||"Hata");}finally{setSaving(false);}
  };

  const del=async(u:AdminUser)=>{
    if(!confirm(`"${u.username}" silinsin?`))return;
    try{await adminApi.deleteUser(u.id);toast.success("Silindi");load();}
    catch(e:any){toast.error(e?.response?.data?.detail||"Silinemedi");}
  };

  const isSA=(me as any)?.role==="super_admin";

  return(
    <div className="space-y-6">
      <div><h1 className="font-display font-bold text-2xl mb-1">Kullanıcı Yönetimi</h1><p className="text-text-secondary text-sm">{total} kullanıcı</p></div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/><input value={search} onChange={e=>{setSearch(e.target.value);setPage(0);}} placeholder="İsim, email..." className="input pl-9 w-full"/></div>
        <select value={roleF} onChange={e=>{setRoleF(e.target.value);setPage(0);}} className="input w-36"><option value="">Tüm Roller</option>{ROLES.map(r=><option key={r} value={r}>{RL[r]}</option>)}</select>
        <select value={statusF} onChange={e=>{setStatusF(e.target.value);setPage(0);}} className="input w-36"><option value="">Tüm Durumlar</option>{["active","pending","suspended","banned"].map(s=><option key={s} value={s}>{s}</option>)}</select>
        <button onClick={load} className="btn-secondary px-3"><RefreshCw size={14}/></button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-bg-secondary">{["Kullanıcı","Rol","Durum","Plan","Giriş","Kayıt","İşlem"].map(h=><th key={h} className="text-left px-4 py-3 text-text-muted text-xs font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {loading?[...Array(5)].map((_,i)=><tr key={i} className="border-b border-border/50 animate-pulse">{[...Array(7)].map((_,j)=><td key={j} className="px-4 py-3"><div className="h-4 bg-bg-hover rounded w-20"/></td>)}</tr>)
              :users.map(u=>(
                <tr key={u.id} className="border-b border-border/50 hover:bg-bg-hover/40 transition-colors">
                  <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-7 h-7 rounded-full bg-accent/20 flex items-center justify-center text-accent text-xs font-bold flex-shrink-0">{u.full_name?.[0]||u.username[0]}</div><div><p className="font-medium text-xs">{u.full_name||u.username}</p><p className="text-text-muted text-xs">{u.email}</p></div></div></td>
                  <td className="px-4 py-3"><span className={cn("badge border text-xs",RC[u.role]||"badge-gray")}>{RL[u.role]||u.role}</span></td>
                  <td className="px-4 py-3"><span className={cn("badge border text-xs",SC[u.status]||"badge-gray")}>{u.status}</span></td>
                  <td className="px-4 py-3 text-text-secondary text-xs capitalize">{u.plan}</td>
                  <td className="px-4 py-3 text-text-muted text-xs">{u.login_count}×</td>
                  <td className="px-4 py-3 text-text-muted text-xs">{formatRelativeTime(u.created_at)}</td>
                  <td className="px-4 py-3"><div className="flex gap-1"><button onClick={()=>openEdit(u)} className="btn-ghost p-1.5" title="Düzenle"><Shield size={13}/></button>{isSA&&u.role!=="super_admin"&&<button onClick={()=>del(u)} className="btn-ghost p-1.5 hover:text-error" title="Sil"><Trash2 size={13}/></button>}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-border">
          <p className="text-text-muted text-xs">{page*LIMIT+1}–{Math.min((page+1)*LIMIT,total)} / {total}</p>
          <div className="flex gap-2">
            <button disabled={page===0} onClick={()=>setPage(p=>p-1)} className="btn-secondary text-xs py-1 px-3 disabled:opacity-40"><ChevronLeft size={13}/></button>
            <button disabled={(page+1)*LIMIT>=total} onClick={()=>setPage(p=>p+1)} className="btn-secondary text-xs py-1 px-3 disabled:opacity-40"><CR size={13}/></button>
          </div>
        </div>
      </div>

      {sel&&(
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={()=>setSel(null)}/>
          <div className="relative card p-6 w-full max-w-md animate-slide-up">
            <h3 className="font-display font-semibold mb-1">{sel.full_name||sel.username}</h3>
            <p className="text-text-muted text-xs mb-5">{sel.email}</p>
            <div className="space-y-4">
              <div><label className="label">Rol</label>
                <select value={nRole} onChange={e=>setNRole(e.target.value)} className="input w-full" disabled={sel.role==="super_admin"&&!isSA}>
                  {ROLES.filter(r=>isSA||r!=="super_admin").map(r=><option key={r} value={r}>{RL[r]}</option>)}
                </select></div>
              <div><label className="label">Durum</label>
                <select value={nStatus} onChange={e=>setNStatus(e.target.value)} className="input w-full" disabled={sel.role==="super_admin"}>
                  {["active","pending","suspended","banned"].map(s=><option key={s} value={s}>{s}</option>)}
                </select></div>
              <div><label className="label">Plan</label>
                <select value={nPlan} onChange={e=>setNPlan(e.target.value)} className="input w-full">
                  {["free","plus","pro"].map(p=><option key={p} value={p}>{p}</option>)}
                </select></div>
              {isSA&&<div><label className="label">Yeni Şifre <span className="text-text-muted">(boş = değişmez)</span></label><input value={nPwd} onChange={e=>setNPwd(e.target.value)} type="password" placeholder="••••••••" className="input w-full"/></div>}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={()=>setSel(null)} className="btn-secondary flex-1">İptal</button>
              <button onClick={save} disabled={saving} className="btn-primary flex-1 justify-center">
                {saving?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:"Kaydet"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
