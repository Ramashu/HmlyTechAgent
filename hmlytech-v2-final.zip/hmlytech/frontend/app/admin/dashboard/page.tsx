"use client";
import { useEffect, useState } from "react";
import { Users, Bot, Zap, Cpu, Shield, Clock, TrendingUp, UserCheck, UserX } from "lucide-react";
import { adminApi } from "@/lib/api/client";
import { formatNumber } from "@/lib/utils";

interface Stats {
  total_users: number; active_users: number; pending_users: number;
  total_agents: number; total_executions: number; total_tokens: number;
  role_counts: Record<string, number>;
}

const ROLE_LABELS: Record<string, string> = {
  super_admin: "Süper Admin", admin: "Admin", plus: "Plus Üye", member: "Üye",
};
const ROLE_COLORS: Record<string, string> = {
  super_admin: "text-red-400 bg-red-900/20 border-red-800/40",
  admin: "text-orange-400 bg-orange-900/20 border-orange-800/40",
  plus: "text-accent bg-accent/10 border-accent/20",
  member: "text-text-secondary bg-bg-hover border-border",
};

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminApi.stats().then(r => setStats(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-bg-card rounded-lg" />
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {[1,2,3,4,5,6].map(i => <div key={i} className="card p-5 h-28" />)}
      </div>
    </div>
  );

  const cards = [
    { label: "Toplam Kullanıcı",   value: stats?.total_users ?? 0,      icon: Users,     color: "accent" },
    { label: "Aktif Kullanıcı",    value: stats?.active_users ?? 0,     icon: UserCheck, color: "teal" },
    { label: "Bekleyen Doğrulama", value: stats?.pending_users ?? 0,    icon: Clock,     color: "warning" },
    { label: "Toplam Agent",       value: stats?.total_agents ?? 0,     icon: Bot,       color: "accent" },
    { label: "Toplam Çalıştırma",  value: stats?.total_executions ?? 0, icon: Zap,       color: "teal" },
    { label: "Toplam Token",       value: stats?.total_tokens ?? 0,     icon: Cpu,       color: "accent" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display font-bold text-2xl mb-1">Admin Dashboard</h1>
        <p className="text-text-secondary text-sm">Platform geneli istatistikler ve yönetim</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-5">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${
              color === "teal" ? "bg-teal-accent/15" : color === "warning" ? "bg-warning/15" : "bg-accent/15"
            }`}>
              <Icon size={18} className={
                color === "teal" ? "text-teal-accent" : color === "warning" ? "text-warning" : "text-accent"
              } />
            </div>
            <p className="font-display font-bold text-2xl">{formatNumber(value)}</p>
            <p className="text-text-muted text-xs mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Role breakdown */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-5">
          <Shield size={16} className="text-accent" />
          <h2 className="font-display font-semibold">Rol Dağılımı</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Object.entries(stats?.role_counts ?? {}).map(([role, count]) => (
            <div key={role} className={`p-4 rounded-xl border text-center ${ROLE_COLORS[role] || "badge-gray"}`}>
              <p className="font-display font-bold text-xl">{count}</p>
              <p className="text-xs mt-0.5 capitalize">{ROLE_LABELS[role] || role}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { href: "/admin/users",    label: "Kullanıcıları Yönet",  sub: "Rol, plan, durum",       icon: Users },
          { href: "/admin/agents",   label: "Agentları İncele",     sub: "Tüm platformdaki agentlar", icon: Bot },
          { href: "/admin/settings", label: "Site İçeriğini Düzenle", sub: "Başlık, metin, ayarlar", icon: TrendingUp },
        ].map(({ href, label, sub, icon: Icon }) => (
          <a key={href} href={href} className="card-hover p-4 flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center">
              <Icon size={16} className="text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium group-hover:text-accent transition-colors">{label}</p>
              <p className="text-text-muted text-xs">{sub}</p>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
