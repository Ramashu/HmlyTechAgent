"use client";
import { useEffect, useState } from "react";
import { Save, RefreshCw, Eye, Settings, Mail, Globe, Sliders } from "lucide-react";
import { adminApi, SiteSetting } from "@/lib/api/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const GROUP_LABELS: Record<string, { label: string; icon: React.ElementType }> = {
  general: { label: "Genel Ayarlar",    icon: Settings },
  landing: { label: "Landing Sayfası",  icon: Globe    },
  email:   { label: "E-posta Ayarları", icon: Mail     },
  limits:  { label: "Limitler & Kısıtlamalar", icon: Sliders },
};

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<SiteSetting[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeGroup, setActiveGroup] = useState("general");
  const [changed, setChanged] = useState<Set<string>>(new Set());

  useEffect(() => {
    adminApi.getSettings().then(r => {
      setSettings(r.data);
      const v: Record<string, string> = {};
      r.data.forEach((s: SiteSetting) => { v[s.key] = s.value ?? ""; });
      setValues(v);
    }).finally(() => setLoading(false));
  }, []);

  const handleChange = (key: string, val: string) => {
    setValues(prev => ({ ...prev, [key]: val }));
    setChanged(prev => new Set(prev).add(key));
  };

  const saveGroup = async () => {
    setSaving(true);
    try {
      const groupKeys = settings.filter(s => s.group === activeGroup).map(s => s.key);
      const updates: Record<string, string> = {};
      groupKeys.forEach(k => { updates[k] = values[k] ?? ""; });
      await adminApi.updateSettings(updates);
      setChanged(prev => { const n = new Set(prev); groupKeys.forEach(k => n.delete(k)); return n; });
      toast.success(`${GROUP_LABELS[activeGroup]?.label || activeGroup} ayarları kaydedildi`);
    } catch { toast.error("Kaydetme başarısız"); }
    finally { setSaving(false); }
  };

  const saveAll = async () => {
    setSaving(true);
    try {
      await adminApi.updateSettings(values);
      setChanged(new Set());
      toast.success("Tüm ayarlar kaydedildi");
    } catch { toast.error("Kaydetme başarısız"); }
    finally { setSaving(false); }
  };

  const groups = [...new Set(settings.map(s => s.group))];
  const groupSettings = settings.filter(s => s.group === activeGroup);
  const groupChangedCount = settings.filter(s => s.group === activeGroup && changed.has(s.key)).length;

  const renderInput = (s: SiteSetting) => {
    const val = values[s.key] ?? "";
    const isChanged = changed.has(s.key);

    switch (s.input_type) {
      case "textarea":
        return (
          <textarea rows={3} value={val}
            onChange={e => handleChange(s.key, e.target.value)}
            className={cn("input resize-y w-full", isChanged && "border-accent")} />
        );
      case "bool":
        return (
          <div className="flex items-center gap-3">
            <button type="button"
              onClick={() => handleChange(s.key, val === "true" ? "false" : "true")}
              className={cn("w-10 h-5 rounded-full transition-colors relative flex-shrink-0",
                val === "true" ? "bg-accent" : "bg-bg-hover border border-border")}>
              <span className={cn("absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow-sm",
                val === "true" ? "translate-x-5" : "translate-x-0.5")} />
            </button>
            <span className={cn("text-sm", val === "true" ? "text-teal-accent" : "text-text-muted")}>
              {val === "true" ? "Aktif" : "Pasif"}
            </span>
          </div>
        );
      case "number":
        return (
          <input type="number" value={val}
            onChange={e => handleChange(s.key, e.target.value)}
            className={cn("input w-32", isChanged && "border-accent")} />
        );
      case "color":
        return (
          <div className="flex items-center gap-3">
            <input type="color" value={val || "#6c63ff"}
              onChange={e => handleChange(s.key, e.target.value)}
              className="w-10 h-10 rounded-lg border border-border bg-bg-secondary cursor-pointer" />
            <input value={val} onChange={e => handleChange(s.key, e.target.value)}
              className={cn("input w-32 font-mono text-sm", isChanged && "border-accent")} />
          </div>
        );
      default:
        return (
          <input type="text" value={val}
            onChange={e => handleChange(s.key, e.target.value)}
            className={cn("input w-full", isChanged && "border-accent")} />
        );
    }
  };

  if (loading) return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-bg-card rounded-lg"/>
      <div className="grid grid-cols-4 gap-2">{[1,2,3,4].map(i=><div key={i} className="h-10 bg-bg-card rounded-lg"/>)}</div>
      <div className="card p-6 space-y-4">{[1,2,3,4].map(i=><div key={i} className="space-y-2"><div className="h-4 w-32 bg-bg-hover rounded"/><div className="h-9 bg-bg-hover rounded"/></div>)}</div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl mb-1">Site Ayarları</h1>
          <p className="text-text-secondary text-sm">Platformun tüm içerik ve ayarlarını buradan düzenleyin</p>
        </div>
        <div className="flex gap-2">
          {changed.size > 0 && (
            <span className="badge-purple text-xs self-center">{changed.size} değişiklik</span>
          )}
          <button onClick={saveAll} disabled={saving || changed.size === 0} className="btn-primary text-sm">
            {saving ? <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <Save size={14}/>}
            Tümünü Kaydet
          </button>
        </div>
      </div>

      {/* Group tabs */}
      <div className="flex gap-1 p-1 bg-bg-secondary rounded-xl border border-border flex-wrap">
        {groups.map(g => {
          const info = GROUP_LABELS[g] || { label: g, icon: Settings };
          const Icon = info.icon;
          const gChanges = settings.filter(s => s.group === g && changed.has(s.key)).length;
          return (
            <button key={g} onClick={() => setActiveGroup(g)}
              className={cn("flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all flex-1 justify-center",
                activeGroup === g
                  ? "bg-bg-card text-text-primary shadow-sm border border-border"
                  : "text-text-secondary hover:text-text-primary")}>
              <Icon size={14}/>
              {info.label}
              {gChanges > 0 && <span className="badge-purple text-xs">{gChanges}</span>}
            </button>
          );
        })}
      </div>

      {/* Settings form */}
      <div className="card p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-semibold flex items-center gap-2">
            {(() => { const Icon = GROUP_LABELS[activeGroup]?.icon || Settings; return <Icon size={16} className="text-accent"/>; })()}
            {GROUP_LABELS[activeGroup]?.label || activeGroup}
          </h2>
          <button onClick={saveGroup} disabled={saving || groupChangedCount === 0} className="btn-secondary text-sm">
            {saving ? <span className="w-3.5 h-3.5 border border-accent/40 border-t-accent rounded-full animate-spin"/> : <Save size={13}/>}
            Bu Grubu Kaydet {groupChangedCount > 0 && `(${groupChangedCount})`}
          </button>
        </div>

        <div className="space-y-5">
          {groupSettings.map(s => (
            <div key={s.key}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="label mb-0">{s.label}</label>
                <div className="flex items-center gap-2">
                  {s.is_public && <span className="badge-teal text-xs flex items-center gap-1"><Eye size={9}/>Public</span>}
                  {changed.has(s.key) && <span className="badge-purple text-xs">değişti</span>}
                </div>
              </div>
              {renderInput(s)}
              {s.description && <p className="text-text-muted text-xs mt-1">{s.description}</p>}
              <p className="text-text-muted text-xs mt-0.5 font-mono opacity-50">key: {s.key}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
