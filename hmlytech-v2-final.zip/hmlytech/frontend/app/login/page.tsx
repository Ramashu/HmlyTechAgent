"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Bot, Mail, Lock, Eye, EyeOff, ArrowRight, Chrome, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { authApi } from "@/lib/api/client";
import { useAuthStore } from "@/lib/store/auth";

const schema = z.object({
  email: z.string().email("Gecersiz e-posta"),
  password: z.string().min(1, "Sifre gerekli"),
});
type F = z.infer<typeof schema>;

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { setUser, setTokens } = useAuthStore();
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const verified = params.get("verified") === "1";

  const { register, handleSubmit, formState: { errors } } = useForm<F>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: F) => {
    setLoading(true);
    try {
      const res = await authApi.login(data);
      setTokens(res.data.access_token, res.data.refresh_token);
      setUser(res.data.user);
      toast.success("Hosgeldiniz!");
      const role = res.data.user?.role;
      router.push(["super_admin","admin"].includes(role) ? "/admin/dashboard" : "/member/dashboard");
    } catch (e: any) {
      toast.error(e?.response?.data?.detail || "Giris basarisiz");
    } finally { setLoading(false); }
  };

  const handleGoogle = async () => {
    try { const r = await authApi.googleUrl(); window.location.href = r.data.url; }
    catch { toast.error("Google OAuth kullanilamiyor"); }
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-accent/4 blur-3xl"/>
      </div>
      <div className="w-full max-w-md relative animate-slide-up">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center"><Bot size={20} className="text-white"/></div>
            <span className="font-display font-bold text-xl">HmlyTech</span>
          </Link>
          <h1 className="font-display font-bold text-2xl mb-1">Tekrar hosgeldiniz</h1>
          <p className="text-text-secondary text-sm">Agent dashboard'iniza giris yapin</p>
        </div>
        {verified && (
          <div className="flex items-center gap-2 p-3 bg-teal-accent/10 border border-teal-accent/20 rounded-xl mb-4">
            <CheckCircle size={16} className="text-teal-accent flex-shrink-0"/>
            <p className="text-teal-accent text-sm">E-posta basariyla dogrulandi! Simdi giris yapabilirsiniz.</p>
          </div>
        )}
        <div className="card p-6 space-y-4">
          <button onClick={handleGoogle} className="btn-secondary w-full justify-center py-2.5">
            <Chrome size={16}/> Google ile Devam Et
          </button>
          <div className="flex items-center gap-3"><div className="flex-1 h-px bg-border"/><span className="text-text-muted text-xs">veya</span><div className="flex-1 h-px bg-border"/></div>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="label">E-posta</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/>
                <input {...register("email")} type="email" placeholder="you@example.com" className="input pl-9 w-full" autoComplete="email"/>
              </div>
              {errors.email && <p className="text-error text-xs mt-1">{errors.email.message}</p>}
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="label mb-0">Sifre</label>
                <Link href="/forgot-password" className="text-accent text-xs hover:underline">Sifremi unuttum</Link>
              </div>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"/>
                <input {...register("password")} type={showPass?"text":"password"} placeholder="••••••••" className="input pl-9 pr-10 w-full" autoComplete="current-password"/>
                <button type="button" onClick={()=>setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary transition-colors">
                  {showPass?<EyeOff size={15}/>:<Eye size={15}/>}
                </button>
              </div>
              {errors.password && <p className="text-error text-xs mt-1">{errors.password.message}</p>}
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
              {loading?<span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>:<>Giris Yap <ArrowRight size={15}/></>}
            </button>
          </form>
        </div>
        <p className="text-center text-text-muted text-sm mt-4">
          Hesabiniz yok mu?{" "}
          <Link href="/register" className="text-accent hover:text-accent-hover transition-colors">Ucretsiz Kayit Ol</Link>
        </p>
      </div>
    </div>
  );
}
