"use client";
import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Bot, Lock, Eye, EyeOff, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api/client";

const schema = z.object({
  new_password: z.string().min(8, "En az 8 karakter"),
  confirm: z.string(),
}).refine(d => d.new_password === d.confirm, { message: "Şifreler eşleşmiyor", path: ["confirm"] });

export default function ResetPasswordPage() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("token");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: { new_password: string; confirm: string }) => {
    if (!token) { toast.error("Geçersiz link"); return; }
    setLoading(true);
    try {
      await api.post("/auth/reset-password", { token, new_password: data.new_password });
      setDone(true);
      setTimeout(() => router.push("/login"), 2500);
    } catch (e: any) {
      toast.error(e?.response?.data?.detail || "Şifre sıfırlama başarısız");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4">
      <div className="w-full max-w-md animate-slide-up">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center">
              <Bot size={20} className="text-white" />
            </div>
            <span className="font-display font-bold text-xl">HmlyTech</span>
          </Link>
          <h1 className="font-display font-bold text-2xl mb-1">Yeni Şifre Belirle</h1>
          <p className="text-text-secondary text-sm">Güçlü bir şifre seçin</p>
        </div>

        <div className="card p-6">
          {done ? (
            <div className="text-center py-4">
              <CheckCircle size={40} className="text-teal-accent mx-auto mb-4" />
              <h3 className="font-display font-semibold mb-2">Şifre Güncellendi!</h3>
              <p className="text-text-secondary text-sm">Giriş sayfasına yönlendiriliyorsunuz…</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit as any)} className="space-y-4">
              <div>
                <label className="label">Yeni Şifre</label>
                <div className="relative">
                  <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                  <input
                    {...register("new_password")}
                    type={showPwd ? "text" : "password"}
                    placeholder="••••••••"
                    className="input pl-9 pr-10 w-full"
                  />
                  <button type="button" onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary">
                    {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                {errors.new_password && (
                  <p className="text-error text-xs mt-1">{errors.new_password.message as string}</p>
                )}
              </div>
              <div>
                <label className="label">Şifre Tekrar</label>
                <div className="relative">
                  <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
                  <input
                    {...register("confirm")}
                    type={showPwd ? "text" : "password"}
                    placeholder="••••••••"
                    className="input pl-9 w-full"
                  />
                </div>
                {errors.confirm && (
                  <p className="text-error text-xs mt-1">{errors.confirm.message as string}</p>
                )}
              </div>
              <button type="submit" disabled={loading || !token} className="btn-primary w-full justify-center py-2.5">
                {loading
                  ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  : "Şifremi Güncelle"}
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-text-muted text-sm mt-4">
          <Link href="/login" className="text-accent hover:underline">Giriş sayfasına dön</Link>
        </p>
      </div>
    </div>
  );
}
