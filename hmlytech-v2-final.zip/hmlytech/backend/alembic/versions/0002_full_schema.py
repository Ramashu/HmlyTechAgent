"""full schema v2

Revision ID: 0002_full_schema
Revises: 0001_initial
Create Date: 2026-01-02 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_full_schema"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add new columns to users
    with op.batch_alter_table("users") as batch_op:
        batch_op.add_column(sa.Column("role", sa.String(50), nullable=False, server_default="member"))
        batch_op.add_column(sa.Column("status", sa.String(50), nullable=False, server_default="pending"))
        batch_op.add_column(sa.Column("verification_token", sa.String(128), nullable=True))
        batch_op.add_column(sa.Column("verification_token_expires", sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column("reset_token", sa.String(128), nullable=True))
        batch_op.add_column(sa.Column("reset_token_expires", sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column("permissions", sa.Text(), nullable=True))
        batch_op.add_column(sa.Column("last_login", sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column("login_count", sa.Integer(), nullable=True, server_default="0"))

    # Site settings table
    op.create_table(
        "site_settings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(100), nullable=False),
        sa.Column("value", sa.Text(), nullable=True),
        sa.Column("label", sa.String(200), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("group", sa.String(50), nullable=True),
        sa.Column("input_type", sa.String(30), nullable=True, server_default="text"),
        sa.Column("is_public", sa.Boolean(), nullable=True, server_default="false"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_by", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_site_settings_key", "site_settings", ["key"], unique=True)
    op.create_index("ix_site_settings_group", "site_settings", ["group"])


def downgrade() -> None:
    op.drop_table("site_settings")
    with op.batch_alter_table("users") as batch_op:
        for col in ["role","status","verification_token","verification_token_expires",
                    "reset_token","reset_token_expires","permissions","last_login","login_count"]:
            batch_op.drop_column(col)
