from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.core.config import settings
from app.core.database import engine, Base
from app.routes import auth, agents, execution, tools, memory, admin, member

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting HmlyTech Agent Platform...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables ready.")
    
    from app.core.database import AsyncSessionLocal
    from app.services.admin_service import seed_super_admin
    from app.services.settings_service import seed_settings
    async with AsyncSessionLocal() as db:
        await seed_super_admin(db)
        await seed_settings(db)
        await db.commit()
    logger.info("Seed data applied.")
    yield
    logger.info("Shutting down...")


app = FastAPI(
    title="HmlyTech Agent API",
    description="AI Agent Platform — Create, manage and deploy AI agents",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router,      prefix="/api/auth",   tags=["Auth"])
app.include_router(agents.router,    prefix="/api/agents", tags=["Agents"])
app.include_router(execution.router, prefix="/api/agent",  tags=["Execution"])
app.include_router(tools.router,     prefix="/api/tools",  tags=["Tools"])
app.include_router(memory.router,    prefix="/api/memory", tags=["Memory"])
app.include_router(admin.router,     prefix="/api/admin",  tags=["Admin"])
app.include_router(member.router,    prefix="/api/member", tags=["Member"])


@app.get("/health")
async def health():
    return {"status": "healthy", "version": "2.0.0", "platform": "HmlyTech Agent"}
