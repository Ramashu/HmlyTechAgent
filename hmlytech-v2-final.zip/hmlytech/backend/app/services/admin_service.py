from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc
from fastapi import HTTPException, BackgroundTasks
import secrets, json
from typing import List, Optional

from app.models.user import User, UserRole, UserStatus
from app.models.agent import Agent, Execution
from app.core.security import hash_password
from app.core.config import settings
from app.services.email_service import send_role_changed_email


async def seed_super_admin(db: AsyncSession):
    result = await db.execute(select(User).where(User.email == settings.SUPER_ADMIN_EMAIL))
    existing = result.scalar_one_or_none()
    if existing:
        if existing.role != UserRole.SUPER_ADMIN:
            existing.role = UserRole.SUPER_ADMIN
            existing.is_verified = True
            existing.status = UserStatus.ACTIVE
            await db.flush()
        return
    admin = User(
        email=settings.SUPER_ADMIN_EMAIL,
        username=settings.SUPER_ADMIN_USERNAME,
        hashed_password=hash_password(settings.SUPER_ADMIN_PASSWORD),
        full_name="Super Admin", role=UserRole.SUPER_ADMIN,
        status=UserStatus.ACTIVE, is_active=True, is_verified=True,
        plan="pro", api_key=secrets.token_urlsafe(32),
    )
    db.add(admin)
    await db.flush()


async def list_users(db: AsyncSession, skip=0, limit=50, role=None, status=None, search=None) -> dict:
    query = select(User)
    if role:
        query = query.where(User.role == role)
    if status:
        query = query.where(User.status == status)
    if search:
        pattern = f"%{search}%"
        query = query.where(
            User.email.ilike(pattern) | User.username.ilike(pattern) | User.full_name.ilike(pattern)
        )
    count_q = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_q)).scalar() or 0
    query = query.order_by(desc(User.created_at)).offset(skip).limit(limit)
    result = await db.execute(query)
    return {"users": list(result.scalars().all()), "total": total, "skip": skip, "limit": limit}


async def get_user_by_id(user_id: int, db: AsyncSession) -> User:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "Kullanici bulunamadi.")
    return user


async def update_user_role(user_id: int, new_role: str, permissions: Optional[List[str]],
                            admin_user: User, db: AsyncSession, background: Optional[BackgroundTasks] = None) -> User:
    user = await get_user_by_id(user_id, db)
    if new_role == UserRole.SUPER_ADMIN and admin_user.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "Super admin rolu yalnizca super admin tarafindan atanabilir.")
    if user.role == UserRole.SUPER_ADMIN and admin_user.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "Super admin kullanicisi degistirilemez.")
    old_role = user.role
    user.role = new_role
    if permissions is not None:
        user.permissions = json.dumps(permissions)
    await db.flush()
    await db.refresh(user)
    if background and old_role != new_role:
        background.add_task(send_role_changed_email, to=user.email,
                            full_name=user.full_name or user.username, new_role=new_role)
    return user


async def update_user_status(user_id: int, new_status: str, admin_user: User, db: AsyncSession) -> User:
    user = await get_user_by_id(user_id, db)
    if user.role == UserRole.SUPER_ADMIN:
        raise HTTPException(403, "Super admin kullanicisinin durumu degistirilemez.")
    user.status = new_status
    user.is_active = (new_status == UserStatus.ACTIVE)
    await db.flush(); await db.refresh(user); return user


async def update_user_plan(user_id: int, plan: str, db: AsyncSession) -> User:
    user = await get_user_by_id(user_id, db)
    user.plan = plan
    await db.flush(); await db.refresh(user); return user


async def delete_user(user_id: int, admin_user: User, db: AsyncSession):
    user = await get_user_by_id(user_id, db)
    if user.role == UserRole.SUPER_ADMIN:
        raise HTTPException(403, "Super admin silinemez.")
    if user.id == admin_user.id:
        raise HTTPException(403, "Kendi hesabinizi silemezsiniz.")
    await db.delete(user)
    await db.flush()


async def reset_user_password(user_id: int, new_password: str, db: AsyncSession) -> User:
    user = await get_user_by_id(user_id, db)
    user.hashed_password = hash_password(new_password)
    await db.flush(); return user


async def get_platform_stats(db: AsyncSession) -> dict:
    total_users = (await db.execute(select(func.count(User.id)))).scalar() or 0
    active_users = (await db.execute(select(func.count(User.id)).where(User.status == UserStatus.ACTIVE))).scalar() or 0
    pending_users = (await db.execute(select(func.count(User.id)).where(User.status == UserStatus.PENDING))).scalar() or 0
    total_agents = (await db.execute(select(func.count(Agent.id)).where(Agent.is_active == True))).scalar() or 0
    total_executions = (await db.execute(select(func.count(Execution.id)))).scalar() or 0
    total_tokens = (await db.execute(select(func.sum(Execution.tokens_used)))).scalar() or 0
    role_counts = {}
    for role in UserRole:
        c = (await db.execute(select(func.count(User.id)).where(User.role == role))).scalar() or 0
        role_counts[role.value] = c
    return {"total_users": total_users, "active_users": active_users,
            "pending_users": pending_users, "total_agents": total_agents,
            "total_executions": total_executions, "total_tokens": total_tokens,
            "role_counts": role_counts}
