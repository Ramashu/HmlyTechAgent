import smtplib, logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from app.core.config import settings

logger = logging.getLogger(__name__)


def _send(to: str, subject: str, html: str, plain: str = "") -> bool:
    if not settings.SMTP_HOST or not settings.SMTP_USER:
        logger.warning("SMTP not configured — skipping email to %s", to)
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{settings.MAIL_FROM_NAME} <{settings.MAIL_FROM}>"
        msg["To"] = to
        if plain:
            msg.attach(MIMEText(plain, "plain", "utf-8"))
        msg.attach(MIMEText(html, "html", "utf-8"))
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as s:
            s.ehlo()
            if settings.SMTP_TLS:
                s.starttls()
            if settings.SMTP_USER and settings.SMTP_PASS:
                s.login(settings.SMTP_USER, settings.SMTP_PASS)
            s.sendmail(settings.MAIL_FROM, to, msg.as_string())
        logger.info("Email sent to %s: %s", to, subject)
        return True
    except Exception as exc:
        logger.error("Email failed to %s: %s", to, exc)
        return False


def _wrap(content: str, title: str = "HmlyTech Agent") -> str:
    return f"""<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"/>
<title>{title}</title>
<style>
body{{margin:0;padding:0;background:#0a0a0f;font-family:'Segoe UI',Arial,sans-serif;color:#f0f0f8}}
.wrap{{max-width:560px;margin:40px auto;background:#1a1a24;border-radius:16px;border:1px solid #2a2a38;overflow:hidden}}
.hdr{{background:linear-gradient(135deg,#6c63ff,#00d4aa);padding:28px 36px}}
.hdr h1{{margin:0;font-size:20px;color:#fff}}.hdr p{{margin:4px 0 0;color:rgba(255,255,255,.7);font-size:12px}}
.bd{{padding:28px 36px}}.bd h2{{margin:0 0 12px;font-size:17px}}
.bd p{{margin:0 0 14px;color:#9898b0;font-size:14px;line-height:1.6}}
.btn{{display:inline-block;background:#6c63ff;color:#fff!important;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;margin:6px 0 18px}}
.ft{{padding:16px 36px;border-top:1px solid #2a2a38;font-size:11px;color:#5a5a72;text-align:center}}
</style></head><body>
<div class="wrap">
  <div class="hdr"><h1>🤖 HmlyTech Agent</h1><p>AI Agent Platform</p></div>
  <div class="bd">{content}</div>
  <div class="ft">Bu e-posta <strong>mail@hmlytech.com</strong> adresinden gönderilmiştir.<br/>© 2026 HmlyTech Agent Platform</div>
</div></body></html>"""


def send_welcome_email(to: str, full_name: str, username: str, verification_link: str) -> bool:
    name = full_name or username
    c = f"""<h2>Aramıza Hoşgeldiniz, {name}! 🎉</h2>
<p>HmlyTech Agent'e kayıt olduğunuz için teşekkürler. Kendi AI agent'larınızı oluşturabilir, yönetebilir ve API üzerinden deploy edebilirsiniz.</p>
<p>Hesabınızı aktif etmek için e-posta adresinizi doğrulayın:</p>
<a href="{verification_link}" class="btn">✉️ E-Posta Adresimi Doğrula</a>
<p style="font-size:12px;color:#5a5a72">Link 24 saat geçerlidir. Kullanıcı adınız: <strong>@{username}</strong></p>"""
    return _send(to, "🎉 Aramıza Hoşgeldiniz — HmlyTech Agent", _wrap(c, "Hoşgeldiniz"),
                 f"Hoşgeldiniz {name}! Doğrulama: {verification_link}")


def send_verification_email(to: str, full_name: str, verification_link: str) -> bool:
    name = full_name or to
    c = f"""<h2>E-Posta Doğrulama</h2>
<p>Merhaba {name}, aşağıdaki butona tıklayarak hesabınızı aktif edin:</p>
<a href="{verification_link}" class="btn">✉️ E-Postamı Doğrula</a>
<p style="font-size:12px;color:#5a5a72">Link 24 saat geçerlidir.</p>"""
    return _send(to, "E-Posta Doğrulama — HmlyTech", _wrap(c), f"Doğrulama: {verification_link}")


def send_password_reset_email(to: str, full_name: str, reset_link: str) -> bool:
    name = full_name or to
    c = f"""<h2>Şifre Sıfırlama</h2>
<p>Merhaba {name}, şifre sıfırlama talebiniz alındı.</p>
<a href="{reset_link}" class="btn">🔑 Şifremi Sıfırla</a>
<p style="font-size:12px;color:#5a5a72">Bu link 1 saat geçerlidir.</p>"""
    return _send(to, "Şifre Sıfırlama — HmlyTech", _wrap(c), f"Sıfırlama linki: {reset_link}")


def send_role_changed_email(to: str, full_name: str, new_role: str) -> bool:
    labels = {"super_admin":"Süper Admin","admin":"Admin","plus":"Plus Üye","member":"Üye"}
    label = labels.get(new_role, new_role)
    c = f"""<h2>Rolünüz Güncellendi</h2>
<p>Merhaba {full_name or to}, hesabınız <strong style="color:#6c63ff">{label}</strong> olarak güncellendi.</p>
<p>Yeni yetkileriniz hemen aktif olmuştur.</p>"""
    return _send(to, f"Rol Güncellemesi — HmlyTech", _wrap(c), f"Rolünüz: {label}")
