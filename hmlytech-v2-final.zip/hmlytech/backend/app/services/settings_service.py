from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Dict, List
from app.models.settings import SiteSetting

DEFAULT_SETTINGS = [
    {"key":"site_name","value":"HmlyTech Agent","label":"Site Adı","group":"general","input_type":"text","is_public":True},
    {"key":"site_tagline","value":"AI Agent Platform","label":"Slogan","group":"general","input_type":"text","is_public":True},
    {"key":"site_description","value":"Kendi AI agent'larınızı oluşturun, yönetin ve API olarak deploy edin.","label":"Site Açıklaması","group":"general","input_type":"textarea","is_public":True},
    {"key":"contact_email","value":"mail@hmlytech.com","label":"İletişim E-postası","group":"general","input_type":"text","is_public":True},
    {"key":"maintenance_mode","value":"false","label":"Bakım Modu","group":"general","input_type":"bool","is_public":True},
    {"key":"hero_title","value":"Build AI agents\nthat actually work","label":"Hero Başlık","group":"landing","input_type":"textarea","is_public":True},
    {"key":"hero_subtitle","value":"Kendi AI agent'larınızı oluşturun, yönetin ve API olarak deploy edin.","label":"Hero Alt Başlık","group":"landing","input_type":"textarea","is_public":True},
    {"key":"hero_cta_primary","value":"Ücretsiz Başla","label":"Birincil Buton","group":"landing","input_type":"text","is_public":True},
    {"key":"hero_cta_secondary","value":"Demo İzle","label":"İkincil Buton","group":"landing","input_type":"text","is_public":True},
    {"key":"feature1_title","value":"Agent Builder","label":"Özellik 1 Başlık","group":"landing","input_type":"text","is_public":True},
    {"key":"feature1_desc","value":"Özel sistem promptları, hedefler ve model seçimiyle agent tasarlayın.","label":"Özellik 1 Açıklama","group":"landing","input_type":"textarea","is_public":True},
    {"key":"feature2_title","value":"Tool Calling","label":"Özellik 2 Başlık","group":"landing","input_type":"text","is_public":True},
    {"key":"feature2_desc","value":"HTTP istekleri, web arama ve özel fonksiyon çağrısı.","label":"Özellik 2 Açıklama","group":"landing","input_type":"textarea","is_public":True},
    {"key":"feature3_title","value":"API Olarak Deploy Et","label":"Özellik 3 Başlık","group":"landing","input_type":"text","is_public":True},
    {"key":"feature3_desc","value":"Her agent kendi REST endpoint'ini alır.","label":"Özellik 3 Açıklama","group":"landing","input_type":"textarea","is_public":True},
    {"key":"email_from_name","value":"HmlyTech Agent","label":"Gönderen Adı","group":"email","input_type":"text","is_public":False},
    {"key":"email_welcome_subject","value":"🎉 Aramıza Hoşgeldiniz — HmlyTech Agent","label":"Hoşgeldiniz Konusu","group":"email","input_type":"text","is_public":False},
    {"key":"email_footer_text","value":"Bu e-posta mail@hmlytech.com adresinden gönderilmiştir.","label":"Mail Footer","group":"email","input_type":"textarea","is_public":False},
    {"key":"max_agents_free","value":"5","label":"Ücretsiz Max Agent","group":"limits","input_type":"number","is_public":True},
    {"key":"max_agents_plus","value":"25","label":"Plus Max Agent","group":"limits","input_type":"number","is_public":True},
    {"key":"registrations_open","value":"true","label":"Yeni Kayıt Açık","group":"limits","input_type":"bool","is_public":True},
    {"key":"require_email_verification","value":"true","label":"Email Doğrulama Zorunlu","group":"limits","input_type":"bool","is_public":False},
]

async def seed_settings(db: AsyncSession):
    for item in DEFAULT_SETTINGS:
        r = await db.execute(select(SiteSetting).where(SiteSetting.key == item["key"]))
        if not r.scalar_one_or_none():
            db.add(SiteSetting(**item))
    await db.flush()

async def get_setting(key: str, db: AsyncSession, default: str = "") -> str:
    r = await db.execute(select(SiteSetting).where(SiteSetting.key == key))
    s = r.scalar_one_or_none()
    return s.value if s and s.value is not None else default

async def get_all_settings(db: AsyncSession) -> List[SiteSetting]:
    r = await db.execute(select(SiteSetting).order_by(SiteSetting.group, SiteSetting.key))
    return list(r.scalars().all())

async def get_public_settings(db: AsyncSession) -> Dict[str, str]:
    r = await db.execute(select(SiteSetting).where(SiteSetting.is_public == True))
    return {s.key: s.value for s in r.scalars().all()}

async def update_setting(key: str, value: str, user_id: int, db: AsyncSession) -> SiteSetting:
    r = await db.execute(select(SiteSetting).where(SiteSetting.key == key))
    s = r.scalar_one_or_none()
    if not s:
        s = SiteSetting(key=key, value=value, updated_by=user_id); db.add(s)
    else:
        s.value = value; s.updated_by = user_id
    await db.flush(); await db.refresh(s); return s

async def bulk_update_settings(updates: Dict[str, str], user_id: int, db: AsyncSession):
    for k, v in updates.items():
        await update_setting(k, v, user_id, db)
