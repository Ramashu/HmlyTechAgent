from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from fastapi import HTTPException, status, BackgroundTasks
import httpx, secrets
from datetime import datetime, timedelta, timezone

from app.models.user import User, UserRole, UserStatus
from app.core.security import hash_password, verify_password, create_access_token, create_refresh_token
from app.core.config import settings
from app.services.email_service import send_welcome_email, send_password_reset_email

DISPOSABLE = {
    "mailinator.com","guerrillamail.com","throwam.com","trashmail.com",
    "fakeinbox.com","maildrop.cc","yopmail.com","sharklasers.com","spam4.me",
    "tempmail.com","temp-mail.org","dispostable.com","10minutemail.com",
    "discard.email","tempr.email","getnada.com","emkei.cz","nwldx.com",
}

def _is_disposable(email: str) -> bool:
    return email.lower().split("@")[-1] in DISPOSABLE

async def _unique_username(base: str, db: AsyncSession) -> str:
    uname = base.replace(".","_")[:20]
    i = 1
    while True:
        r = await db.execute(select(User).where(User.username == uname))
        if not r.scalar_one_or_none():
            return uname
        uname = f"{base[:18]}{i}"; i += 1

async def register_user(data, db: AsyncSession, background: BackgroundTasks) -> dict:
    email = data.email.lower().strip()
    if _is_disposable(email):
        raise HTTPException(400, "Geçici/sahte e-posta adresleri kabul edilmemektedir.")
    r = await db.execute(select(User).where(User.email == email))
    if r.scalar_one_or_none():
        raise HTTPException(400, "Bu e-posta adresi zaten kayıtlı.")
    r = await db.execute(select(User).where(User.username == data.username))
    if r.scalar_one_or_none():
        raise HTTPException(400, "Bu kullanıcı adı alınmış.")
    token = secrets.token_urlsafe(48)
    expires = datetime.now(timezone.utc) + timedelta(hours=24)
    user = User(
        email=email, username=data.username,
        hashed_password=hash_password(data.password),
        full_name=data.full_name, role=UserRole.MEMBER,
        status=UserStatus.PENDING, is_active=True, is_verified=False,
        verification_token=token, verification_token_expires=expires,
        api_key=secrets.token_urlsafe(32),
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    link = f"{settings.FRONTEND_URL}/verify-email?token={token}"
    background.add_task(send_welcome_email, to=email,
        full_name=data.full_name or data.username,
        username=data.username, verification_link=link)
    return {"user": user,
            "access_token": create_access_token({"sub": str(user.id)}),
            "refresh_token": create_refresh_token({"sub": str(user.id)})}

async def verify_email(token: str, db: AsyncSession) -> User:
    r = await db.execute(select(User).where(User.verification_token == token))
    user = r.scalar_one_or_none()
    if not user:
        raise HTTPException(400, "Geçersiz doğrulama linki.")
    if user.verification_token_expires and user.verification_token_expires < datetime.now(timezone.utc):
        raise HTTPException(400, "Doğrulama linki süresi dolmuş.")
    user.is_verified = True; user.status = UserStatus.ACTIVE
    user.verification_token = None; user.verification_token_expires = None
    await db.flush(); return user

async def login_user(data, db: AsyncSession) -> dict:
    email = data.email.lower().strip()
    r = await db.execute(select(User).where(User.email == email))
    user = r.scalar_one_or_none()
    if not user or not user.hashed_password or not verify_password(data.password, user.hashed_password):
        raise HTTPException(401, "E-posta veya şifre yanlış.")
    if not user.is_active or user.status == UserStatus.BANNED:
        raise HTTPException(403, "Hesabınız askıya alınmış veya yasaklanmış.")
    if not user.is_verified and user.status == UserStatus.PENDING:
        raise HTTPException(403, "Lütfen önce e-posta adresinizi doğrulayın.")
    user.last_login = datetime.now(timezone.utc)
    user.login_count = (user.login_count or 0) + 1
    await db.flush()
    return {"user": user,
            "access_token": create_access_token({"sub": str(user.id)}),
            "refresh_token": create_refresh_token({"sub": str(user.id)})}

async def get_google_auth_url() -> str:
    p = {"client_id": settings.GOOGLE_CLIENT_ID,
         "redirect_uri": settings.GOOGLE_REDIRECT_URI,
         "response_type": "code", "scope": "openid email profile",
         "access_type": "offline", "prompt": "consent"}
    return "https://accounts.google.com/o/oauth2/v2/auth?" + "&".join(f"{k}={v}" for k,v in p.items())

async def handle_google_callback(code: str, db: AsyncSession, background: BackgroundTasks) -> dict:
    async with httpx.AsyncClient() as c:
        tr = await c.post("https://oauth2.googleapis.com/token", data={
            "code": code, "client_id": settings.GOOGLE_CLIENT_ID,
            "client_secret": settings.GOOGLE_CLIENT_SECRET,
            "redirect_uri": settings.GOOGLE_REDIRECT_URI, "grant_type": "authorization_code"})
        td = tr.json()
        if "error" in td:
            raise HTTPException(400, f"Google OAuth hatası: {td['error']}")
        ui = (await c.get("https://www.googleapis.com/oauth2/v2/userinfo",
            headers={"Authorization": f"Bearer {td['access_token']}"})).json()
    email = ui.get("email","").lower()
    r = await db.execute(select(User).where(User.google_id == ui["id"]))
    user = r.scalar_one_or_none()
    if not user:
        r = await db.execute(select(User).where(User.email == email))
        user = r.scalar_one_or_none()
        if user:
            user.google_id = ui["id"]; user.avatar_url = ui.get("picture","")
        else:
            uname = await _unique_username(email.split("@")[0], db)
            user = User(email=email, username=uname, full_name=ui.get("name",""),
                avatar_url=ui.get("picture",""), google_id=ui["id"],
                is_verified=True, status=UserStatus.ACTIVE, role=UserRole.MEMBER,
                api_key=secrets.token_urlsafe(32))
            db.add(user); await db.flush(); await db.refresh(user)
            background.add_task(send_welcome_email, to=email,
                full_name=ui.get("name",""), username=uname,
                verification_link=f"{settings.FRONTEND_URL}/dashboard")
    user.last_login = datetime.now(timezone.utc)
    user.login_count = (user.login_count or 0) + 1
    await db.flush(); await db.refresh(user)
    return {"user": user,
            "access_token": create_access_token({"sub": str(user.id)}),
            "refresh_token": create_refresh_token({"sub": str(user.id)})}

async def request_password_reset(email: str, db: AsyncSession, background: BackgroundTasks):
    r = await db.execute(select(User).where(User.email == email.lower()))
    user = r.scalar_one_or_none()
    if not user: return
    token = secrets.token_urlsafe(48)
    user.reset_token = token
    user.reset_token_expires = datetime.now(timezone.utc) + timedelta(hours=1)
    await db.flush()
    background.add_task(send_password_reset_email, to=user.email,
        full_name=user.full_name or user.username,
        reset_link=f"{settings.FRONTEND_URL}/reset-password?token={token}")

async def confirm_password_reset(token: str, new_password: str, db: AsyncSession):
    r = await db.execute(select(User).where(User.reset_token == token))
    user = r.scalar_one_or_none()
    if not user: raise HTTPException(400, "Geçersiz token.")
    if user.reset_token_expires and user.reset_token_expires < datetime.now(timezone.utc):
        raise HTTPException(400, "Token süresi dolmuş.")
    user.hashed_password = hash_password(new_password)
    user.reset_token = None; user.reset_token_expires = None
    await db.flush(); return user
