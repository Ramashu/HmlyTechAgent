from pydantic_settings import BaseSettings
from typing import List
import secrets


class Settings(BaseSettings):
    APP_NAME: str = "HmlyTech Agent"
    DEBUG: bool = False
    SECRET_KEY: str = secrets.token_urlsafe(32)

    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/hmlytech"

    JWT_SECRET: str = "your-super-secret-jwt-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    GOOGLE_REDIRECT_URI: str = "http://localhost:8000/api/auth/google/callback"

    OPENAI_API_KEY: str = ""
    OPENAI_DEFAULT_MODEL: str = "gpt-4o"
    ANTHROPIC_API_KEY: str = ""

    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "https://hmlytech.vercel.app",
    ]
    FRONTEND_URL: str = "http://localhost:3000"

    # ── SMTP / Mail ──────────────────────────────────────────────
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASS: str = ""
    SMTP_TLS: bool = True
    MAIL_FROM: str = "mail@hmlytech.com"
    MAIL_FROM_NAME: str = "HmlyTech Agent"

    # Super-admin seed credentials
    SUPER_ADMIN_EMAIL: str = "admin@hmlytech.com"
    SUPER_ADMIN_PASSWORD: str = "admin123"
    SUPER_ADMIN_USERNAME: str = "superadmin"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
