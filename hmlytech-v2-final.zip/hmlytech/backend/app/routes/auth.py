from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Query
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, EmailStr
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user, decode_token, create_access_token, create_refresh_token
from app.models.user import User, UserRole, UserStatus
from app.services.auth_service import (
    register_user, login_user, verify_email, get_google_auth_url,
    handle_google_callback, request_password_reset, confirm_password_reset,
)
from app.services.settings_service import get_public_settings
from app.core.config import settings
import secrets

router = APIRouter()

class RegisterIn(BaseModel):
    email: EmailStr
    username: str
    password: str
    full_name: Optional[str] = None

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class RefreshIn(BaseModel):
    refresh_token: str

class ResetRequestIn(BaseModel):
    email: EmailStr

class ResetConfirmIn(BaseModel):
    token: str
    new_password: str

def user_resp(u: User):
    return {
        "id": u.id, "email": u.email, "username": u.username,
        "full_name": u.full_name, "avatar_url": u.avatar_url,
        "role": u.role, "status": u.status, "plan": u.plan,
        "is_verified": u.is_verified, "created_at": u.created_at,
        "login_count": u.login_count or 0,
    }

@router.post("/register")
async def register(data: RegisterIn, bg: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    result = await register_user(data, db, bg)
    return {"access_token": result["access_token"], "refresh_token": result["refresh_token"],
            "token_type": "bearer", "user": user_resp(result["user"])}

@router.post("/login")
async def login(data: LoginIn, db: AsyncSession = Depends(get_db)):
    result = await login_user(data, db)
    return {"access_token": result["access_token"], "refresh_token": result["refresh_token"],
            "token_type": "bearer", "user": user_resp(result["user"])}

@router.get("/verify-email")
async def verify(token: str, db: AsyncSession = Depends(get_db)):
    user = await verify_email(token, db)
    return RedirectResponse(url=f"{settings.FRONTEND_URL}/login?verified=1")

@router.post("/refresh")
async def refresh(data: RefreshIn, db: AsyncSession = Depends(get_db)):
    payload = decode_token(data.refresh_token)
    if payload.get("type") != "refresh":
        raise HTTPException(401, "Gecersiz refresh token")
    r = await db.execute(select(User).where(User.id == int(payload["sub"])))
    user = r.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(401, "Kullanici bulunamadi")
    return {"access_token": create_access_token({"sub": str(user.id)}),
            "refresh_token": create_refresh_token({"sub": str(user.id)}),
            "token_type": "bearer", "user": user_resp(user)}

@router.get("/google")
async def google_login():
    return {"url": await get_google_auth_url()}

@router.get("/google/callback")
async def google_callback(code: str, bg: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    result = await handle_google_callback(code, db, bg)
    return RedirectResponse(
        url=f"{settings.FRONTEND_URL}/auth/callback"
            f"?access_token={result['access_token']}&refresh_token={result['refresh_token']}"
    )

@router.post("/forgot-password")
async def forgot_password(data: ResetRequestIn, bg: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    await request_password_reset(data.email, db, bg)
    return {"message": "Sifre sifirlama e-postasi gonderildi."}

@router.post("/reset-password")
async def reset_password(data: ResetConfirmIn, db: AsyncSession = Depends(get_db)):
    await confirm_password_reset(data.token, data.new_password, db)
    return {"message": "Sifreniz basariyla guncellendi."}

@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return user_resp(current_user)

@router.get("/api-key")
async def get_api_key(current_user: User = Depends(get_current_user)):
    return {"api_key": current_user.api_key}

@router.post("/api-key/regenerate")
async def regen_api_key(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    current_user.api_key = secrets.token_urlsafe(32)
    await db.flush()
    return {"api_key": current_user.api_key}

@router.get("/public-settings")
async def public_settings(db: AsyncSession = Depends(get_db)):
    return await get_public_settings(db)
