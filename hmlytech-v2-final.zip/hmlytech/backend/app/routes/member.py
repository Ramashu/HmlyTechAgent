from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User, UserStatus
from app.core.security import hash_password, verify_password
import secrets

router = APIRouter()

class ProfileUpdateIn(BaseModel):
    full_name: Optional[str] = None
    username: Optional[str] = None

class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str

def user_resp(u: User):
    return {
        "id": u.id, "email": u.email, "username": u.username,
        "full_name": u.full_name, "avatar_url": u.avatar_url,
        "role": u.role, "status": u.status, "plan": u.plan,
        "is_verified": u.is_verified, "login_count": u.login_count or 0,
        "last_login": u.last_login, "created_at": u.created_at,
    }

@router.get("/profile")
async def get_profile(current_user: User = Depends(get_current_user)):
    return user_resp(current_user)

@router.put("/profile")
async def update_profile(
    data: ProfileUpdateIn,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import select
    if data.username and data.username != current_user.username:
        r = await db.execute(select(User).where(User.username == data.username))
        if r.scalar_one_or_none():
            raise HTTPException(400, "Bu kullanici adi alinmis.")
        current_user.username = data.username
    if data.full_name is not None:
        current_user.full_name = data.full_name
    await db.flush()
    await db.refresh(current_user)
    return user_resp(current_user)

@router.post("/change-password")
async def change_password(
    data: PasswordChangeIn,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not current_user.hashed_password or not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(400, "Mevcut sifre yanlis.")
    if len(data.new_password) < 8:
        raise HTTPException(400, "Yeni sifre en az 8 karakter olmalidir.")
    current_user.hashed_password = hash_password(data.new_password)
    await db.flush()
    return {"message": "Sifre basariyla guncellendi."}

@router.get("/api-key")
async def get_api_key(current_user: User = Depends(get_current_user)):
    return {"api_key": current_user.api_key}

@router.post("/api-key/regenerate")
async def regenerate_api_key(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    current_user.api_key = secrets.token_urlsafe(32)
    await db.flush()
    return {"api_key": current_user.api_key}

@router.get("/stats")
async def member_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import select, func
    from app.models.agent import Agent, Execution
    total_agents = (await db.execute(
        select(func.count(Agent.id)).where(Agent.owner_id == current_user.id, Agent.is_active == True)
    )).scalar() or 0
    total_runs = (await db.execute(
        select(func.sum(Agent.total_runs)).where(Agent.owner_id == current_user.id)
    )).scalar() or 0
    total_tokens = (await db.execute(
        select(func.sum(Agent.total_tokens_used)).where(Agent.owner_id == current_user.id)
    )).scalar() or 0
    return {"total_agents": total_agents, "total_runs": total_runs, "total_tokens_used": total_tokens}
