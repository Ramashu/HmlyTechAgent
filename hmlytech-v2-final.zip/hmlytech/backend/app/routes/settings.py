from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.services.settings_service import get_public_settings

router = APIRouter()


@router.get("/public")
async def public_settings(db: AsyncSession = Depends(get_db)):
    """All is_public settings — used by frontend for editable content."""
    return await get_public_settings(db)
