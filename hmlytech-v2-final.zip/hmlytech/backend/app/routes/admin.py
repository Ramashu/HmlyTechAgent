from fastapi import APIRouter, Depends, Query, BackgroundTasks, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional, List

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User, UserRole
from app.services.admin_service import (
    list_users, get_user_by_id, update_user_role, update_user_status,
    update_user_plan, delete_user, reset_user_password, get_platform_stats,
)
from app.services.settings_service import get_all_settings, bulk_update_settings, update_setting
from app.models.agent import Agent, Execution
from sqlalchemy import select, desc

router = APIRouter()

ADMIN_ROLES = {UserRole.SUPER_ADMIN, UserRole.ADMIN}

def require_admin(current_user: User = Depends(get_current_user)):
    if current_user.role not in ADMIN_ROLES:
        raise HTTPException(403, "Admin yetkisi gereklidir.")
    return current_user

def require_super_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.SUPER_ADMIN:
        raise HTTPException(403, "Super admin yetkisi gereklidir.")
    return current_user

def user_resp(u: User):
    import json
    return {
        "id": u.id, "email": u.email, "username": u.username,
        "full_name": u.full_name, "avatar_url": u.avatar_url,
        "role": u.role, "status": u.status, "plan": u.plan,
        "is_verified": u.is_verified, "api_key": u.api_key,
        "login_count": u.login_count or 0, "last_login": u.last_login,
        "created_at": u.created_at, "updated_at": u.updated_at,
        "permissions": json.loads(u.permissions) if u.permissions else [],
    }

class RoleUpdateIn(BaseModel):
    role: str
    permissions: Optional[List[str]] = None

class StatusUpdateIn(BaseModel):
    status: str

class PlanUpdateIn(BaseModel):
    plan: str

class PasswordResetIn(BaseModel):
    new_password: str

class SettingIn(BaseModel):
    key: str
    value: str

class BulkSettingsIn(BaseModel):
    settings: dict

# ── Stats ─────────────────────────────────────────────────────────────────────
@router.get("/stats")
async def stats(admin=Depends(require_admin), db: AsyncSession = Depends(get_db)):
    return await get_platform_stats(db)

# ── Users ────────────────────────────────────────────────────────────────────
@router.get("/users")
async def list_all_users(
    skip: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
    role: Optional[str] = None, status: Optional[str] = None, search: Optional[str] = None,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    result = await list_users(db, skip, limit, role, status, search)
    result["users"] = [user_resp(u) for u in result["users"]]
    return result

@router.get("/users/{user_id}")
async def get_user(user_id: int, admin=Depends(require_admin), db: AsyncSession = Depends(get_db)):
    u = await get_user_by_id(user_id, db)
    return user_resp(u)

@router.put("/users/{user_id}/role")
async def change_role(
    user_id: int, data: RoleUpdateIn, bg: BackgroundTasks,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    u = await update_user_role(user_id, data.role, data.permissions, admin, db, bg)
    return user_resp(u)

@router.put("/users/{user_id}/status")
async def change_status(
    user_id: int, data: StatusUpdateIn,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    u = await update_user_status(user_id, data.status, admin, db)
    return user_resp(u)

@router.put("/users/{user_id}/plan")
async def change_plan(
    user_id: int, data: PlanUpdateIn,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    u = await update_user_plan(user_id, data.plan, db)
    return user_resp(u)

@router.post("/users/{user_id}/reset-password")
async def admin_reset_password(
    user_id: int, data: PasswordResetIn,
    admin=Depends(require_super_admin), db: AsyncSession = Depends(get_db),
):
    await reset_user_password(user_id, data.new_password, db)
    return {"message": "Sifre guncellendi."}

@router.delete("/users/{user_id}")
async def remove_user(
    user_id: int, admin=Depends(require_super_admin), db: AsyncSession = Depends(get_db),
):
    await delete_user(user_id, admin, db)
    return {"message": "Kullanici silindi."}

# ── Agents (admin view) ───────────────────────────────────────────────────────
@router.get("/agents")
async def list_all_agents(
    skip: int = 0, limit: int = 50, search: Optional[str] = None,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    q = select(Agent)
    if search:
        q = q.where(Agent.name.ilike(f"%{search}%"))
    q = q.order_by(desc(Agent.created_at)).offset(skip).limit(limit)
    r = await db.execute(q)
    agents = r.scalars().all()
    return [{"id": a.id, "name": a.name, "owner_id": a.owner_id,
             "model": a.model, "total_runs": a.total_runs,
             "is_public": a.is_public, "is_active": a.is_active,
             "created_at": a.created_at} for a in agents]

@router.delete("/agents/{agent_id}")
async def admin_delete_agent(
    agent_id: int, admin=Depends(require_super_admin), db: AsyncSession = Depends(get_db),
):
    r = await db.execute(select(Agent).where(Agent.id == agent_id))
    agent = r.scalar_one_or_none()
    if not agent:
        raise HTTPException(404, "Agent bulunamadi.")
    agent.is_active = False
    await db.flush()
    return {"message": "Agent devre disi birakildi."}

# ── Settings ──────────────────────────────────────────────────────────────────
@router.get("/settings")
async def get_settings(admin=Depends(require_admin), db: AsyncSession = Depends(get_db)):
    settings_list = await get_all_settings(db)
    return [{"id": s.id, "key": s.key, "value": s.value, "label": s.label,
             "description": s.description, "group": s.group,
             "input_type": s.input_type, "is_public": s.is_public} for s in settings_list]

@router.put("/settings")
async def update_settings(
    data: BulkSettingsIn, admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    await bulk_update_settings(data.settings, admin.id, db)
    return {"message": f"{len(data.settings)} ayar guncellendi."}

@router.put("/settings/{key}")
async def update_one_setting(
    key: str, data: SettingIn,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    s = await update_setting(key, data.value, admin.id, db)
    return {"key": s.key, "value": s.value}

# ── Executions (admin view) ───────────────────────────────────────────────────
@router.get("/executions")
async def list_executions(
    skip: int = 0, limit: int = 50,
    admin=Depends(require_admin), db: AsyncSession = Depends(get_db),
):
    r = await db.execute(
        select(Execution).order_by(desc(Execution.created_at)).offset(skip).limit(limit)
    )
    execs = r.scalars().all()
    return [{"id": e.id, "agent_id": e.agent_id, "user_id": e.user_id,
             "status": e.status, "tokens_used": e.tokens_used,
             "duration_ms": e.duration_ms, "created_at": e.created_at} for e in execs]
