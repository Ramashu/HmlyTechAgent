<?php
/**
 * API Proxy — İsteğe bağlı sunucu taraflı Groq proxy
 * Kullanım: ?action=api&method=chat
 */
header('Content-Type: application/json');

if (!$auth->isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Oturum açılmamış.']);
    exit;
}

$method = $_GET['method'] ?? '';
if ($method !== 'chat') {
    http_response_code(400);
    echo json_encode(['error' => 'Geçersiz method.']);
    exit;
}

$body = file_get_contents('php://input');
$data = json_decode($body, true);

if (!$data || !isset($data['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Geçersiz istek.']);
    exit;
}

// API anahtarını veritabanından al (istemciye gösterme)
$setting = $db->fetchOne("SELECT setting_value FROM app_settings WHERE setting_key='groq_api_key'");
$apiKey  = $setting['setting_value'] ?? DEFAULT_API_KEY;

if (empty($apiKey)) {
    http_response_code(500);
    echo json_encode(['error' => 'API anahtarı yapılandırılmamış.']);
    exit;
}

$payload = [
    'model'    => $data['model'] ?? 'llama-3.3-70b-versatile',
    'messages' => $data['messages'],
    'max_tokens'  => min((int)($data['max_tokens'] ?? 1024), 4096),
    'temperature' => min(max((float)($data['temperature'] ?? 0.72), 0), 2),
    'stream'      => false,
];

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ],
    CURLOPT_TIMEOUT        => 60,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

http_response_code($httpCode);
echo $response;
