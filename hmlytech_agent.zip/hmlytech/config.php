<?php
/**
 * HmlyTech Agent - Yapılandırma
 */

// Hata raporlama (production'da kapalı)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/error.log');

// Veritabanı
define('DB_PATH', __DIR__ . '/data/hmlytech.sqlite');

// Oturum
define('SESSION_LIFETIME', 3600 * 8); // 8 saat

// Yedek dizini (sunucu tarafı)
define('BACKUP_DIR', __DIR__ . '/backups');

// Brute-force koruması
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 dakika

// Uygulama
define('APP_NAME', 'HmlyTech Agent');
define('DEFAULT_API_KEY', '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');
define('DEFAULT_MODEL', 'llama-3.3-70b-versatile');

// Dizinleri oluştur
foreach ([
    __DIR__ . '/data',
    __DIR__ . '/logs',
    __DIR__ . '/backups',
] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
}
