# HmlyTech Agent — Kurulum Kılavuzu

## Gereksinimler
- PHP 8.1+ (PDO SQLite, cURL, OpenSSL)
- Apache veya Nginx web sunucusu
- SQLite 3

## Kurulum

1. Tüm dosyaları web sunucunuzun dizinine kopyalayın
2. `data/`, `logs/`, `backups/` klasörlerinin yazılabilir olduğundan emin olun:
   ```bash
   chmod 750 data logs backups
   ```
3. `config.php` içinde gerekirse `DB_PATH` ve `BACKUP_DIR` yollarını güncelleyin
4. Tarayıcınızda `index.php`'yi açın

## Varsayılan Giriş
- **E-posta:** admin@hmlytech.com  
- **Şifre:** admin123

⚠️ **Güvenlik:** İlk girişten sonra şifrenizi derhal değiştirin!

## Windows Yedekleme
Web sunucusu Windows'ta çalışıyorsa yazışma yedekleri otomatik olarak şu klasöre aktarılır:
```
C:\Users\User\Desktop\HmlyTech Agent\
```
Linux/Mac sunucularda ise `backups/` klasörüne kaydedilir.

## Güvenlik Özellikleri
- Argon2id şifre hash (en güvenli algoritma)
- CSRF token koruması (her form)
- SQL injection engelleme (PDO prepared statements)
- XSS engelleme (htmlspecialchars)
- Brute-force koruması (5 deneme / 15 dakika)
- Session fixation koruması
- Güvenli HTTP başlıkları (CSP, X-Frame-Options vs.)
- Hassas dizinlere .htaccess erişim engeli

## Nginx Yapılandırması
```nginx
location ~ ^/(data|logs|backups|includes)/ {
    deny all;
}
location ~* \.(sqlite|db|log)$ {
    deny all;
}
```
