<?php $user = $pageData['user']; ?>
<style>
#profile-wrap { flex:1; overflow-y:auto; padding:24px; }
.profile-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:700px; }
@media(max-width:600px){ .profile-grid { grid-template-columns:1fr; } }
.card { background:var(--bg2); border:1px solid var(--border); border-radius:10px; overflow:hidden; }
.card-head { padding:12px 16px; border-bottom:1px solid var(--border); font-size:13px; font-weight:600; }
.card-body { padding:16px; display:flex; flex-direction:column; gap:14px; }
.info-row { display:flex; justify-content:space-between; font-size:13px; padding:6px 0; border-bottom:1px solid rgba(48,54,61,.4); }
.info-row:last-child { border-bottom:none; }
.info-row .label { color:var(--text2); }
</style>

<div id="profile-wrap">
  <div style="margin-bottom:20px">
    <h2 style="font-size:18px;font-weight:600">👤 Profil</h2>
  </div>

  <div class="profile-grid">
    <!-- Hesap Bilgileri -->
    <div class="card">
      <div class="card-head">Hesap Bilgileri</div>
      <div class="card-body">
        <div class="info-row">
          <span class="label">E-posta</span>
          <span><?= Security::sanitize($user['email']) ?></span>
        </div>
        <div class="info-row">
          <span class="label">Ad</span>
          <span><?= Security::sanitize($user['display_name'] ?: '—') ?></span>
        </div>
        <div class="info-row">
          <span class="label">Rol</span>
          <span class="badge badge-<?= $user['role'] ?>"><?= $user['role'] === 'admin' ? '🔑 Admin' : '👤 Kullanıcı' ?></span>
        </div>
        <div class="info-row">
          <span class="label">Kayıt</span>
          <span style="font-size:12px;color:var(--text2)"><?= substr($user['created_at'],0,16) ?></span>
        </div>
        <div class="info-row">
          <span class="label">Son Giriş</span>
          <span style="font-size:12px;color:var(--text2)"><?= $user['last_login'] ? substr($user['last_login'],0,16) : '—' ?></span>
        </div>
        <?php
        $backupCount = $db->fetchOne("SELECT COUNT(*) as cnt FROM chat_backups WHERE user_id=?",[$user['id']])['cnt'] ?? 0;
        ?>
        <div class="info-row">
          <span class="label">Yedek sayısı</span>
          <span><?= $backupCount ?></span>
        </div>
      </div>
    </div>

    <!-- Şifre Değiştir -->
    <div class="card">
      <div class="card-head">🔑 Şifre Değiştir</div>
      <div class="card-body">
        <form method="post" action="?action=change_password" style="display:flex;flex-direction:column;gap:12px">
          <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
          <div class="form-group">
            <label>Mevcut Şifre</label>
            <input class="form-input" type="password" name="current_password" required placeholder="••••••••">
          </div>
          <div class="form-group">
            <label>Yeni Şifre (min 8 kar, harf+rakam)</label>
            <input class="form-input" type="password" name="new_password" required placeholder="••••••••">
          </div>
          <div class="form-group">
            <label>Yeni Şifre (Tekrar)</label>
            <input class="form-input" type="password" id="np2" placeholder="••••••••">
          </div>
          <button type="submit" class="btn btn-primary" onclick="return checkPw()">Şifreyi Değiştir</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
function checkPw(){
  var np=document.querySelector('[name=new_password]').value;
  var np2=document.getElementById('np2').value;
  if(np!==np2){showToast('Yeni şifreler eşleşmiyor!','error');return false;}
  return true;
}
</script>
