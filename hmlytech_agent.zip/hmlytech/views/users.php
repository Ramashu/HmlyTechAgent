<?php
if (!$pageData['isAdmin']) { header('Location: ?action=chat'); exit; }
$users = $auth->getAllUsers();
?>
<style>
#users-wrap { flex:1; overflow-y:auto; padding:24px; }
.page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.page-header h2 { font-size:18px; font-weight:600; }
.card { background:var(--bg2); border:1px solid var(--border); border-radius:10px; overflow:hidden; }
.card-head { padding:12px 16px; border-bottom:1px solid var(--border); font-size:12px; font-weight:500; color:var(--text2); }
.modal-bg { display:none; position:fixed; inset:0; background:rgba(0,0,0,.7); z-index:1000; align-items:center; justify-content:center; }
.modal-bg.open { display:flex; }
.modal { background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:24px; width:380px; display:flex; flex-direction:column; gap:16px; }
.modal h3 { font-size:15px; font-weight:600; }
</style>

<div id="users-wrap">
  <div class="page-header">
    <h2>👥 Kullanıcı Yönetimi</h2>
    <button class="btn btn-primary" onclick="document.getElementById('create-modal').classList.add('open')">+ Yeni Kullanıcı</button>
  </div>

  <div class="card">
    <div class="card-head"><?= count($users) ?> kullanıcı</div>
    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>E-posta</th>
          <th>Ad</th>
          <th>Rol</th>
          <th>Durum</th>
          <th>Son Giriş</th>
          <th>İşlem</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td style="color:var(--text2)"><?= $u['id'] ?></td>
          <td><?= Security::sanitize($u['email']) ?></td>
          <td><?= Security::sanitize($u['display_name']) ?></td>
          <td><span class="badge badge-<?= $u['role'] ?>"><?= $u['role'] === 'admin' ? '🔑 Admin' : '👤 Kullanıcı' ?></span></td>
          <td><span class="badge <?= $u['is_active'] ? 'badge-active' : 'badge-inactive' ?>"><?= $u['is_active'] ? 'Aktif' : 'Pasif' ?></span></td>
          <td style="color:var(--text2);font-size:12px"><?= $u['last_login'] ? substr($u['last_login'],0,16) : '—' ?></td>
          <td>
            <?php if ($u['id'] !== $_SESSION['user_id']): ?>
            <form method="post" action="?action=delete_user" style="display:inline" onsubmit="return confirmDelete('<?= Security::sanitize($u['email']) ?> kullanıcısını silmek istediğinize emin misiniz?')">
              <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <button type="submit" class="btn btn-danger" style="padding:3px 9px;font-size:11px">Sil</button>
            </form>
            <?php else: ?>
            <span style="font-size:11px;color:var(--text2)">(Siz)</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Yeni Kullanıcı Modal -->
<div id="create-modal" class="modal-bg" onclick="if(event.target===this)this.classList.remove('open')">
  <div class="modal">
    <h3>Yeni Kullanıcı Oluştur</h3>
    <form method="post" action="?action=create_user" style="display:flex;flex-direction:column;gap:12px">
      <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
      <div class="form-group">
        <label>E-posta *</label>
        <input class="form-input" type="email" name="email" required placeholder="kullanici@domain.com">
      </div>
      <div class="form-group">
        <label>Ad Soyad</label>
        <input class="form-input" type="text" name="display_name" placeholder="Ad Soyad">
      </div>
      <div class="form-group">
        <label>Şifre * (min 8 karakter, harf+rakam)</label>
        <input class="form-input" type="password" name="password" required placeholder="••••••••">
      </div>
      <div class="form-group">
        <label>Rol</label>
        <select class="form-input" name="role">
          <option value="user">Kullanıcı</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-primary" style="flex:1">Oluştur</button>
        <button type="button" class="btn btn-ghost" onclick="document.getElementById('create-modal').classList.remove('open')">İptal</button>
      </div>
    </form>
  </div>
</div>
