<?php
if (!$pageData['isAdmin']) { header('Location: ?action=chat'); exit; }
$settings = [];
foreach ($db->fetchAll('SELECT setting_key, setting_value FROM app_settings') as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
$bm = new BackupManager();
$localInfo = $bm->getLocalPathInfo();
?>
<style>
#settings-wrap { flex:1; overflow-y:auto; padding:24px; }
.settings-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:900px; }
@media(max-width:700px){ .settings-grid { grid-template-columns:1fr; } }
.card { background:var(--bg2); border:1px solid var(--border); border-radius:10px; overflow:hidden; }
.card-head { padding:12px 16px; border-bottom:1px solid var(--border); font-size:13px; font-weight:600; }
.card-body { padding:16px; display:flex; flex-direction:column; gap:14px; }
.info-box { background:var(--bg3); border:1px solid var(--border); border-radius:8px; padding:12px; font-size:12px; color:var(--text2); line-height:1.6; }
.info-box code { font-family:var(--mono); background:rgba(0,0,0,.3); padding:2px 6px; border-radius:4px; color:var(--text); }
</style>

<div id="settings-wrap">
  <div style="margin-bottom:20px">
    <h2 style="font-size:18px;font-weight:600">⚙️ Sistem Ayarları</h2>
  </div>

  <div class="settings-grid">
    <!-- API & Model -->
    <div class="card" style="grid-column:1/-1">
      <div class="card-head">🤖 Groq API & Model Ayarları</div>
      <div class="card-body">
        <form method="post" action="?action=save_settings" style="display:flex;flex-direction:column;gap:14px">
          <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
          <div class="form-group">
            <label>Groq API Anahtarı</label>
            <input class="form-input" type="text" name="groq_api_key"
                   value="<?= Security::sanitize($settings['groq_api_key'] ?? '') ?>"
                   placeholder="gsk_...">
          </div>
          <div class="form-group">
            <label>Varsayılan Model</label>
            <select class="form-input" name="default_model">
              <?php $models=['llama-3.3-70b-versatile'=>'Llama 3.3 70B','llama-3.1-8b-instant'=>'Llama 3.1 8B','mixtral-8x7b-32768'=>'Mixtral 8x7B','gemma2-9b-it'=>'Gemma 2 9B']; ?>
              <?php foreach($models as $v=>$l): ?>
              <option value="<?=$v?>" <?=($settings['default_model']??'')===$v?'selected':''?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Sistem Promptu (Agent Kişiliği)</label>
            <textarea class="form-input" name="system_prompt" rows="5" style="resize:vertical"><?= Security::sanitize($settings['system_prompt'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="align-self:flex-start;padding:8px 20px">Kaydet</button>
        </form>
      </div>
    </div>

    <!-- Yedek Bilgisi -->
    <div class="card">
      <div class="card-head">📂 Yedekleme Bilgisi</div>
      <div class="card-body">
        <div class="info-box">
          <strong>Sunucu Tarafı Yedekler:</strong><br>
          <code><?= APP_ROOT ?>/backups/</code><br><br>
          <strong>Windows Hedef Klasör:</strong><br>
          <code><?= Security::sanitize($localInfo['path']) ?></code><br><br>
          <?= Security::sanitize($localInfo['note']) ?>
        </div>
        <?php
        $backupCount = $db->fetchOne("SELECT COUNT(*) as cnt FROM chat_backups")['cnt'] ?? 0;
        $userCount   = $db->fetchOne("SELECT COUNT(*) as cnt FROM users")['cnt'] ?? 0;
        ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div class="stat" style="background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:10px;text-align:center">
            <div style="font-size:22px;font-weight:700;color:var(--accent)"><?= $backupCount ?></div>
            <div style="font-size:11px;color:var(--text2)">toplam yedek</div>
          </div>
          <div class="stat" style="background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:10px;text-align:center">
            <div style="font-size:22px;font-weight:700;color:var(--success)"><?= $userCount ?></div>
            <div style="font-size:11px;color:var(--text2)">kayıtlı kullanıcı</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Güvenlik Durumu -->
    <div class="card">
      <div class="card-head">🔒 Güvenlik Durumu</div>
      <div class="card-body">
        <div class="info-box">
          ✅ Argon2id şifre hash<br>
          ✅ CSRF koruması<br>
          ✅ SQL injection önleme (PDO prepared statements)<br>
          ✅ XSS önleme (htmlspecialchars)<br>
          ✅ Brute-force koruması (<?= MAX_LOGIN_ATTEMPTS ?> deneme / 15 dk)<br>
          ✅ Session fixation koruması<br>
          ✅ Güvenli HTTP başlıkları<br>
          ✅ Content Security Policy
        </div>
        <?php
        $recentAttempts = $db->fetchOne(
            "SELECT COUNT(*) as cnt FROM login_attempts WHERE success=0 AND attempted_at > datetime('now','-1 hour')"
        )['cnt'] ?? 0;
        ?>
        <div style="font-size:12px;color:var(--text2)">
          Son 1 saatte başarısız giriş: <strong style="color:<?= $recentAttempts>10?'var(--danger)':'var(--success)' ?>"><?= $recentAttempts ?></strong>
        </div>
      </div>
    </div>
  </div>
</div>
