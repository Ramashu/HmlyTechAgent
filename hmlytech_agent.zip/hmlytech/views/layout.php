<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= APP_NAME ?></title>
<style>
:root {
  --bg:       #0f1117;
  --bg2:      #161b22;
  --bg3:      #1c2333;
  --border:   #30363d;
  --text:     #e6edf3;
  --text2:    #8b949e;
  --accent:   #58a6ff;
  --accent2:  #1f6feb;
  --success:  #3fb950;
  --danger:   #f85149;
  --warning:  #d29922;
  --radius:   8px;
  --font:     -apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  --mono:     'SF Mono','Fira Code','Cascadia Code',monospace;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; }
body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
}
a { color: var(--accent); text-decoration: none; }
a:hover { text-decoration: underline; }

/* NAV */
#nav {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 16px;
  height: 48px;
  background: var(--bg2);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
#nav .logo {
  font-size: 15px;
  font-weight: 600;
  color: var(--text);
  margin-right: 12px;
  display: flex;
  align-items: center;
  gap: 7px;
}
#nav .logo svg { width:22px; height:22px; }
.nav-link {
  padding: 5px 10px;
  font-size: 12px;
  color: var(--text2);
  border-radius: 6px;
  transition: all .15s;
  cursor: pointer;
  background: none;
  border: none;
  font-family: var(--font);
}
.nav-link:hover, .nav-link.active { background: var(--bg3); color: var(--text); }
.nav-right { margin-left: auto; display: flex; align-items: center; gap: 8px; }
.nav-user { font-size: 11px; color: var(--text2); }
.btn {
  padding: 5px 12px;
  font-size: 12px;
  border-radius: 6px;
  border: 1px solid var(--border);
  cursor: pointer;
  font-family: var(--font);
  font-weight: 500;
  transition: all .15s;
}
.btn-primary { background: var(--accent2); color: #fff; border-color: var(--accent2); }
.btn-primary:hover { background: #388bfd; }
.btn-ghost { background: transparent; color: var(--text2); }
.btn-ghost:hover { background: var(--bg3); color: var(--text); }
.btn-danger { background: transparent; color: var(--danger); border-color: var(--danger); }
.btn-danger:hover { background: rgba(248,81,73,.1); }
.btn-success { background: transparent; color: var(--success); border-color: var(--success); }
.btn-success:hover { background: rgba(63,185,80,.1); }

/* MAIN */
#main { flex: 1; overflow: hidden; display: flex; }

/* TOAST */
#toast-container {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.toast {
  padding: 10px 16px;
  border-radius: 8px;
  font-size: 13px;
  background: var(--bg3);
  border: 1px solid var(--border);
  color: var(--text);
  animation: slideIn .2s ease;
  max-width: 320px;
}
.toast.success { border-color: var(--success); color: var(--success); }
.toast.error   { border-color: var(--danger);  color: var(--danger);  }
@keyframes slideIn { from { opacity:0; transform:translateX(20px); } to { opacity:1; transform:none; } }

/* FORMS */
.form-group { display: flex; flex-direction: column; gap: 4px; }
.form-group label { font-size: 11px; color: var(--text2); font-weight: 500; }
.form-input {
  padding: 7px 10px;
  font-size: 13px;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  color: var(--text);
  font-family: var(--font);
  outline: none;
  transition: border .15s;
  width: 100%;
}
.form-input:focus { border-color: var(--accent); }
.form-input[type=password] { letter-spacing: .1em; }
select.form-input option { background: var(--bg2); }

/* TABLES */
.table { width: 100%; border-collapse: collapse; font-size: 13px; }
.table th { font-size: 11px; color: var(--text2); font-weight: 500; text-transform: uppercase; letter-spacing: .04em; padding: 8px 12px; border-bottom: 1px solid var(--border); text-align: left; }
.table td { padding: 8px 12px; border-bottom: 1px solid rgba(48,54,61,.5); vertical-align: middle; }
.table tr:last-child td { border-bottom: none; }
.table tr:hover td { background: rgba(48,54,61,.3); }

/* BADGES */
.badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 10px; font-weight: 500; }
.badge-admin   { background: rgba(88,166,255,.15); color: var(--accent); border: 1px solid rgba(88,166,255,.3); }
.badge-user    { background: rgba(139,148,158,.1); color: var(--text2); border: 1px solid var(--border); }
.badge-active  { background: rgba(63,185,80,.15); color: var(--success); border: 1px solid rgba(63,185,80,.3); }
.badge-inactive{ background: rgba(248,81,73,.1); color: var(--danger); border: 1px solid rgba(248,81,73,.3); }

/* SCROLLBAR */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #484f58; }
</style>
</head>
<body>

<?php if ($pageData['user']): ?>
<nav id="nav">
  <div class="logo">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--accent)">
      <path d="M12 2a10 10 0 0 1 10 10c0 5.52-4.48 10-10 10S2 17.52 2 12 6.48 2 12 2z"/>
      <path d="M8 12h8M12 8v8"/>
    </svg>
    <?= APP_NAME ?>
  </div>
  <a href="?action=chat"    class="nav-link <?= ($action==='chat')?'active':'' ?>">💬 Chat</a>
  <a href="?action=backups" class="nav-link <?= ($action==='backups')?'active':'' ?>">📂 Yedekler</a>
  <a href="?action=profile" class="nav-link <?= ($action==='profile')?'active':'' ?>">👤 Profil</a>
  <?php if ($pageData['isAdmin']): ?>
  <a href="?action=users"    class="nav-link <?= ($action==='users')?'active':'' ?>">👥 Kullanıcılar</a>
  <a href="?action=settings" class="nav-link <?= ($action==='settings')?'active':'' ?>">⚙️ Ayarlar</a>
  <?php endif; ?>
  <div class="nav-right">
    <span class="nav-user"><?= Security::sanitize($pageData['user']['display_name'] ?: $pageData['user']['email']) ?></span>
    <form method="post" action="?action=logout" style="display:inline">
      <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
      <button type="submit" class="btn btn-ghost">Çıkış</button>
    </form>
  </div>
</nav>
<?php endif; ?>

<div id="main">
<?= $content ?>
</div>

<div id="toast-container"></div>

<?php if (!empty($pageData['msg'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  showToast(<?= json_encode($pageData['msg']) ?>, 'success');
});
</script>
<?php endif; ?>

<script>
function showToast(msg, type='') {
  var c = document.getElementById('toast-container');
  var t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(function(){ t.remove(); }, 3500);
}
function confirmDelete(msg) { return confirm(msg || 'Silmek istediğinize emin misiniz?'); }
</script>
</body>
</html>
