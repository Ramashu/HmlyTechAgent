<?php
$bm = new BackupManager();
$result = $bm->listBackups($_SESSION['user_id']);
$backups = $result['backups'] ?? [];
?>
<style>
#backups-wrap { flex:1; overflow-y:auto; padding:24px; }
.card { background:var(--bg2); border:1px solid var(--border); border-radius:10px; overflow:hidden; }
.card-head { padding:12px 16px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
.card-head h2 { font-size:15px; font-weight:600; }
.empty-state { text-align:center; padding:48px; color:var(--text2); }
.empty-state .icon { font-size:48px; margin-bottom:12px; }
.backup-row { display:flex; align-items:center; gap:12px; padding:10px 16px; border-bottom:1px solid rgba(48,54,61,.4); }
.backup-row:last-child { border-bottom:none; }
.backup-row:hover { background:rgba(48,54,61,.2); }
.backup-icon { font-size:20px; flex-shrink:0; }
.backup-info { flex:1; min-width:0; }
.backup-title { font-size:13px; font-weight:500; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.backup-meta  { font-size:11px; color:var(--text2); margin-top:2px; }
.backup-actions { display:flex; gap:6px; flex-shrink:0; }
</style>

<div id="backups-wrap">
  <div style="margin-bottom:20px;display:flex;align-items:center;justify-content:space-between">
    <h2 style="font-size:18px;font-weight:600">📂 Konuşma Yedekleri</h2>
    <button class="btn btn-primary" onclick="window.location='?action=chat'">💬 Chat'e Dön</button>
  </div>

  <div class="card">
    <div class="card-head">
      <h2><?= count($backups) ?> yedek</h2>
      <span style="font-size:11px;color:var(--text2)">Sunucu ve veritabanında saklanır</span>
    </div>

    <?php if (empty($backups)): ?>
    <div class="empty-state">
      <div class="icon">📭</div>
      <p>Henüz yedeklenmiş konuşma yok.</p>
      <p style="font-size:12px;margin-top:8px">Chat ekranında "Kaydet" butonuna basarak konuşmaları yedekleyebilirsiniz.</p>
    </div>
    <?php else: ?>
    <?php foreach ($backups as $b): ?>
    <div class="backup-row">
      <div class="backup-icon">💬</div>
      <div class="backup-info">
        <div class="backup-title"><?= Security::sanitize($b['title']) ?></div>
        <div class="backup-meta">
          <?= Security::sanitize($b['model'] ?: 'Model bilinmiyor') ?> ·
          <?= substr($b['created_at'], 0, 16) ?> ·
          <?= round($b['size_bytes'] / 1024, 1) ?> KB
        </div>
      </div>
      <div class="backup-actions">
        <button class="btn btn-success" style="padding:4px 10px;font-size:11px"
                onclick="loadAndGoToChat(<?= $b['id'] ?>)">▶ Yükle</button>
        <form method="post" action="?action=delete_backup" style="display:inline"
              onsubmit="return confirmDelete('Bu yedeği silmek istediğinize emin misiniz?')">
          <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">
          <input type="hidden" name="backup_id" value="<?= $b['id'] ?>">
          <button type="button" class="btn btn-danger" style="padding:4px 10px;font-size:11px"
                  onclick="deleteBackupPage(<?= $b['id'] ?>)">✕</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<script>
function loadAndGoToChat(id) {
  sessionStorage.setItem('loadBackup', id);
  window.location = '?action=chat';
}

async function deleteBackupPage(id) {
  if (!confirmDelete('Bu yedeği silmek istediğinize emin misiniz?')) return;
  try {
    var r = await fetch('?action=delete_backup&id=' + id);
    var d = await r.json();
    if (d.success) { showToast('Yedek silindi', 'success'); setTimeout(function(){location.reload();}, 500); }
    else showToast(d.message || 'Hata', 'error');
  } catch(e) { showToast('Hata: ' + e.message, 'error'); }
}
</script>
