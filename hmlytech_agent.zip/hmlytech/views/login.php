<style>
#login-wrap {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg);
}
#login-box {
  width: 360px;
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 32px;
  display: flex;
  flex-direction: column;
  gap: 22px;
}
.login-logo {
  text-align: center;
}
.login-logo svg { width:40px; height:40px; color: var(--accent); }
.login-logo h1 { font-size: 20px; font-weight: 600; margin-top: 10px; }
.login-logo p  { font-size: 12px; color: var(--text2); margin-top: 4px; }
.login-form { display: flex; flex-direction: column; gap: 14px; }
.error-msg {
  font-size: 12px;
  color: var(--danger);
  background: rgba(248,81,73,.1);
  border: 1px solid rgba(248,81,73,.3);
  border-radius: 6px;
  padding: 8px 12px;
}
.login-footer {
  text-align: center;
  font-size: 11px;
  color: var(--text2);
}
</style>

<div id="login-wrap">
  <div id="login-box">
    <div class="login-logo">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 2a10 10 0 0 1 10 10c0 5.52-4.48 10-10 10S2 17.52 2 12 6.48 2 12 2z"/>
        <path d="M8 12h8M12 8v8"/>
      </svg>
      <h1><?= APP_NAME ?></h1>
      <p>Hesabınıza giriş yapın</p>
    </div>

    <?php if ($pageData['loginError']): ?>
    <div class="error-msg">⚠️ <?= Security::sanitize($pageData['loginError']) ?></div>
    <?php endif; ?>

    <form class="login-form" method="post" action="?action=do_login" autocomplete="on">
      <input type="hidden" name="csrf_token" value="<?= $pageData['csrf'] ?>">

      <div class="form-group">
        <label for="email">E-posta</label>
        <input class="form-input" type="email" id="email" name="email"
               placeholder="ornek@domain.com" required autocomplete="email">
      </div>

      <div class="form-group">
        <label for="password">Şifre</label>
        <input class="form-input" type="password" id="password" name="password"
               placeholder="••••••••" required autocomplete="current-password">
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;padding:9px;font-size:14px;">Giriş Yap</button>
    </form>

    <div class="login-footer">
      🔒 Güvenli bağlantı · <?= APP_VERSION ?>
    </div>
  </div>
</div>
