<?php
$settings = [];
foreach ($db->fetchAll('SELECT setting_key, setting_value FROM app_settings') as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
$apiKey      = $settings['groq_api_key']  ?? DEFAULT_API_KEY;
$defaultModel= $settings['default_model'] ?? DEFAULT_MODEL;
$sysPrompt   = $settings['system_prompt'] ?? '';
?>
<style>
#chat-wrap {
  display: flex;
  flex: 1;
  height: 100%;
  overflow: hidden;
}
/* SIDEBAR */
#sidebar {
  width: 240px;
  background: var(--bg2);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow: hidden;
}
#sidebar-head {
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
#sidebar-head span { font-size: 11px; color: var(--text2); font-weight: 500; text-transform: uppercase; letter-spacing: .05em; }
#backup-list {
  flex: 1;
  overflow-y: auto;
  padding: 6px;
}
.backup-item {
  padding: 7px 9px;
  border-radius: 6px;
  border: 1px solid var(--border);
  margin-bottom: 4px;
  cursor: pointer;
  background: var(--bg3);
  transition: all .15s;
  display: flex;
  align-items: center;
  gap: 6px;
}
.backup-item:hover { border-color: var(--accent); }
.backup-item .bi-title { font-size: 11px; color: var(--text); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.backup-item .bi-date  { font-size: 10px; color: var(--text2); flex-shrink: 0; }
.backup-item .bi-del   { font-size: 11px; color: var(--danger); opacity: 0; cursor: pointer; flex-shrink: 0; }
.backup-item:hover .bi-del { opacity: 1; }
#backup-empty { font-size: 12px; color: var(--text2); text-align: center; padding: 20px 10px; }

/* CHAT COLUMN */
#chat-col {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
/* TOPBAR */
#chat-topbar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 14px;
  border-bottom: 1px solid var(--border);
  background: var(--bg2);
  flex-shrink: 0;
}
#sdot {
  width: 8px; height: 8px; border-radius: 50%;
  background: #3fb950; flex-shrink: 0; transition: background .3s;
}
#sdot.thinking { background: var(--warning); animation: bpulse .9s infinite; }
@keyframes bpulse { 0%,100%{opacity:1} 50%{opacity:.3} }
#aname-label { font-size: 13px; font-weight: 500; }
#amode-label { font-size: 10px; color: var(--text2); }
.model-sel {
  padding: 4px 8px;
  font-size: 11px;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 6px;
  color: var(--text);
  cursor: pointer;
  font-family: var(--font);
}
.topbar-right { margin-left: auto; display: flex; gap: 6px; }

/* MESSAGES */
#msgs {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.msg { display: flex; gap: 10px; animation: msgUp .18s ease; max-width: 100%; }
@keyframes msgUp { from{opacity:0;transform:translateY(5px)} to{opacity:1;transform:none} }
.msg.user { flex-direction: row-reverse; }
.av {
  width: 28px; height: 28px; border-radius: 7px;
  display: flex; align-items: center; justify-content: center;
  font-size: 10px; font-weight: 600; flex-shrink: 0; margin-top: 2px;
}
.msg.user .av      { background: rgba(88,166,255,.2); color: var(--accent); border: 1px solid rgba(88,166,255,.3); }
.msg.assistant .av { background: var(--bg3); color: var(--text2); border: 1px solid var(--border); }
.bubble {
  max-width: 78%;
  padding: 10px 14px;
  font-size: 13px;
  line-height: 1.65;
  border-radius: 10px;
}
.msg.user .bubble      { background: rgba(88,166,255,.15); color: var(--text); border: 1px solid rgba(88,166,255,.25); border-radius: 10px 10px 3px 10px; }
.msg.assistant .bubble { background: var(--bg3); color: var(--text); border: 1px solid var(--border); border-radius: 10px 10px 10px 3px; }
.bubble code  { font-family: var(--mono); font-size: 11px; background: rgba(0,0,0,.3); padding: 1px 5px; border-radius: 4px; }
.bubble pre   { font-family: var(--mono); font-size: 11px; background: rgba(0,0,0,.4); padding: 10px; border-radius: 6px; overflow-x: auto; margin: 6px 0; white-space: pre-wrap; word-break: break-word; border: 1px solid var(--border); }
.msg-meta     { font-size: 10px; color: var(--text2); margin-top: 4px; opacity: .6; }
#cursor       { display: inline-block; width: 2px; height: 12px; background: var(--text); margin-left: 1px; vertical-align: middle; animation: cblink .7s infinite; }
@keyframes cblink { 0%,100%{opacity:1} 50%{opacity:0} }

/* STATS */
#srow {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 6px;
  padding: 8px 14px; border-top: 1px solid var(--border); flex-shrink: 0;
}
.stat { background: var(--bg3); border-radius: 6px; padding: 5px 8px; text-align: center; border: 1px solid var(--border); }
.sv { font-size: 13px; font-weight: 600; color: var(--text); }
.sl { font-size: 9px; color: var(--text2); margin-top: 1px; }

/* LEARNED BAR */
#lbar { padding: 5px 14px; border-top: 1px solid var(--border); background: rgba(31,111,235,.05); flex-shrink: 0; }
#ltxt { font-size: 10px; color: var(--text2); }

/* INPUT */
#inpbar { padding: 10px 14px; border-top: 1px solid var(--border); flex-shrink: 0; }
#inprow { display: flex; gap: 8px; align-items: flex-end; }
#inp {
  flex: 1; resize: none; border: 1px solid var(--border);
  border-radius: 8px; padding: 9px 12px; font-size: 13px;
  font-family: var(--font); min-height: 40px; max-height: 96px;
  background: var(--bg3); color: var(--text); outline: none; transition: border .15s;
}
#inp:focus { border-color: var(--accent); }
#sbtn {
  padding: 9px 16px; border: 1px solid var(--border); border-radius: 8px;
  font-size: 12px; font-weight: 600; cursor: pointer;
  background: var(--accent2); color: #fff; border-color: var(--accent2);
  white-space: nowrap; transition: all .15s;
}
#sbtn:hover:not(:disabled) { background: #388bfd; }
#sbtn:disabled { opacity: .35; cursor: not-allowed; }
#hint { font-size: 10px; color: var(--text2); margin-top: 3px; }

/* MEM PANEL */
#mem-panel {
  width: 200px; border-left: 1px solid var(--border);
  background: var(--bg2); flex-shrink: 0; display: none;
  flex-direction: column; overflow: hidden;
}
#mem-panel.open { display: flex; }
#mlist { flex: 1; overflow-y: auto; padding: 8px; }
.mi { padding: 6px 8px; border: 1px solid var(--border); border-radius: 6px; margin-bottom: 4px; background: var(--bg3); }
.mk { font-size: 10px; color: var(--text2); margin-bottom: 2px; }
.mv { font-size: 11px; color: var(--text); }
</style>

<div id="chat-wrap">
  <!-- Sol: Yedekler -->
  <div id="sidebar">
    <div id="sidebar-head">
      <span>📂 Yedekler</span>
      <button class="btn btn-ghost" onclick="saveConversation()" style="padding:3px 8px;font-size:11px;">Kaydet</button>
    </div>
    <div id="backup-list">
      <div id="backup-empty">Henüz yedek yok</div>
    </div>
  </div>

  <!-- Orta: Chat -->
  <div id="chat-col">
    <div id="chat-topbar">
      <div id="sdot"></div>
      <div>
        <div id="aname-label">HmlyTech Agent</div>
        <div id="amode-label">Hazır</div>
      </div>
      <select class="model-sel" id="modelsel" onchange="changeModel(this.value)">
        <option value="llama-3.3-70b-versatile" <?= $defaultModel==='llama-3.3-70b-versatile'?'selected':'' ?>>Llama 3.3 70B</option>
        <option value="llama-3.1-8b-instant"     <?= $defaultModel==='llama-3.1-8b-instant'?'selected':'' ?>>Llama 3.1 8B</option>
        <option value="mixtral-8x7b-32768"        <?= $defaultModel==='mixtral-8x7b-32768'?'selected':'' ?>>Mixtral 8x7B</option>
        <option value="gemma2-9b-it"              <?= $defaultModel==='gemma2-9b-it'?'selected':'' ?>>Gemma 2 9B</option>
      </select>
      <div class="topbar-right">
        <button class="btn btn-ghost" style="font-size:11px;padding:4px 9px" onclick="toggleMem()">🧠 Bellek</button>
        <button class="btn btn-ghost" style="font-size:11px;padding:4px 9px" onclick="resetChat()">↺ Sıfırla</button>
      </div>
    </div>

    <div id="msgs"></div>

    <div id="srow">
      <div class="stat"><div class="sv" id="s1">0</div><div class="sl">mesaj</div></div>
      <div class="stat"><div class="sv" id="s2">0</div><div class="sl">token</div></div>
      <div class="stat"><div class="sv" id="s3">0</div><div class="sl">öğrenilen</div></div>
      <div class="stat"><div class="sv" id="s4">—</div><div class="sl">son süre</div></div>
    </div>
    <div id="lbar"><div id="ltxt">Konuştukça bilgi biriktiriyorum...</div></div>
    <div id="inpbar">
      <div id="inprow">
        <textarea id="inp" placeholder="Mesajınızı yazın..." rows="1"></textarea>
        <button id="sbtn" onclick="send()">Gönder</button>
      </div>
      <div id="hint">Enter: gönder · Shift+Enter: yeni satır</div>
    </div>
  </div>

  <!-- Sağ: Bellek Paneli -->
  <div id="mem-panel">
    <div style="padding:8px 10px;border-bottom:1px solid var(--border);font-size:10px;color:var(--text2);text-transform:uppercase;letter-spacing:.05em">Öğrenilenler</div>
    <div id="mlist"><div style="font-size:12px;color:var(--text2);padding:16px;text-align:center">Henüz yok</div></div>
  </div>
</div>

<script>
var GROQ_KEY   = <?= json_encode($apiKey) ?>;
var SYS_PROMPT = <?= json_encode($sysPrompt) ?>;
var MODEL      = <?= json_encode($defaultModel) ?>;
var hist=[], mem=[], st={msg:0,tok:0,mem:0,dur:0}, busy=false;

// Öğrenme kalıpları
var PATTERNS=[
  {r:/benim adım ([^.,!?\n]{2,30})/i,k:"isim"},
  {r:/adım ([^.,!?\n]{2,20})/i,k:"isim"},
  {r:/(python|javascript|typescript|java|go|rust|c\+\+|swift|kotlin|php|ruby)/i,k:"dil"},
  {r:/(react|vue|angular|nextjs|django|flask|fastapi|laravel|spring)/i,k:"framework"},
  {r:/(istanbul|ankara|izmir|bursa|antalya|adana|konya|mersin)/i,k:"şehir"},
  {r:/([a-z]+) sektöründe/i,k:"sektör"},
  {r:/sevmiyorum[: ]+([^.,!?\n]{2,40})/i,k:"sevmediği"},
  {r:/seviyorum[: ]+([^.,!?\n]{2,40})/i,k:"sevdiği"},
  {r:/(yeni başlayanım|uzmanım|orta seviyeyim)/i,k:"seviye"},
  {r:/(öğretmen|mühendis|doktor|avukat|tasarımcı|yazılımcı|öğrenci)/i,k:"meslek"},
];

function esc(t){return(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function render(t){
  var s=esc(t);
  s=s.replace(/```(\w*)\n?([\s\S]*?)```/g,function(_,l,c){return'<pre>'+c.trim()+'</pre>';});
  s=s.replace(/`([^`\n]+)`/g,'<code>$1</code>');
  s=s.replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>');
  s=s.replace(/\*([^*\n]+)\*/g,'<em>$1</em>');
  s=s.replace(/\n/g,'<br>');
  return s;
}

function buildSystem(){
  var s=SYS_PROMPT||"Sen HmlyTech platformunun akıllı asistanısın. Çözüm odaklısın, özgün ve net yanıtlar verirsin.";
  if(mem.length>0){
    s+="\n\n[Kullanıcıdan öğrenilenler]\n";
    mem.forEach(function(m){s+="- "+m.k+": "+m.v+"\n";});
    s+="\nBu bilgileri doğal biçimde kullan.";
  }
  s+="\n\n[Kurallar]\n1. Kelime tekrarı yapma.\n2. Net ve çözüm odaklı ol.\n3. Gereksiz giriş cümlesi ekleme.";
  return s;
}

function addMsg(role,text,meta){
  var box=document.getElementById("msgs");
  var d=document.createElement("div");
  d.className="msg "+role;
  var m=meta?'<div class="msg-meta">'+esc(meta)+'</div>':"";
  d.innerHTML='<div class="av">'+(role==="user"?"Sen":"AI")+'</div><div><div class="bubble">'+render(text)+'</div>'+m+'</div>';
  box.appendChild(d);
  box.scrollTop=box.scrollHeight;
  return d;
}

function extract(user,asst){
  var res=[];
  var both=user+" "+asst;
  PATTERNS.forEach(function(p){
    var m=both.match(p.r);
    if(m){
      var v=(m[1]||m[0]).trim();
      if(v.length>1&&v.length<50&&!mem.find(function(x){return x.k===p.k;})){
        res.push({k:p.k,v:v});
      }
    }
  });
  return res;
}

function updateStats(){
  document.getElementById("s1").textContent=st.msg;
  document.getElementById("s2").textContent=st.tok>999?(st.tok/1000).toFixed(1)+"k":st.tok;
  document.getElementById("s3").textContent=st.mem;
  document.getElementById("s4").textContent=st.dur>0?st.dur+"ms":"—";
}

function updateMemPanel(){
  var l=document.getElementById("mlist");
  if(mem.length===0){l.innerHTML='<div style="font-size:12px;color:var(--text2);padding:16px;text-align:center">Henüz yok</div>';return;}
  l.innerHTML=mem.map(function(m){
    return'<div class="mi"><div class="mk">'+esc(m.k)+'</div><div class="mv">'+esc(m.v)+'</div></div>';
  }).join("");
}

function toggleMem(){
  document.getElementById("mem-panel").classList.toggle("open");
}

function changeModel(v){ MODEL=v; }

function resetChat(){
  if(!confirm("Sohbet geçmişini sıfırlamak istiyor musunuz?"))return;
  hist=[];mem=[];st={msg:0,tok:0,mem:0,dur:0};
  document.getElementById("msgs").innerHTML="";
  updateStats(); updateMemPanel();
  document.getElementById("ltxt").textContent="Sıfırlandı.";
  addMsg("assistant","Hafıza temizlendi. Sıfırdan başlayalım.");
}

async function send(){
  var inp=document.getElementById("inp");
  var text=inp.value.trim();
  if(!text||busy)return;
  inp.value=""; inp.style.height="auto";
  addMsg("user",text);
  hist.push({role:"user",content:text});
  busy=true;
  document.getElementById("sbtn").disabled=true;
  document.getElementById("sdot").className="thinking";
  document.getElementById("amode-label").textContent="düşünüyor...";

  var msgs=document.getElementById("msgs");
  var div=document.createElement("div");
  div.className="msg assistant";
  div.innerHTML='<div class="av">AI</div><div><div class="bubble" id="sb"></div></div>';
  msgs.appendChild(div);
  msgs.scrollTop=msgs.scrollHeight;

  var full="",t0=Date.now();
  try{
    var res=await fetch("https://api.groq.com/openai/v1/chat/completions",{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+GROQ_KEY},
      body:JSON.stringify({
        model:MODEL,
        messages:[{role:"system",content:buildSystem()}].concat(hist.slice(-14)),
        max_tokens:1024,
        temperature:0.72,
        stream:true
      })
    });
    if(!res.ok){var ed=await res.json().catch(function(){return{};});throw new Error(ed.error?.message||"Groq API hatası: HTTP "+res.status);}
    var reader=res.body.getReader(),dec=new TextDecoder(),buf="";
    while(true){
      var chunk=await reader.read();
      if(chunk.done)break;
      buf+=dec.decode(chunk.value,{stream:true});
      var lines=buf.split("\n"); buf=lines.pop();
      for(var i=0;i<lines.length;i++){
        var line=lines[i].trim();
        if(!line.startsWith("data:"))continue;
        var data=line.slice(5).trim();
        if(data==="[DONE]")continue;
        try{
          var ev=JSON.parse(data);
          var delta=ev.choices?.[0]?.delta?.content;
          if(delta){
            full+=delta;
            var b=document.getElementById("sb");
            if(b)b.innerHTML=render(full)+'<span id="cursor"></span>';
            msgs.scrollTop=msgs.scrollHeight;
          }
        }catch(e){}
      }
    }
    var b2=document.getElementById("sb");
    if(b2)b2.innerHTML=render(full);
    var dur=Date.now()-t0;
    var tok=Math.round(full.length/3.5+text.length/3.5);
    st.msg++;st.tok+=tok;st.dur=dur;
    var md=document.createElement("div"); md.className="msg-meta";
    md.textContent=tok+" token · "+dur+"ms · "+MODEL;
    if(div.children[1])div.children[1].appendChild(md);
    hist.push({role:"assistant",content:full});
    var learned=extract(text,full);
    if(learned.length>0){
      mem=mem.concat(learned);st.mem+=learned.length;
      document.getElementById("ltxt").textContent="Öğrenildi: "+learned.map(function(l){return l.k+" → "+l.v;}).join(", ");
      updateMemPanel();
    }
    updateStats();
  }catch(e){
    var b3=document.getElementById("sb");
    if(b3)b3.innerHTML='<span style="color:var(--danger)">'+esc(e.message)+'</span>';
    showToast(e.message,'error');
  }
  busy=false;
  document.getElementById("sbtn").disabled=false;
  document.getElementById("sdot").className="";
  document.getElementById("amode-label").textContent=MODEL;
  msgs.scrollTop=msgs.scrollHeight;
}

// Yedekleri yükle
async function loadBackups(){
  try{
    var r=await fetch("?action=load_backups");
    var d=await r.json();
    var list=document.getElementById("backup-list");
    var empty=document.getElementById("backup-empty");
    if(!d.backups||d.backups.length===0){
      if(empty)empty.style.display='block';
      return;
    }
    if(empty)empty.style.display='none';
    // clear existing items
    Array.from(list.querySelectorAll('.backup-item')).forEach(function(el){el.remove();});
    d.backups.forEach(function(b){
      var div=document.createElement("div");
      div.className="backup-item";
      div.innerHTML='<span class="bi-title">'+esc(b.title)+'</span>'
        +'<span class="bi-date">'+esc(b.created_at.substring(0,10))+'</span>'
        +'<span class="bi-del" onclick="deleteBackup(event,'+b.id+')" title="Sil">✕</span>';
      div.onclick=function(){loadBackup(b.id);};
      list.appendChild(div);
    });
  }catch(e){}
}

async function loadBackup(id){
  try{
    var r=await fetch("?action=load_backup&id="+id);
    var d=await r.json();
    if(!d.success||!d.backup){showToast("Yedek yüklenemedi","error");return;}
    hist=[];
    document.getElementById("msgs").innerHTML="";
    if(d.backup.model&&d.backup.model!==MODEL){
      MODEL=d.backup.model;
      document.getElementById("modelsel").value=MODEL;
    }
    var messages=d.backup.messages||[];
    messages.forEach(function(m){
      hist.push(m);
      addMsg(m.role,m.content);
    });
    showToast("Yedek yüklendi: "+d.backup.title,"success");
    st={msg:Math.floor(messages.length/2),tok:0,mem:st.mem,dur:0};
    updateStats();
  }catch(e){showToast("Hata: "+e.message,"error");}
}

async function deleteBackup(e,id){
  e.stopPropagation();
  if(!confirm("Bu yedeği silmek istediğinize emin misiniz?"))return;
  try{
    var r=await fetch("?action=delete_backup&id="+id);
    var d=await r.json();
    if(d.success){showToast("Yedek silindi","success");loadBackups();}
  }catch(e){}
}

async function saveConversation(){
  if(hist.length===0){showToast("Kaydedilecek konuşma yok","error");return;}
  try{
    var r=await fetch("?action=save_chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:hist,model:MODEL})
    });
    var d=await r.json();
    if(d.success){showToast("Kaydedildi: "+d.title,"success");loadBackups();}
    else showToast(d.message||"Kaydedilemedi","error");
  }catch(e){showToast("Hata: "+e.message,"error");}
}

document.addEventListener("DOMContentLoaded",function(){
  loadBackups();
  var inp=document.getElementById("inp");
  inp.addEventListener("keydown",function(e){
    if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}
  });
  inp.addEventListener("input",function(){
    this.style.height="auto";
    this.style.height=Math.min(this.scrollHeight,96)+"px";
  });
  addMsg("assistant","Merhaba! Ben HmlyTech Agent. Size nasıl yardımcı olabilirim?");
  inp.focus();
});
</script>
