<?php
/**
 * HmlyTech Agent - Ana Giriş Noktası
 * Güvenli PHP AI Agent Uygulaması
 */

define('APP_ROOT', __DIR__);
define('APP_VERSION', '2.0.0');

require_once APP_ROOT . '/config.php';
require_once APP_ROOT . '/includes/Database.php';
require_once APP_ROOT . '/includes/Auth.php';
require_once APP_ROOT . '/includes/Security.php';
require_once APP_ROOT . '/includes/BackupManager.php';

// Güvenlik başlıkları
Security::setSecurityHeaders();

// Oturum başlat
session_start([
    'cookie_httponly' => true,
    'cookie_secure'   => isset($_SERVER['HTTPS']),
    'cookie_samesite' => 'Strict',
    'gc_maxlifetime'  => SESSION_LIFETIME,
]);

// CSRF token oluştur
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = Security::generateToken();
}

$db   = Database::getInstance();
$auth = new Auth($db);

// Rota yönetimi
$action = $_GET['action'] ?? 'home';
$action = preg_replace('/[^a-z_]/', '', strtolower($action));

// API istekleri
if ($action === 'api') {
    require_once APP_ROOT . '/api.php';
    exit;
}

// Giriş yapılmamışsa login sayfasına yönlendir
if (!$auth->isLoggedIn() && $action !== 'login' && $action !== 'do_login') {
    header('Location: ?action=login');
    exit;
}

// POST işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrf($_POST['csrf_token'] ?? '');

    switch ($action) {
        case 'do_login':
            $result = $auth->login(
                Security::sanitize($_POST['email'] ?? ''),
                $_POST['password'] ?? '',
                $_SERVER['REMOTE_ADDR']
            );
            if ($result['success']) {
                header('Location: ?action=chat');
            } else {
                $loginError = $result['message'];
                $action = 'login';
            }
            break;

        case 'logout':
            $auth->logout();
            header('Location: ?action=login');
            exit;

        case 'save_chat':
            if ($auth->isLoggedIn()) {
                $bm = new BackupManager();
                echo json_encode($bm->saveConversation(
                    $_SESSION['user_id'],
                    $_SESSION['user_email'],
                    json_decode(file_get_contents('php://input'), true) ?? []
                ));
                exit;
            }
            break;

        case 'create_user':
            if ($auth->isAdmin()) {
                $result = $auth->createUser(
                    Security::sanitize($_POST['email'] ?? ''),
                    $_POST['password'] ?? '',
                    Security::sanitize($_POST['display_name'] ?? ''),
                    $_POST['role'] ?? 'user'
                );
                header('Location: ?action=users&msg=' . urlencode($result['message']));
                exit;
            }
            break;

        case 'change_password':
            if ($auth->isLoggedIn()) {
                $result = $auth->changePassword(
                    $_SESSION['user_id'],
                    $_POST['current_password'] ?? '',
                    $_POST['new_password'] ?? ''
                );
                header('Location: ?action=profile&msg=' . urlencode($result['message']));
                exit;
            }
            break;

        case 'delete_user':
            if ($auth->isAdmin()) {
                $uid = (int)($_POST['user_id'] ?? 0);
                $auth->deleteUser($uid);
                header('Location: ?action=users&msg=Kullanıcı+silindi');
                exit;
            }
            break;

        case 'save_settings':
            if ($auth->isAdmin()) {
                $db->query(
                    "UPDATE app_settings SET setting_value=? WHERE setting_key='groq_api_key'",
                    [Security::sanitize($_POST['groq_api_key'] ?? '')]
                );
                $db->query(
                    "UPDATE app_settings SET setting_value=? WHERE setting_key='default_model'",
                    [Security::sanitize($_POST['default_model'] ?? 'llama-3.3-70b-versatile')]
                );
                $db->query(
                    "UPDATE app_settings SET setting_value=? WHERE setting_key='system_prompt'",
                    [Security::sanitize($_POST['system_prompt'] ?? '')]
                );
                header('Location: ?action=settings&msg=Ayarlar+kaydedildi');
                exit;
            }
            break;
    }
}

// GET işlemleri
switch ($action) {
    case 'logout':
        $auth->logout();
        header('Location: ?action=login');
        exit;

    case 'load_backups':
        if ($auth->isLoggedIn()) {
            header('Content-Type: application/json');
            $bm = new BackupManager();
            echo json_encode($bm->listBackups($_SESSION['user_id']));
            exit;
        }
        break;

    case 'load_backup':
        if ($auth->isLoggedIn()) {
            header('Content-Type: application/json');
            $bm = new BackupManager();
            $id = (int)($_GET['id'] ?? 0);
            echo json_encode($bm->loadBackup($id, $_SESSION['user_id']));
            exit;
        }
        break;
    case 'delete_backup':
        if ($auth->isLoggedIn()) {
            header('Content-Type: application/json');
            $bm = new BackupManager();
            $id = (int)($_GET['id'] ?? 0);
            echo json_encode($bm->deleteBackup($id, $_SESSION['user_id']));
            exit;
        }
        break;
}

// Sayfa verisi hazırla
$pageData = [
    'user'       => $auth->getCurrentUser(),
    'isAdmin'    => $auth->isAdmin(),
    'csrf'       => $_SESSION['csrf_token'],
    'loginError' => $loginError ?? null,
    'msg'        => Security::sanitize($_GET['msg'] ?? ''),
];

// Sayfa yükle
ob_start();
$view = APP_ROOT . '/views/' . $action . '.php';
if (file_exists($view)) {
    include $view;
} else {
    include APP_ROOT . '/views/chat.php';
}
$content = ob_get_clean();

include APP_ROOT . '/views/layout.php';
