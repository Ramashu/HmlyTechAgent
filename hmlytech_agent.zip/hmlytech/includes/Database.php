<?php
/**
 * Veritabanı Sınıfı — SQLite (PDO)
 */
class Database {
    private static ?Database $instance = null;
    private PDO $pdo;

    private function __construct() {
        $this->pdo = new PDO('sqlite:' . DB_PATH, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $this->pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
        $this->initSchema();
    }

    public static function getInstance(): self {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initSchema(): void {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                email       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
                password    TEXT    NOT NULL,
                display_name TEXT   NOT NULL DEFAULT '',
                role        TEXT    NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
                is_active   INTEGER NOT NULL DEFAULT 1,
                created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
                last_login  TEXT
            );

            CREATE TABLE IF NOT EXISTS login_attempts (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                email       TEXT    NOT NULL,
                ip          TEXT    NOT NULL,
                attempted_at TEXT   NOT NULL DEFAULT (datetime('now')),
                success     INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS chat_backups (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title       TEXT    NOT NULL,
                messages    TEXT    NOT NULL,
                model       TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
                updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS app_settings (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                setting_key   TEXT NOT NULL UNIQUE,
                setting_value TEXT NOT NULL DEFAULT '',
                updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_login_attempts_email ON login_attempts(email);
            CREATE INDEX IF NOT EXISTS idx_login_attempts_ip    ON login_attempts(ip);
            CREATE INDEX IF NOT EXISTS idx_backups_user         ON chat_backups(user_id);
        ");

        // Varsayılan admin kullanıcısı
        $admin = $this->fetchOne('SELECT id FROM users WHERE email=?', ['admin@hmlytech.com']);
        if (!$admin) {
            $hash = password_hash('admin123', PASSWORD_ARGON2ID, ['memory_cost'=>65536,'time_cost'=>4,'threads'=>2]);
            $this->query(
                "INSERT INTO users (email, password, display_name, role) VALUES (?,?,?,?)",
                ['admin@hmlytech.com', $hash, 'Admin', 'admin']
            );
        }

        // Varsayılan ayarlar
        $settings = [
            'groq_api_key'  => DEFAULT_API_KEY,
            'default_model' => DEFAULT_MODEL,
            'system_prompt' => "Sen HmlyTech platformunun akıllı asistanısın. Her konuşmadan öğrenirsin. Çözüm odaklısın, gereksiz kelime tekrarı yapmazsın, özgün ve net yanıtlar verirsin.",
        ];
        foreach ($settings as $k => $v) {
            $existing = $this->fetchOne('SELECT id FROM app_settings WHERE setting_key=?', [$k]);
            if (!$existing) {
                $this->query('INSERT INTO app_settings (setting_key, setting_value) VALUES (?,?)', [$k, $v]);
            }
        }
    }

    public function query(string $sql, array $params = []): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetchOne(string $sql, array $params = []): ?array {
        $r = $this->query($sql, $params)->fetch();
        return $r ?: null;
    }

    public function fetchAll(string $sql, array $params = []): array {
        return $this->query($sql, $params)->fetchAll();
    }

    public function lastInsertId(): int {
        return (int)$this->pdo->lastInsertId();
    }
}
