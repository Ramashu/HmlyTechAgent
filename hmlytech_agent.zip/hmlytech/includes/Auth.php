<?php
/**
 * Kimlik Doğrulama Sınıfı
 */
class Auth {
    private Database $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function login(string $email, string $password, string $ip): array {
        if (!Security::validateEmail($email)) {
            return ['success' => false, 'message' => 'Geçersiz e-posta adresi.'];
        }

        if (!Security::rateLimit($this->db, $email, $ip)) {
            Security::logAttempt($this->db, $email, $ip, false);
            return ['success' => false, 'message' => 'Çok fazla başarısız giriş denemesi. 15 dakika bekleyin.'];
        }

        $user = $this->db->fetchOne(
            'SELECT * FROM users WHERE email=? AND is_active=1',
            [$email]
        );

        if (!$user || !password_verify($password, $user['password'])) {
            Security::logAttempt($this->db, $email, $ip, false);
            // Timing attack koruması
            password_verify('dummy', '$2y$10$dummyhashtopreventtimingattacks00000000000000000000000000');
            return ['success' => false, 'message' => 'E-posta veya şifre hatalı.'];
        }

        Security::logAttempt($this->db, $email, $ip, true);

        // Oturumu yenile (session fixation koruması)
        session_regenerate_id(true);

        $_SESSION['user_id']    = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_name']  = $user['display_name'];
        $_SESSION['user_role']  = $user['role'];
        $_SESSION['login_time'] = time();

        // Son giriş güncelle
        $this->db->query(
            "UPDATE users SET last_login=datetime('now') WHERE id=?",
            [$user['id']]
        );

        return ['success' => true];
    }

    public function logout(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']
            );
        }
        session_destroy();
    }

    public function isLoggedIn(): bool {
        if (empty($_SESSION['user_id'])) return false;
        // Oturum süresi kontrolü
        if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > SESSION_LIFETIME) {
            $this->logout();
            return false;
        }
        return true;
    }

    public function isAdmin(): bool {
        return $this->isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
    }

    public function getCurrentUser(): ?array {
        if (!$this->isLoggedIn()) return null;
        return $this->db->fetchOne('SELECT id,email,display_name,role,created_at,last_login FROM users WHERE id=?', [$_SESSION['user_id']]);
    }

    public function createUser(string $email, string $password, string $displayName, string $role): array {
        if (!Security::validateEmail($email)) {
            return ['success' => false, 'message' => 'Geçersiz e-posta adresi.'];
        }
        $pwCheck = Security::validatePassword($password);
        if (!$pwCheck['valid']) {
            return ['success' => false, 'message' => $pwCheck['message']];
        }
        $role = in_array($role, ['admin','user']) ? $role : 'user';

        $existing = $this->db->fetchOne('SELECT id FROM users WHERE email=?', [$email]);
        if ($existing) {
            return ['success' => false, 'message' => 'Bu e-posta zaten kayıtlı.'];
        }

        $hash = password_hash($password, PASSWORD_ARGON2ID, ['memory_cost'=>65536,'time_cost'=>4,'threads'=>2]);
        $this->db->query(
            'INSERT INTO users (email, password, display_name, role) VALUES (?,?,?,?)',
            [$email, $hash, $displayName ?: $email, $role]
        );
        return ['success' => true, 'message' => 'Kullanıcı oluşturuldu.'];
    }

    public function changePassword(int $userId, string $currentPassword, string $newPassword): array {
        $user = $this->db->fetchOne('SELECT * FROM users WHERE id=?', [$userId]);
        if (!$user || !password_verify($currentPassword, $user['password'])) {
            return ['success' => false, 'message' => 'Mevcut şifre hatalı.'];
        }
        $pwCheck = Security::validatePassword($newPassword);
        if (!$pwCheck['valid']) {
            return $pwCheck;
        }
        $hash = password_hash($newPassword, PASSWORD_ARGON2ID, ['memory_cost'=>65536,'time_cost'=>4,'threads'=>2]);
        $this->db->query('UPDATE users SET password=? WHERE id=?', [$hash, $userId]);
        return ['success' => true, 'message' => 'Şifre başarıyla değiştirildi.'];
    }

    public function getAllUsers(): array {
        return $this->db->fetchAll('SELECT id,email,display_name,role,is_active,created_at,last_login FROM users ORDER BY id');
    }

    public function deleteUser(int $userId): void {
        // Admin kendini silemez
        if ($userId === ($_SESSION['user_id'] ?? 0)) return;
        $this->db->query('DELETE FROM users WHERE id=?', [$userId]);
    }

    public function toggleUser(int $userId): void {
        if ($userId === ($_SESSION['user_id'] ?? 0)) return;
        $this->db->query('UPDATE users SET is_active = CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?', [$userId]);
    }
}
