<?php
/**
 * Yedekleme Yöneticisi
 * Yazışmaları veritabanında ve yerel klasörde saklar
 */
class BackupManager {
    private Database $db;
    // Windows bilgisayarındaki hedef klasör (UNC / mapped drive veya web sunucusu Windows'ta çalışıyorsa)
    private string $localPath = 'C:\\Users\\User\\Desktop\\HmlyTech Agent';

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function saveConversation(int $userId, string $userEmail, array $data): array {
        $messages = $data['messages'] ?? [];
        $model    = Security::sanitize($data['model'] ?? '');
        $title    = $this->generateTitle($messages);

        if (empty($messages)) {
            return ['success' => false, 'message' => 'Boş konuşma.'];
        }

        $json = json_encode($messages, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        // Veritabanına kaydet
        $this->db->query(
            "INSERT INTO chat_backups (user_id, title, messages, model) VALUES (?,?,?,?)",
            [$userId, $title, $json, $model]
        );
        $backupId = $this->db->lastInsertId();

        // Sunucu tarafı yedek dosyası oluştur
        $filename = $this->saveToFile($userEmail, $title, $json, $backupId);

        return [
            'success'   => true,
            'backup_id' => $backupId,
            'title'     => $title,
            'filename'  => $filename,
            'message'   => 'Konuşma yedeklendi.',
        ];
    }

    private function saveToFile(string $userEmail, string $title, string $json, int $id): string {
        // Sunucu yedeği
        $serverDir = BACKUP_DIR . '/' . preg_replace('/[^a-z0-9_]/', '_', strtolower($userEmail));
        if (!is_dir($serverDir)) mkdir($serverDir, 0750, true);

        $filename = date('Y-m-d_His') . '_' . $id . '.json';
        $filepath = $serverDir . '/' . $filename;

        $content = json_encode([
            'backup_id'  => $id,
            'user'       => $userEmail,
            'title'      => $title,
            'saved_at'   => date('c'),
            'local_path' => $this->localPath,
            'messages'   => json_decode($json, true),
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        file_put_contents($filepath, $content, LOCK_EX);
        return $filename;
    }

    public function listBackups(int $userId): array {
        $rows = $this->db->fetchAll(
            "SELECT id, title, model, created_at, updated_at,
                    LENGTH(messages) as size_bytes
             FROM chat_backups WHERE user_id=? ORDER BY created_at DESC LIMIT 100",
            [$userId]
        );
        return ['success' => true, 'backups' => $rows];
    }

    public function loadBackup(int $backupId, int $userId): array {
        $row = $this->db->fetchOne(
            'SELECT * FROM chat_backups WHERE id=? AND user_id=?',
            [$backupId, $userId]
        );
        if (!$row) {
            return ['success' => false, 'message' => 'Yedek bulunamadı.'];
        }
        return [
            'success'  => true,
            'backup'   => [
                'id'         => $row['id'],
                'title'      => $row['title'],
                'model'      => $row['model'],
                'created_at' => $row['created_at'],
                'messages'   => json_decode($row['messages'], true),
            ],
        ];
    }

    public function deleteBackup(int $backupId, int $userId): array {
        $row = $this->db->fetchOne(
            'SELECT id FROM chat_backups WHERE id=? AND user_id=?',
            [$backupId, $userId]
        );
        if (!$row) {
            return ['success' => false, 'message' => 'Yedek bulunamadı.'];
        }
        $this->db->query('DELETE FROM chat_backups WHERE id=?', [$backupId]);
        return ['success' => true, 'message' => 'Yedek silindi.'];
    }

    private function generateTitle(array $messages): string {
        foreach ($messages as $m) {
            if (($m['role'] ?? '') === 'user' && !empty($m['content'])) {
                $t = mb_substr(strip_tags($m['content']), 0, 60);
                return $t ?: 'Konuşma';
            }
        }
        return 'Konuşma ' . date('d.m.Y H:i');
    }

    public function getLocalPathInfo(): array {
        return [
            'path'    => $this->localPath,
            'note'    => 'Web sunucusu Windows\'ta çalışıyorsa bu klasöre otomatik yazar. Linux/Mac sunucuda sunucu tarafı yedekler /backups/ altında saklanır.',
        ];
    }
}
