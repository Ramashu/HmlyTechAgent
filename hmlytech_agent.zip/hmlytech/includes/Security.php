<?php
/**
 * Güvenlik Yardımcı Sınıfı
 */
class Security {

    public static function setSecurityHeaders(): void {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self' https://api.groq.com; img-src 'self' data:;");
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    }

    public static function generateToken(int $length = 32): string {
        return bin2hex(random_bytes($length));
    }

    public static function verifyCsrf(string $token): void {
        if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            http_response_code(403);
            die('Güvenlik hatası: Geçersiz CSRF token.');
        }
    }

    public static function sanitize(string $input): string {
        return htmlspecialchars(trim($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    public static function validateEmail(string $email): bool {
        return (bool)filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function validatePassword(string $password): array {
        if (strlen($password) < 8) {
            return ['valid' => false, 'message' => 'Şifre en az 8 karakter olmalıdır.'];
        }
        if (!preg_match('/[A-Za-z]/', $password)) {
            return ['valid' => false, 'message' => 'Şifre en az bir harf içermelidir.'];
        }
        if (!preg_match('/[0-9]/', $password)) {
            return ['valid' => false, 'message' => 'Şifre en az bir rakam içermelidir.'];
        }
        return ['valid' => true, 'message' => ''];
    }

    public static function rateLimit(Database $db, string $email, string $ip): bool {
        // Son 15 dakikadaki başarısız giriş sayısını kontrol et
        $attempts = $db->fetchOne(
            "SELECT COUNT(*) as cnt FROM login_attempts
             WHERE (email=? OR ip=?) AND success=0
             AND attempted_at > datetime('now', '-15 minutes')",
            [$email, $ip]
        );
        return (int)($attempts['cnt'] ?? 0) < MAX_LOGIN_ATTEMPTS;
    }

    public static function logAttempt(Database $db, string $email, string $ip, bool $success): void {
        $db->query(
            "INSERT INTO login_attempts (email, ip, success) VALUES (?,?,?)",
            [$email, $ip, $success ? 1 : 0]
        );
        // Eski kayıtları temizle (1 gün öncesi)
        $db->query("DELETE FROM login_attempts WHERE attempted_at < datetime('now', '-1 day')");
    }
}
