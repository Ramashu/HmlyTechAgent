from fastapi import APIRouter, Depends
from app.core.security import get_current_user
from app.services.tools_service import execute_tool

router = APIRouter()

AVAILABLE_TOOLS = [
    {
        "type": "http_request",
        "name": "HTTP Request",
        "description": "Make HTTP requests to external APIs",
        "config_schema": {
            "url": {"type": "string", "required": True},
            "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE"], "default": "GET"},
        },
    },
    {
        "type": "web_search",
        "name": "Web Search",
        "description": "Search the web for information using DuckDuckGo",
        "config_schema": {
            "query": {"type": "string", "required": True},
        },
    },
    {
        "type": "calculator",
        "name": "Calculator",
        "description": "Perform mathematical calculations",
        "config_schema": {
            "expression": {"type": "string", "required": True},
        },
    },
]


@router.get("")
async def list_tools(current_user=Depends(get_current_user)):
    return {"tools": AVAILABLE_TOOLS}


@router.post("/test")
async def test_tool(
    tool_name: str,
    args: dict,
    current_user=Depends(get_current_user),
):
    result = await execute_tool(tool_name, args)
    return {"tool": tool_name, "result": result}
