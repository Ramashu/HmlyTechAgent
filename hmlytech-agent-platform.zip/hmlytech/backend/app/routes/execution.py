from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.agent import Agent, Execution
from app.models.user import User
from app.schemas.agent import AgentRunRequest, AgentRunResponse, ExecutionResponse
from app.services.execution_service import run_agent, stream_agent
from app.services.memory_service import get_session_history, format_history_for_llm

router = APIRouter()


async def get_agent_for_execution(agent_id: int, db: AsyncSession) -> Agent:
    result = await db.execute(
        select(Agent).where(Agent.id == agent_id, Agent.is_active == True)
    )
    agent = result.scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.post("/{agent_id}/run", response_model=AgentRunResponse)
async def run(
    agent_id: int,
    data: AgentRunRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await get_agent_for_execution(agent_id, db)

    if agent.owner_id != current_user.id and not agent.is_public:
        raise HTTPException(status_code=403, detail="Access denied")

    history = []
    if data.session_id:
        memories = await get_session_history(db, data.session_id)
        history = await format_history_for_llm(memories)

    if data.conversation_history:
        history = data.conversation_history

    result = await run_agent(agent, data.input, history, data.session_id)
    result["agent_id"] = agent_id

    return AgentRunResponse(**result)


@router.post("/{agent_id}/stream")
async def stream(
    agent_id: int,
    data: AgentRunRequest,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await get_agent_for_execution(agent_id, db)

    if agent.owner_id != current_user.id and not agent.is_public:
        raise HTTPException(status_code=403, detail="Access denied")

    history = []
    if data.session_id:
        memories = await get_session_history(db, data.session_id)
        history = await format_history_for_llm(memories)

    return StreamingResponse(
        stream_agent(agent, data.input, history, data.session_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/{agent_id}/run/public", response_model=AgentRunResponse)
async def run_public(
    agent_id: int,
    data: AgentRunRequest,
    x_api_key: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
):
    agent = await get_agent_for_execution(agent_id, db)

    user = None
    if x_api_key:
        result = await db.execute(select(User).where(User.api_key == x_api_key))
        user = result.scalar_one_or_none()

    if not agent.is_public and (not user or agent.owner_id != user.id):
        raise HTTPException(status_code=403, detail="Access denied")

    result = await run_agent(agent, data.input, data.conversation_history, data.session_id)
    result["agent_id"] = agent_id

    return AgentRunResponse(**result)


@router.get("/{agent_id}/executions")
async def get_executions(
    agent_id: int,
    limit: int = 20,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await get_agent_for_execution(agent_id, db)
    if agent.owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")

    result = await db.execute(
        select(Execution)
        .where(Execution.agent_id == agent_id)
        .order_by(Execution.created_at.desc())
        .limit(limit)
    )
    executions = result.scalars().all()
    return [ExecutionResponse.model_validate(e) for e in executions]
