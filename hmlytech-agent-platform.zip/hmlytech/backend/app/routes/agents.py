from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.core.database import get_db
from app.core.security import get_current_user
from app.schemas.agent import AgentCreate, AgentUpdate, AgentResponse, AgentVersionResponse
from app.services.agent_service import (
    create_agent, get_agent, list_agents, update_agent,
    delete_agent, get_agent_versions, get_user_stats,
)

router = APIRouter()


@router.post("", response_model=AgentResponse, status_code=201)
async def create(
    data: AgentCreate,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await create_agent(data, current_user, db)
    return AgentResponse.model_validate(agent)


@router.get("", response_model=List[AgentResponse])
async def list_all(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agents = await list_agents(current_user, db, skip=skip, limit=limit)
    return [AgentResponse.model_validate(a) for a in agents]


@router.get("/stats")
async def get_stats(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await get_user_stats(current_user, db)


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_one(
    agent_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await get_agent(agent_id, current_user, db)
    return AgentResponse.model_validate(agent)


@router.put("/{agent_id}", response_model=AgentResponse)
async def update(
    agent_id: int,
    data: AgentUpdate,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    agent = await update_agent(agent_id, data, current_user, db)
    return AgentResponse.model_validate(agent)


@router.delete("/{agent_id}")
async def delete(
    agent_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await delete_agent(agent_id, current_user, db)
    return {"message": "Agent deleted successfully"}


@router.get("/{agent_id}/versions", response_model=List[AgentVersionResponse])
async def get_versions(
    agent_id: int,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    versions = await get_agent_versions(agent_id, current_user, db)
    return [AgentVersionResponse.model_validate(v) for v in versions]
