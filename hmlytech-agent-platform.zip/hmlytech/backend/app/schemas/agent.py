from pydantic import BaseModel, field_validator
from typing import Optional, List, Any, Dict
from datetime import datetime


SUPPORTED_MODELS = [
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gpt-3.5-turbo",
    "claude-3-5-sonnet-20241022",
    "claude-3-haiku-20240307",
    "claude-opus-4-5",
]


class ToolConfig(BaseModel):
    name: str
    type: str
    description: str
    config: Dict[str, Any] = {}


class AgentCreate(BaseModel):
    name: str
    description: Optional[str] = None
    goal: Optional[str] = None
    system_prompt: str = "You are a helpful AI assistant."
    model: str = "gpt-4o"
    tools: List[Dict[str, Any]] = []
    temperature: float = 0.7
    max_tokens: int = 2048
    is_public: bool = False
    tags: List[str] = []

    @field_validator("model")
    @classmethod
    def validate_model(cls, v):
        if v not in SUPPORTED_MODELS:
            raise ValueError(f"Model must be one of: {', '.join(SUPPORTED_MODELS)}")
        return v

    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v):
        if not 0.0 <= v <= 2.0:
            raise ValueError("Temperature must be between 0.0 and 2.0")
        return v

    @field_validator("name")
    @classmethod
    def validate_name(cls, v):
        if len(v.strip()) < 2:
            raise ValueError("Agent name must be at least 2 characters")
        return v.strip()


class AgentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    goal: Optional[str] = None
    system_prompt: Optional[str] = None
    model: Optional[str] = None
    tools: Optional[List[Dict[str, Any]]] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    is_public: Optional[bool] = None
    tags: Optional[List[str]] = None


class AgentVersionResponse(BaseModel):
    id: int
    version: int
    system_prompt: str
    model: str
    tools: List[Dict[str, Any]]
    temperature: float
    max_tokens: int
    created_at: datetime

    model_config = {"from_attributes": True}


class AgentResponse(BaseModel):
    id: int
    owner_id: int
    name: str
    description: Optional[str]
    goal: Optional[str]
    system_prompt: str
    model: str
    tools: List[Dict[str, Any]]
    temperature: float
    max_tokens: int
    is_public: bool
    is_active: bool
    version: int
    tags: List[str]
    total_runs: int
    total_tokens_used: int
    created_at: datetime
    updated_at: Optional[datetime]

    model_config = {"from_attributes": True}


class AgentRunRequest(BaseModel):
    input: str
    session_id: Optional[str] = None
    stream: bool = False
    conversation_history: Optional[List[Dict[str, str]]] = None

    @field_validator("input")
    @classmethod
    def validate_input(cls, v):
        if not v.strip():
            raise ValueError("Input cannot be empty")
        if len(v) > 50000:
            raise ValueError("Input too long (max 50,000 characters)")
        return v


class AgentRunResponse(BaseModel):
    output: str
    agent_id: int
    session_id: str
    tokens_used: int
    duration_ms: int
    tool_calls: List[Dict[str, Any]] = []
    model: str


class ExecutionResponse(BaseModel):
    id: int
    agent_id: int
    input_text: str
    output_text: Optional[str]
    tokens_used: int
    duration_ms: int
    status: str
    tool_calls: List[Dict[str, Any]]
    created_at: datetime

    model_config = {"from_attributes": True}
