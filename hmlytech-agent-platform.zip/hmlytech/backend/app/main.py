from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager
import logging

from app.core.config import settings
from app.core.database import engine, Base
from app.routes import auth, agents, execution, tools, memory

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting HmlyTech Agent Platform...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created/verified.")
    yield
    logger.info("Shutting down...")


app = FastAPI(
    title="HmlyTech Agent API",
    description="AI Agent Platform - Create, manage and deploy AI agents",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(agents.router, prefix="/api/agents", tags=["Agents"])
app.include_router(execution.router, prefix="/api/agent", tags=["Execution"])
app.include_router(tools.router, prefix="/api/tools", tags=["Tools"])
app.include_router(memory.router, prefix="/api/memory", tags=["Memory"])


@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.0.0", "platform": "HmlyTech Agent"}
