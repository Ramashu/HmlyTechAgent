import httpx
import json
from typing import Any, Dict


async def execute_tool(tool_name: str, args: Dict[str, Any]) -> Any:
    if tool_name == "http_request":
        return await http_request_tool(args)
    elif tool_name == "web_search":
        return await web_search_tool(args)
    elif tool_name == "calculator":
        return calculator_tool(args)
    else:
        return {"error": f"Unknown tool: {tool_name}"}


async def http_request_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    url = args.get("url")
    method = args.get("method", "GET").upper()
    body = args.get("body")
    headers = args.get("headers", {})

    if not url:
        return {"error": "URL is required"}

    try:
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            if method == "GET":
                response = await client.get(url, headers=headers)
            elif method == "POST":
                payload = json.loads(body) if body else {}
                response = await client.post(url, json=payload, headers=headers)
            elif method == "PUT":
                payload = json.loads(body) if body else {}
                response = await client.put(url, json=payload, headers=headers)
            elif method == "DELETE":
                response = await client.delete(url, headers=headers)
            else:
                return {"error": f"Unsupported method: {method}"}

            try:
                result_body = response.json()
            except Exception:
                result_body = response.text[:2000]

            return {
                "status_code": response.status_code,
                "body": result_body,
                "headers": dict(response.headers),
            }
    except httpx.TimeoutException:
        return {"error": "Request timed out"}
    except Exception as e:
        return {"error": str(e)}


async def web_search_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    query = args.get("query", "")
    if not query:
        return {"error": "Query is required"}

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                "https://api.duckduckgo.com/",
                params={"q": query, "format": "json", "no_html": "1"},
            )
            data = response.json()
            results = []

            if data.get("AbstractText"):
                results.append({
                    "title": data.get("Heading", ""),
                    "snippet": data["AbstractText"],
                    "url": data.get("AbstractURL", ""),
                })

            for topic in data.get("RelatedTopics", [])[:3]:
                if isinstance(topic, dict) and topic.get("Text"):
                    results.append({
                        "title": topic.get("Text", "")[:100],
                        "snippet": topic.get("Text", ""),
                        "url": topic.get("FirstURL", ""),
                    })

            return {"query": query, "results": results[:5]}
    except Exception as e:
        return {"query": query, "results": [], "error": str(e)}


def calculator_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    expression = args.get("expression", "")
    if not expression:
        return {"error": "Expression is required"}

    allowed_chars = set("0123456789+-*/()., ")
    if not all(c in allowed_chars for c in expression):
        return {"error": "Invalid expression - only basic math operations allowed"}

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return {"expression": expression, "result": result}
    except Exception as e:
        return {"error": f"Calculation error: {str(e)}"}
