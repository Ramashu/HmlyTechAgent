from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from fastapi import HTTPException
from typing import List, Optional

from app.models.agent import Agent, AgentVersion
from app.models.user import User
from app.schemas.agent import AgentCreate, AgentUpdate


async def create_agent(data: AgentCreate, user: User, db: AsyncSession) -> Agent:
    agent = Agent(
        owner_id=user.id,
        name=data.name,
        description=data.description,
        goal=data.goal,
        system_prompt=data.system_prompt,
        model=data.model,
        tools=data.tools,
        temperature=data.temperature,
        max_tokens=data.max_tokens,
        is_public=data.is_public,
        tags=data.tags,
        version=1,
    )
    db.add(agent)
    await db.flush()

    version = AgentVersion(
        agent_id=agent.id,
        version=1,
        system_prompt=data.system_prompt,
        model=data.model,
        tools=data.tools,
        temperature=data.temperature,
        max_tokens=data.max_tokens,
    )
    db.add(version)
    await db.flush()
    await db.refresh(agent)
    return agent


async def get_agent(agent_id: int, user: User, db: AsyncSession) -> Agent:
    result = await db.execute(select(Agent).where(Agent.id == agent_id))
    agent = result.scalar_one_or_none()

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    if agent.owner_id != user.id and not agent.is_public:
        raise HTTPException(status_code=403, detail="Access denied")

    return agent


async def get_agent_public(agent_id: int, db: AsyncSession) -> Agent:
    result = await db.execute(select(Agent).where(Agent.id == agent_id, Agent.is_active == True))
    agent = result.scalar_one_or_none()

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    return agent


async def list_agents(user: User, db: AsyncSession, skip: int = 0, limit: int = 50) -> List[Agent]:
    result = await db.execute(
        select(Agent)
        .where(Agent.owner_id == user.id, Agent.is_active == True)
        .order_by(Agent.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    return list(result.scalars().all())


async def update_agent(agent_id: int, data: AgentUpdate, user: User, db: AsyncSession) -> Agent:
    agent = await get_agent(agent_id, user, db)

    if agent.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Not your agent")

    update_data = data.model_dump(exclude_none=True)

    if any(k in update_data for k in ["system_prompt", "model", "tools", "temperature", "max_tokens"]):
        agent.version += 1
        version = AgentVersion(
            agent_id=agent.id,
            version=agent.version,
            system_prompt=update_data.get("system_prompt", agent.system_prompt),
            model=update_data.get("model", agent.model),
            tools=update_data.get("tools", agent.tools),
            temperature=update_data.get("temperature", agent.temperature),
            max_tokens=update_data.get("max_tokens", agent.max_tokens),
        )
        db.add(version)

    for key, value in update_data.items():
        setattr(agent, key, value)

    await db.flush()
    await db.refresh(agent)
    return agent


async def delete_agent(agent_id: int, user: User, db: AsyncSession) -> bool:
    agent = await get_agent(agent_id, user, db)

    if agent.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Not your agent")

    agent.is_active = False
    await db.flush()
    return True


async def get_agent_versions(agent_id: int, user: User, db: AsyncSession) -> list:
    await get_agent(agent_id, user, db)

    result = await db.execute(
        select(AgentVersion)
        .where(AgentVersion.agent_id == agent_id)
        .order_by(AgentVersion.version.desc())
    )
    return list(result.scalars().all())


async def get_user_stats(user: User, db: AsyncSession) -> dict:
    agent_count = await db.execute(
        select(func.count(Agent.id)).where(Agent.owner_id == user.id, Agent.is_active == True)
    )
    total_runs = await db.execute(
        select(func.sum(Agent.total_runs)).where(Agent.owner_id == user.id)
    )
    total_tokens = await db.execute(
        select(func.sum(Agent.total_tokens_used)).where(Agent.owner_id == user.id)
    )

    return {
        "total_agents": agent_count.scalar() or 0,
        "total_runs": total_runs.scalar() or 0,
        "total_tokens_used": total_tokens.scalar() or 0,
    }
