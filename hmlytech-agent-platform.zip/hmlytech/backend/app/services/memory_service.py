from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from typing import List, Optional

from app.models.memory import Memory
from app.models.user import User


async def save_message(
    db: AsyncSession,
    user_id: int,
    session_id: str,
    role: str,
    content: str,
    agent_id: Optional[int] = None,
    is_long_term: bool = False,
) -> Memory:
    memory = Memory(
        user_id=user_id,
        agent_id=agent_id,
        session_id=session_id,
        role=role,
        content=content,
        is_long_term=is_long_term,
    )
    db.add(memory)
    await db.flush()
    return memory


async def get_session_history(
    db: AsyncSession,
    session_id: str,
    limit: int = 20,
) -> List[Memory]:
    result = await db.execute(
        select(Memory)
        .where(Memory.session_id == session_id)
        .order_by(Memory.created_at.asc())
        .limit(limit)
    )
    return list(result.scalars().all())


async def get_user_sessions(
    db: AsyncSession,
    user_id: int,
    agent_id: Optional[int] = None,
) -> List[str]:
    query = select(Memory.session_id).where(Memory.user_id == user_id).distinct()
    if agent_id:
        query = query.where(Memory.agent_id == agent_id)

    result = await db.execute(query.order_by(Memory.created_at.desc()).limit(50))
    return [row[0] for row in result.all()]


async def clear_session(db: AsyncSession, session_id: str, user_id: int) -> int:
    result = await db.execute(
        delete(Memory).where(
            Memory.session_id == session_id,
            Memory.user_id == user_id,
            Memory.is_long_term == False,
        )
    )
    return result.rowcount


async def format_history_for_llm(memories: List[Memory]) -> List[dict]:
    return [
        {"role": m.role, "content": m.content}
        for m in memories
        if m.role in ("user", "assistant")
    ]
