import time
import json
import secrets
from typing import AsyncGenerator, List, Dict, Any, Optional
from openai import AsyncOpenAI
import anthropic

from app.core.config import settings
from app.models.agent import Agent, Execution
from app.models.user import User
from app.core.database import AsyncSessionLocal
from app.services.tools_service import execute_tool


openai_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
anthropic_client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY or "dummy")


def is_claude_model(model: str) -> bool:
    return model.startswith("claude")


def build_openai_tools(tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    openai_tools = []
    for tool in tools:
        if tool.get("type") == "http_request":
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": "http_request",
                    "description": "Make an HTTP request to a URL",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "url": {"type": "string", "description": "The URL to request"},
                            "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE"]},
                            "body": {"type": "string", "description": "Request body (JSON)"},
                        },
                        "required": ["url"],
                    },
                },
            })
        elif tool.get("type") == "web_search":
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": "web_search",
                    "description": "Search the web for information",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query"},
                        },
                        "required": ["query"],
                    },
                },
            })
    return openai_tools


async def run_agent(
    agent: Agent,
    user_input: str,
    conversation_history: Optional[List[Dict[str, str]]] = None,
    session_id: Optional[str] = None,
) -> Dict[str, Any]:
    start_time = time.time()
    session_id = session_id or secrets.token_urlsafe(16)
    tool_calls_log = []

    messages = [{"role": "system", "content": agent.system_prompt}]
    if conversation_history:
        messages.extend(conversation_history[-10:])
    messages.append({"role": "user", "content": user_input})

    if is_claude_model(agent.model):
        output, tokens = await _run_claude(agent, messages, tool_calls_log)
    else:
        output, tokens = await _run_openai(agent, messages, tool_calls_log)

    duration_ms = int((time.time() - start_time) * 1000)

    async with AsyncSessionLocal() as db:
        execution = Execution(
            agent_id=agent.id,
            user_id=user.id if hasattr(user, "id") else None,
            input_text=user_input,
            output_text=output,
            tokens_used=tokens,
            duration_ms=duration_ms,
            status="completed",
            tool_calls=tool_calls_log,
            messages=messages,
        )
        db.add(execution)

        agent_obj = await db.get(Agent, agent.id)
        if agent_obj:
            agent_obj.total_runs += 1
            agent_obj.total_tokens_used += tokens

        await db.commit()

    return {
        "output": output,
        "session_id": session_id,
        "tokens_used": tokens,
        "duration_ms": duration_ms,
        "tool_calls": tool_calls_log,
        "model": agent.model,
    }


async def _run_openai(agent: Agent, messages: List[Dict], tool_calls_log: List) -> tuple:
    tools = build_openai_tools(agent.tools or [])
    kwargs = {
        "model": agent.model,
        "messages": messages,
        "temperature": agent.temperature,
        "max_tokens": agent.max_tokens,
    }
    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    response = await openai_client.chat.completions.create(**kwargs)

    total_tokens = response.usage.total_tokens if response.usage else 0
    message = response.choices[0].message

    while message.tool_calls:
        tool_results = []
        for tc in message.tool_calls:
            func_name = tc.function.name
            func_args = json.loads(tc.function.arguments)
            result = await execute_tool(func_name, func_args)
            tool_calls_log.append({"tool": func_name, "args": func_args, "result": result})
            tool_results.append({
                "tool_call_id": tc.id,
                "role": "tool",
                "content": json.dumps(result),
            })

        messages.append(message.model_dump())
        messages.extend(tool_results)

        response = await openai_client.chat.completions.create(**kwargs)
        total_tokens += response.usage.total_tokens if response.usage else 0
        message = response.choices[0].message

    return message.content or "", total_tokens


async def _run_claude(agent: Agent, messages: List[Dict], tool_calls_log: List) -> tuple:
    system_msg = next((m["content"] for m in messages if m["role"] == "system"), "")
    claude_messages = [m for m in messages if m["role"] != "system"]

    response = await anthropic_client.messages.create(
        model=agent.model,
        max_tokens=agent.max_tokens,
        system=system_msg,
        messages=claude_messages,
        temperature=agent.temperature,
    )

    tokens = response.usage.input_tokens + response.usage.output_tokens
    output = ""
    for block in response.content:
        if hasattr(block, "text"):
            output += block.text

    return output, tokens


async def stream_agent(
    agent: Agent,
    user_input: str,
    conversation_history: Optional[List[Dict[str, str]]] = None,
    session_id: Optional[str] = None,
) -> AsyncGenerator[str, None]:
    session_id = session_id or secrets.token_urlsafe(16)

    messages = [{"role": "system", "content": agent.system_prompt}]
    if conversation_history:
        messages.extend(conversation_history[-10:])
    messages.append({"role": "user", "content": user_input})

    if is_claude_model(agent.model):
        async for chunk in _stream_claude(agent, messages):
            yield chunk
    else:
        async for chunk in _stream_openai(agent, messages):
            yield chunk


async def _stream_openai(agent: Agent, messages: List[Dict]) -> AsyncGenerator[str, None]:
    stream = await openai_client.chat.completions.create(
        model=agent.model,
        messages=messages,
        temperature=agent.temperature,
        max_tokens=agent.max_tokens,
        stream=True,
    )

    async for chunk in stream:
        delta = chunk.choices[0].delta if chunk.choices else None
        if delta and delta.content:
            yield f"data: {json.dumps({'chunk': delta.content})}\n\n"

    yield "data: [DONE]\n\n"


async def _stream_claude(agent: Agent, messages: List[Dict]) -> AsyncGenerator[str, None]:
    system_msg = next((m["content"] for m in messages if m["role"] == "system"), "")
    claude_messages = [m for m in messages if m["role"] != "system"]

    async with anthropic_client.messages.stream(
        model=agent.model,
        max_tokens=agent.max_tokens,
        system=system_msg,
        messages=claude_messages,
    ) as stream:
        async for text in stream.text_stream:
            yield f"data: {json.dumps({'chunk': text})}\n\n"

    yield "data: [DONE]\n\n"
