"""
Basic smoke tests for HmlyTech Agent API.
Run with: pytest tests/ -v
"""
import pytest
import asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

from app.main import app
from app.core.database import Base, get_db

TEST_DB_URL = "postgresql+asyncpg://postgres:postgres@localhost:5432/hmlytech_test"

test_engine = create_async_engine(TEST_DB_URL, echo=False)
TestSessionLocal = async_sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)


async def override_get_db():
    async with TestSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session", autouse=True)
async def setup_db():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture
async def client():
    app.dependency_overrides[get_db] = override_get_db
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_health(client):
    res = await client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "healthy"


@pytest.mark.asyncio
async def test_register(client):
    res = await client.post("/api/auth/register", json={
        "email": "test@example.com",
        "username": "testuser",
        "password": "testpass123",
        "full_name": "Test User",
    })
    assert res.status_code == 200
    data = res.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["user"]["email"] == "test@example.com"


@pytest.mark.asyncio
async def test_login(client):
    await client.post("/api/auth/register", json={
        "email": "login@example.com",
        "username": "loginuser",
        "password": "mypassword123",
    })
    res = await client.post("/api/auth/login", json={
        "email": "login@example.com",
        "password": "mypassword123",
    })
    assert res.status_code == 200
    assert "access_token" in res.json()


@pytest.mark.asyncio
async def test_login_wrong_password(client):
    res = await client.post("/api/auth/login", json={
        "email": "login@example.com",
        "password": "wrongpassword",
    })
    assert res.status_code == 401


@pytest.mark.asyncio
async def test_create_agent(client):
    reg = await client.post("/api/auth/register", json={
        "email": "agent@example.com",
        "username": "agentuser",
        "password": "agentpass123",
    })
    token = reg.json()["access_token"]

    res = await client.post("/api/agents", json={
        "name": "Test Agent",
        "system_prompt": "You are a helpful test assistant.",
        "model": "gpt-4o",
        "temperature": 0.7,
        "max_tokens": 1024,
        "is_public": False,
        "tools": [],
        "tags": ["test"],
    }, headers={"Authorization": f"Bearer {token}"})

    assert res.status_code == 201
    data = res.json()
    assert data["name"] == "Test Agent"
    assert data["version"] == 1


@pytest.mark.asyncio
async def test_list_agents(client):
    reg = await client.post("/api/auth/register", json={
        "email": "list@example.com",
        "username": "listuser",
        "password": "listpass123",
    })
    token = reg.json()["access_token"]

    res = await client.get("/api/agents", headers={"Authorization": f"Bearer {token}"})
    assert res.status_code == 200
    assert isinstance(res.json(), list)


@pytest.mark.asyncio
async def test_get_me(client):
    reg = await client.post("/api/auth/register", json={
        "email": "me@example.com",
        "username": "meuser",
        "password": "mepass123",
    })
    token = reg.json()["access_token"]

    res = await client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert res.status_code == 200
    assert res.json()["email"] == "me@example.com"
