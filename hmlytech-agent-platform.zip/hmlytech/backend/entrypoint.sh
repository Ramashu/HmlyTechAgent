#!/bin/bash
set -e

echo "🚀 Starting HmlyTech Agent Backend..."

# Wait for PostgreSQL
echo "⏳ Waiting for database..."
until python -c "
import asyncio, asyncpg, os
async def check():
    url = os.environ.get('DATABASE_URL', '').replace('postgresql+asyncpg://', 'postgresql://')
    conn = await asyncpg.connect(url)
    await conn.close()
asyncio.run(check())
" 2>/dev/null; do
  echo "  PostgreSQL not ready, retrying in 2s..."
  sleep 2
done

echo "✅ Database is ready."

# Run Alembic migrations
echo "🔄 Running database migrations..."
alembic upgrade head

echo "✅ Migrations applied."

# Start the server
echo "▶️  Starting uvicorn..."
exec uvicorn app.main:app \
  --host 0.0.0.0 \
  --port 8000 \
  --workers "${WORKERS:-2}" \
  --loop uvloop \
  --http httptools \
  --log-level "${LOG_LEVEL:-info}"
