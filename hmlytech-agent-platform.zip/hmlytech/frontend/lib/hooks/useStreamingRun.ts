import { useState, useRef, useCallback } from "react";
import Cookies from "js-cookie";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export function useStreamingRun(agentId: number | null) {
  const [output, setOutput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const readerRef = useRef<ReadableStreamDefaultReader | null>(null);

  const run = useCallback(
    async (input: string, sessionId?: string) => {
      if (!agentId) return;

      setOutput("");
      setStreaming(true);
      setError(null);

      const token = Cookies.get("access_token");
      try {
        const res = await fetch(`${API_URL}/api/agent/${agentId}/stream`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ input, session_id: sessionId }),
        });

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const reader = res.body?.getReader();
        if (!reader) throw new Error("No response body");
        readerRef.current = reader;

        const decoder = new TextDecoder();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const text = decoder.decode(value, { stream: true });
          const lines = text.split("\n");
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6).trim();
              if (data === "[DONE]") break;
              try {
                const parsed = JSON.parse(data);
                if (parsed.chunk) setOutput((prev) => prev + parsed.chunk);
              } catch {
                // skip malformed
              }
            }
          }
        }
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : "Streaming failed";
        setError(msg);
      } finally {
        setStreaming(false);
        readerRef.current = null;
      }
    },
    [agentId]
  );

  const abort = useCallback(() => {
    readerRef.current?.cancel();
    setStreaming(false);
  }, []);

  return { output, streaming, error, run, abort };
}
