import { useState, useEffect } from "react";
import { Agent, agentsApi } from "@/lib/api/client";

export function useAgent(id: number | null) {
  const [agent, setAgent] = useState<Agent | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setError(null);
    agentsApi
      .get(id)
      .then((r) => setAgent(r.data))
      .catch(() => setError("Failed to load agent"))
      .finally(() => setLoading(false));
  }, [id]);

  return { agent, loading, error };
}
