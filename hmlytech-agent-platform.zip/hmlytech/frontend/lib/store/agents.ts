import { create } from "zustand";
import { Agent, agentsApi, AgentCreatePayload } from "@/lib/api/client";
import { toast } from "sonner";

interface AgentsState {
  agents: Agent[];
  selectedAgent: Agent | null;
  isLoading: boolean;
  stats: { total_agents: number; total_runs: number; total_tokens_used: number } | null;
  fetchAgents: () => Promise<void>;
  fetchAgent: (id: number) => Promise<Agent | null>;
  createAgent: (data: AgentCreatePayload) => Promise<Agent | null>;
  updateAgent: (id: number, data: Partial<AgentCreatePayload>) => Promise<Agent | null>;
  deleteAgent: (id: number) => Promise<boolean>;
  setSelectedAgent: (agent: Agent | null) => void;
  fetchStats: () => Promise<void>;
}

export const useAgentsStore = create<AgentsState>((set, get) => ({
  agents: [],
  selectedAgent: null,
  isLoading: false,
  stats: null,

  fetchAgents: async () => {
    set({ isLoading: true });
    try {
      const res = await agentsApi.list();
      set({ agents: res.data });
    } catch {
      toast.error("Failed to load agents");
    } finally {
      set({ isLoading: false });
    }
  },

  fetchAgent: async (id) => {
    try {
      const res = await agentsApi.get(id);
      set({ selectedAgent: res.data });
      return res.data;
    } catch {
      toast.error("Agent not found");
      return null;
    }
  },

  createAgent: async (data) => {
    try {
      const res = await agentsApi.create(data);
      set((s) => ({ agents: [res.data, ...s.agents] }));
      toast.success("Agent created successfully");
      return res.data;
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail || "Failed to create agent";
      toast.error(msg);
      return null;
    }
  },

  updateAgent: async (id, data) => {
    try {
      const res = await agentsApi.update(id, data);
      set((s) => ({
        agents: s.agents.map((a) => (a.id === id ? res.data : a)),
        selectedAgent: s.selectedAgent?.id === id ? res.data : s.selectedAgent,
      }));
      toast.success("Agent updated");
      return res.data;
    } catch {
      toast.error("Failed to update agent");
      return null;
    }
  },

  deleteAgent: async (id) => {
    try {
      await agentsApi.delete(id);
      set((s) => ({ agents: s.agents.filter((a) => a.id !== id) }));
      toast.success("Agent deleted");
      return true;
    } catch {
      toast.error("Failed to delete agent");
      return false;
    }
  },

  setSelectedAgent: (agent) => set({ selectedAgent: agent }),

  fetchStats: async () => {
    try {
      const res = await agentsApi.stats();
      set({ stats: res.data });
    } catch {
      // silently fail
    }
  },
}));
