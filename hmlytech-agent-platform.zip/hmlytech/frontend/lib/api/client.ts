import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";
import Cookies from "js-cookie";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = Cookies.get("access_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      const refresh = Cookies.get("refresh_token");
      if (refresh) {
        try {
          const res = await axios.post(`${API_URL}/api/auth/refresh`, { refresh_token: refresh });
          Cookies.set("access_token", res.data.access_token, { expires: 1 });
          Cookies.set("refresh_token", res.data.refresh_token, { expires: 30 });
          if (error.config) {
            error.config.headers.Authorization = `Bearer ${res.data.access_token}`;
            return api(error.config);
          }
        } catch {
          Cookies.remove("access_token");
          Cookies.remove("refresh_token");
          window.location.href = "/login";
        }
      } else {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// Auth
export const authApi = {
  register: (d: { email: string; username: string; password: string; full_name?: string }) =>
    api.post("/auth/register", d),
  login: (d: { email: string; password: string }) => api.post("/auth/login", d),
  refresh: (refresh_token: string) => api.post("/auth/refresh", { refresh_token }),
  me: () => api.get("/auth/me"),
  googleUrl: () => api.get("/auth/google"),
  getApiKey: () => api.get("/auth/api-key"),
  regenerateApiKey: () => api.post("/auth/api-key/regenerate"),
};

// Agents
export const agentsApi = {
  list: (params?: { skip?: number; limit?: number }) => api.get("/agents", { params }),
  get: (id: number) => api.get(`/agents/${id}`),
  create: (d: AgentCreatePayload) => api.post("/agents", d),
  update: (id: number, d: Partial<AgentCreatePayload>) => api.put(`/agents/${id}`, d),
  delete: (id: number) => api.delete(`/agents/${id}`),
  versions: (id: number) => api.get(`/agents/${id}/versions`),
  stats: () => api.get("/agents/stats"),
};

// Execution
export const executionApi = {
  run: (agentId: number, d: RunPayload) => api.post(`/agent/${agentId}/run`, d),
  executions: (agentId: number, limit = 20) =>
    api.get(`/agent/${agentId}/executions`, { params: { limit } }),
};

// Memory
export const memoryApi = {
  sessions: (agentId?: number) => api.get("/memory/sessions", { params: { agent_id: agentId } }),
  session: (sessionId: string) => api.get(`/memory/sessions/${sessionId}`),
  clearSession: (sessionId: string) => api.delete(`/memory/sessions/${sessionId}`),
};

// Tools
export const toolsApi = {
  list: () => api.get("/tools"),
};

export interface AgentCreatePayload {
  name: string;
  description?: string;
  goal?: string;
  system_prompt: string;
  model: string;
  tools: ToolConfig[];
  temperature: number;
  max_tokens: number;
  is_public: boolean;
  tags: string[];
}

export interface ToolConfig {
  type: string;
  name: string;
  description: string;
  config: Record<string, unknown>;
}

export interface RunPayload {
  input: string;
  session_id?: string;
  stream?: boolean;
  conversation_history?: { role: string; content: string }[];
}

export interface Agent {
  id: number;
  owner_id: number;
  name: string;
  description?: string;
  goal?: string;
  system_prompt: string;
  model: string;
  tools: ToolConfig[];
  temperature: number;
  max_tokens: number;
  is_public: boolean;
  is_active: boolean;
  version: number;
  tags: string[];
  total_runs: number;
  total_tokens_used: number;
  created_at: string;
  updated_at?: string;
}

export interface User {
  id: number;
  email: string;
  username: string;
  full_name?: string;
  avatar_url?: string;
  plan: string;
  is_verified: boolean;
  created_at: string;
}
