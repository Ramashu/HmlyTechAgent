import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });
}

export function formatRelativeTime(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function formatNumber(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export const MODEL_LABELS: Record<string, string> = {
  "gpt-4o": "GPT-4o",
  "gpt-4o-mini": "GPT-4o Mini",
  "gpt-4-turbo": "GPT-4 Turbo",
  "gpt-3.5-turbo": "GPT-3.5 Turbo",
  "claude-3-5-sonnet-20241022": "Claude 3.5 Sonnet",
  "claude-3-haiku-20240307": "Claude 3 Haiku",
  "claude-opus-4-5": "Claude Opus 4.5",
};

export const MODEL_PROVIDERS: Record<string, "openai" | "anthropic"> = {
  "gpt-4o": "openai",
  "gpt-4o-mini": "openai",
  "gpt-4-turbo": "openai",
  "gpt-3.5-turbo": "openai",
  "claude-3-5-sonnet-20241022": "anthropic",
  "claude-3-haiku-20240307": "anthropic",
  "claude-opus-4-5": "anthropic",
};

export function truncate(str: string, len = 80) {
  return str.length <= len ? str : str.slice(0, len) + "…";
}

export function generateSessionId() {
  return `sess_${Math.random().toString(36).slice(2)}_${Date.now()}`;
}
