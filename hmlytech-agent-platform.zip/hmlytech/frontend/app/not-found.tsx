import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-bg flex items-center justify-center px-4">
      <div className="text-center animate-fade-in">
        <p className="text-8xl font-display font-bold text-gradient mb-4">404</p>
        <h1 className="font-display font-bold text-2xl mb-2">Page not found</h1>
        <p className="text-text-secondary mb-8">The page you're looking for doesn't exist or has been moved.</p>
        <Link href="/dashboard" className="btn-primary inline-flex">Back to Dashboard</Link>
      </div>
    </div>
  );
}
