"use client";
import Link from "next/link";
import { Zap, Shield, Cpu, ArrowRight, Bot, Globe, Wrench } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-bg overflow-hidden">
      {/* Nav */}
      <nav className="fixed top-0 w-full z-50 border-b border-border/50 bg-bg/80 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center">
              <Bot size={16} className="text-white" />
            </div>
            <span className="font-display font-bold text-lg">HmlyTech</span>
            <span className="badge-purple ml-1">Agent</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="btn-ghost text-sm">Sign in</Link>
            <Link href="/register" className="btn-primary text-sm">Get started <ArrowRight size={14} /></Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-40 pb-24 px-6">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-accent/5 blur-3xl" />
          <div className="absolute top-1/3 right-1/4 w-64 h-64 rounded-full bg-teal-accent/5 blur-3xl" />
        </div>
        <div className="max-w-4xl mx-auto text-center relative">
          <div className="inline-flex items-center gap-2 badge-purple mb-6 text-sm px-3 py-1.5">
            <span className="glow-dot" />
            AI-powered agent platform
          </div>
          <h1 className="font-display font-bold text-5xl md:text-7xl leading-tight mb-6">
            Build AI agents
            <br />
            <span className="text-gradient">that actually work</span>
          </h1>
          <p className="text-text-secondary text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Create, configure and deploy intelligent AI agents with custom tools,
            memory, and streaming responses — all through a modern API.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/register" className="btn-primary px-6 py-3 text-base">
              Start building free <ArrowRight size={16} />
            </Link>
            <Link href="/login" className="btn-secondary px-6 py-3 text-base">
              View demo
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 pb-32">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Bot, title: "Agent Builder", desc: "Design agents with custom system prompts, goals, and model selection. GPT-4o, Claude, and more.", color: "accent" },
            { icon: Wrench, title: "Tool Calling", desc: "Equip agents with HTTP requests, web search, calculator and custom function execution.", color: "teal-accent" },
            { icon: Globe, title: "Deploy as API", desc: "Every agent gets a REST endpoint. Call it from anywhere with your API key.", color: "accent" },
            { icon: Shield, title: "Secure by Default", desc: "JWT authentication, API key management, rate limiting and access controls built in.", color: "teal-accent" },
            { icon: Zap, title: "Streaming Responses", desc: "Real-time token streaming with Server-Sent Events for instant, fluid responses.", color: "accent" },
            { icon: Cpu, title: "Memory & Context", desc: "Short-term conversation history and long-term persistent memory stored in PostgreSQL.", color: "teal-accent" },
          ].map((f) => (
            <div key={f.title} className="card-hover p-6 group animate-fade-in">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${f.color === "accent" ? "bg-accent/15" : "bg-teal-accent/15"}`}>
                <f.icon size={20} className={f.color === "accent" ? "text-accent" : "text-teal-accent"} />
              </div>
              <h3 className="font-display font-semibold text-base mb-2 group-hover:text-accent transition-colors">{f.title}</h3>
              <p className="text-text-secondary text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-text-muted text-sm">
          <span>© 2026 HmlyTech Agent Platform</span>
          <span>Built with Next.js + FastAPI</span>
        </div>
      </footer>
    </div>
  );
}
