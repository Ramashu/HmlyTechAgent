export default function AgentsLoading() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="h-7 w-24 bg-bg-card rounded-lg" />
          <div className="h-4 w-32 bg-bg-card rounded" />
        </div>
        <div className="h-9 w-28 bg-bg-card rounded-lg" />
      </div>
      <div className="h-9 w-72 bg-bg-card rounded-lg" />
      <div className="space-y-2">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="card p-4 flex items-center gap-4">
            <div className="w-10 h-10 bg-bg-hover rounded-xl flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-1/3 bg-bg-hover rounded" />
              <div className="h-3 w-1/2 bg-bg-hover rounded" />
            </div>
            <div className="h-6 w-24 bg-bg-hover rounded-full" />
          </div>
        ))}
      </div>
    </div>
  );
}
