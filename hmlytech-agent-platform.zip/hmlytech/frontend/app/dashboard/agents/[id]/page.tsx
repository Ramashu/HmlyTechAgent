"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, Bot, Zap, Clock, GitBranch, Code2, ExternalLink, Trash2, Save, History } from "lucide-react";
import { useAgentsStore } from "@/lib/store/agents";
import { agentsApi, executionApi } from "@/lib/api/client";
import { formatRelativeTime, MODEL_LABELS } from "@/lib/utils";
import AgentForm from "@/app/components/agent/AgentForm";
import { AgentCreatePayload } from "@/lib/api/client";
import { toast } from "sonner";

type Tab = "overview" | "edit" | "executions" | "api";

export default function AgentDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { selectedAgent, fetchAgent, updateAgent, deleteAgent } = useAgentsStore();
  const [tab, setTab] = useState<Tab>("overview");
  const [executions, setExecutions] = useState<unknown[]>([]);
  const [versions, setVersions] = useState<unknown[]>([]);
  const [loadingExec, setLoadingExec] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    fetchAgent(parseInt(id));
  }, [id, fetchAgent]);

  useEffect(() => {
    if (tab === "executions" && selectedAgent) {
      setLoadingExec(true);
      executionApi.executions(selectedAgent.id).then((r) => {
        setExecutions(r.data);
      }).finally(() => setLoadingExec(false));
    }
    if (tab === "overview" && selectedAgent) {
      agentsApi.versions(selectedAgent.id).then((r) => setVersions(r.data));
    }
  }, [tab, selectedAgent]);

  const handleUpdate = async (data: AgentCreatePayload) => {
    if (!selectedAgent) return;
    setSaving(true);
    await updateAgent(selectedAgent.id, data);
    setSaving(false);
    setTab("overview");
  };

  const handleDelete = async () => {
    if (!selectedAgent || !confirm(`Delete "${selectedAgent.name}"?`)) return;
    setDeleting(true);
    const ok = await deleteAgent(selectedAgent.id);
    if (ok) router.push("/dashboard/agents");
    setDeleting(false);
  };

  const apiUrl = `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/api/agent/${id}/run/public`;

  if (!selectedAgent) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-2 h-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    );
  }

  const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "overview", label: "Overview", icon: Bot },
    { id: "edit", label: "Edit", icon: Save },
    { id: "executions", label: "Runs", icon: Zap },
    { id: "api", label: "API", icon: Code2 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <Link href="/dashboard/agents" className="btn-ghost text-sm mb-4 inline-flex">
          <ChevronLeft size={15} /> Agents
        </Link>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-accent/20 to-teal-accent/10 border border-accent/20 flex items-center justify-center">
              <Bot size={20} className="text-accent" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-bold text-xl">{selectedAgent.name}</h1>
                {selectedAgent.is_public && <span className="badge-teal">Public</span>}
                <span className="badge-gray">v{selectedAgent.version}</span>
              </div>
              <p className="text-text-secondary text-sm">{selectedAgent.description || "No description"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/playground?agent=${selectedAgent.id}`} className="btn-secondary text-sm">
              <ExternalLink size={14} /> Playground
            </Link>
            <button onClick={handleDelete} disabled={deleting} className="btn-danger text-sm">
              {deleting ? <span className="w-3.5 h-3.5 border border-error/40 border-t-error rounded-full animate-spin" /> : <Trash2 size={14} />}
              Delete
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border">
        {TABS.map(({ id: tid, label, icon: Icon }) => (
          <button key={tid} onClick={() => setTab(tid)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px ${
              tab === tid ? "border-accent text-accent" : "border-transparent text-text-secondary hover:text-text-primary"
            }`}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 animate-fade-in">
          <div className="lg:col-span-2 space-y-4">
            <div className="card p-5">
              <h3 className="font-display font-semibold text-sm mb-3 text-text-secondary uppercase tracking-wide">System Prompt</h3>
              <pre className="text-text-primary text-sm font-mono whitespace-pre-wrap leading-relaxed bg-bg-secondary rounded-lg p-4 border border-border max-h-64 overflow-y-auto">
                {selectedAgent.system_prompt}
              </pre>
            </div>
            {selectedAgent.tools?.length > 0 && (
              <div className="card p-5">
                <h3 className="font-display font-semibold text-sm mb-3 text-text-secondary uppercase tracking-wide">Tools</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedAgent.tools.map((t: { type: string; name: string }) => (
                    <span key={t.type} className="badge-purple">{t.name}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="space-y-4">
            <div className="card p-5 space-y-3">
              <h3 className="font-display font-semibold text-sm text-text-secondary uppercase tracking-wide">Stats</h3>
              {[
                { label: "Model", value: MODEL_LABELS[selectedAgent.model] || selectedAgent.model },
                { label: "Total Runs", value: selectedAgent.total_runs },
                { label: "Tokens Used", value: selectedAgent.total_tokens_used.toLocaleString() },
                { label: "Temperature", value: selectedAgent.temperature },
                { label: "Max Tokens", value: selectedAgent.max_tokens },
                { label: "Version", value: `v${selectedAgent.version}` },
                { label: "Created", value: formatRelativeTime(selectedAgent.created_at) },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between text-sm">
                  <span className="text-text-muted">{label}</span>
                  <span className="text-text-primary font-medium">{String(value)}</span>
                </div>
              ))}
            </div>
            {versions.length > 1 && (
              <div className="card p-5">
                <h3 className="font-display font-semibold text-sm mb-3 text-text-secondary uppercase tracking-wide flex items-center gap-2">
                  <History size={13} /> Version History
                </h3>
                <div className="space-y-2">
                  {(versions as Array<{ version: number; model: string; created_at: string }>).slice(0, 5).map((v) => (
                    <div key={v.version} className="flex items-center justify-between text-xs">
                      <span className="badge-gray">v{v.version}</span>
                      <span className="text-text-muted">{MODEL_LABELS[v.model] || v.model}</span>
                      <span className="text-text-muted">{formatRelativeTime(v.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit */}
      {tab === "edit" && (
        <div className="max-w-2xl animate-fade-in">
          <div className="card p-6">
            <AgentForm initial={selectedAgent} onSubmit={handleUpdate} isLoading={saving} submitLabel="Save Changes" />
          </div>
        </div>
      )}

      {/* Executions */}
      {tab === "executions" && (
        <div className="animate-fade-in space-y-3">
          {loadingExec ? (
            <div className="card p-8 text-center text-text-muted text-sm">Loading runs…</div>
          ) : executions.length === 0 ? (
            <div className="card p-12 text-center">
              <Zap size={28} className="text-text-muted mx-auto mb-3" />
              <p className="text-text-secondary">No executions yet. Run this agent from the Playground.</p>
            </div>
          ) : (
            (executions as Array<{ id: number; status: string; input_text: string; output_text: string; tokens_used: number; duration_ms: number; created_at: string }>).map((e) => (
              <div key={e.id} className="card p-4">
                <div className="flex items-center gap-3 mb-3">
                  <span className={`badge ${e.status === "completed" ? "badge-teal" : "bg-error/10 text-error border-error/20"}`}>
                    {e.status}
                  </span>
                  <span className="text-text-muted text-xs">{formatRelativeTime(e.created_at)}</span>
                  <span className="text-text-muted text-xs ml-auto">{e.tokens_used} tokens · {e.duration_ms}ms</span>
                </div>
                <p className="text-text-secondary text-xs mb-2"><span className="text-text-muted">Input: </span>{e.input_text?.slice(0, 120)}{e.input_text?.length > 120 ? "…" : ""}</p>
                <p className="text-text-primary text-xs"><span className="text-text-muted">Output: </span>{e.output_text?.slice(0, 200)}{(e.output_text?.length || 0) > 200 ? "…" : ""}</p>
              </div>
            ))
          )}
        </div>
      )}

      {/* API */}
      {tab === "api" && (
        <div className="max-w-2xl animate-fade-in space-y-5">
          <div className="card p-5">
            <h3 className="font-display font-semibold text-sm mb-1">Endpoint</h3>
            <p className="text-text-muted text-xs mb-3">Make POST requests to run this agent programmatically.</p>
            <div className="bg-bg-secondary border border-border rounded-lg p-3 font-mono text-sm text-teal-accent break-all">
              POST {apiUrl}
            </div>
            <button onClick={() => { navigator.clipboard.writeText(apiUrl); toast.success("Copied!"); }}
              className="btn-ghost text-xs mt-2">Copy URL</button>
          </div>

          <div className="card p-5">
            <h3 className="font-display font-semibold text-sm mb-3">Request Example</h3>
            <pre className="bg-bg-secondary border border-border rounded-lg p-4 text-xs font-mono text-text-secondary overflow-x-auto">{`curl -X POST "${apiUrl}" \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: YOUR_API_KEY" \\
  -d '{
    "input": "Your message here",
    "session_id": "optional-session-id"
  }'`}</pre>
            <button onClick={() => {
              const code = `curl -X POST "${apiUrl}" \\\n  -H "Content-Type: application/json" \\\n  -H "X-API-Key: YOUR_API_KEY" \\\n  -d '{"input": "Your message here"}'`;
              navigator.clipboard.writeText(code);
              toast.success("Copied!");
            }} className="btn-ghost text-xs mt-2">Copy cURL</button>
          </div>

          <div className="card p-5">
            <h3 className="font-display font-semibold text-sm mb-3">Response Schema</h3>
            <pre className="bg-bg-secondary border border-border rounded-lg p-4 text-xs font-mono text-text-secondary overflow-x-auto">{`{
  "output": "Agent response text",
  "agent_id": ${selectedAgent.id},
  "session_id": "sess_abc123",
  "tokens_used": 142,
  "duration_ms": 823,
  "tool_calls": [],
  "model": "${selectedAgent.model}"
}`}</pre>
          </div>

          <div className="card p-5">
            <h3 className="font-display font-semibold text-sm mb-1">Authentication</h3>
            <p className="text-text-muted text-sm">
              Pass your API key as the <code className="text-accent font-mono text-xs bg-accent/10 px-1 rounded">X-API-Key</code> header.
              Get your key from <Link href="/dashboard/settings" className="text-accent hover:underline">Settings</Link>.
              {!selectedAgent.is_public && " This agent is private — only your API key can access it."}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
