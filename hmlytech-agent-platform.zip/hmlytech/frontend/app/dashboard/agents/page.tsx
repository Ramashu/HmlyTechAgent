"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Bot, Plus, Search, Trash2, ExternalLink, Zap, Tag } from "lucide-react";
import { useAgentsStore } from "@/lib/store/agents";
import { formatRelativeTime, MODEL_LABELS, truncate } from "@/lib/utils";
import { Agent } from "@/lib/api/client";

export default function AgentsPage() {
  const { agents, isLoading, fetchAgents, deleteAgent } = useAgentsStore();
  const [search, setSearch] = useState("");
  const [deleting, setDeleting] = useState<number | null>(null);

  useEffect(() => { fetchAgents(); }, [fetchAgents]);

  const filtered = agents.filter(
    (a) =>
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.description?.toLowerCase().includes(search.toLowerCase()) ||
      a.tags?.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  );

  const handleDelete = async (e: React.MouseEvent, agent: Agent) => {
    e.preventDefault();
    if (!confirm(`Delete "${agent.name}"? This cannot be undone.`)) return;
    setDeleting(agent.id);
    await deleteAgent(agent.id);
    setDeleting(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl mb-1">Agents</h1>
          <p className="text-text-secondary text-sm">{agents.length} agent{agents.length !== 1 ? "s" : ""} total</p>
        </div>
        <Link href="/dashboard/agents/new" className="btn-primary">
          <Plus size={15} /> New Agent
        </Link>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, description or tag…"
          className="input pl-9 max-w-md"
        />
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card p-4 animate-pulse">
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-bg-hover" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-bg-hover rounded w-1/4" />
                  <div className="h-3 bg-bg-hover rounded w-1/2" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-14 text-center">
          <div className="w-14 h-14 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mx-auto mb-4">
            <Bot size={24} className="text-accent" />
          </div>
          {search ? (
            <>
              <h3 className="font-semibold mb-1">No results for "{search}"</h3>
              <p className="text-text-muted text-sm">Try a different search term</p>
            </>
          ) : (
            <>
              <h3 className="font-semibold mb-2">No agents yet</h3>
              <p className="text-text-muted text-sm mb-5">Create your first AI agent to start automating tasks</p>
              <Link href="/dashboard/agents/new" className="btn-primary inline-flex">
                <Plus size={15} /> Create first agent
              </Link>
            </>
          )}
        </div>
      ) : (
        <div className="grid gap-3">
          {filtered.map((agent) => (
            <Link key={agent.id} href={`/dashboard/agents/${agent.id}`}
              className="card-hover p-4 flex items-center gap-4 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent/20 to-teal-accent/10 border border-accent/20 flex items-center justify-center flex-shrink-0">
                <Bot size={18} className="text-accent" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="font-medium text-sm group-hover:text-accent transition-colors">{agent.name}</p>
                  {agent.is_public && (
                    <span className="badge-teal text-xs">Public</span>
                  )}
                  <span className="badge-gray text-xs">v{agent.version}</span>
                </div>
                <p className="text-text-muted text-xs truncate mb-1.5">
                  {truncate(agent.description || "No description", 90)}
                </p>
                {agent.tags?.length > 0 && (
                  <div className="flex items-center gap-1">
                    <Tag size={10} className="text-text-muted" />
                    {agent.tags.slice(0, 3).map((t) => (
                      <span key={t} className="badge-gray text-xs">{t}</span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4 text-xs text-text-muted flex-shrink-0">
                <div className="text-right hidden sm:block">
                  <p className="text-text-secondary font-medium">{MODEL_LABELS[agent.model] || agent.model}</p>
                  <p className="text-text-muted">{agent.tools?.length || 0} tools</p>
                </div>
                <div className="text-right hidden md:block">
                  <div className="flex items-center gap-1 text-teal-accent">
                    <Zap size={11} />
                    <span className="font-medium">{agent.total_runs}</span>
                  </div>
                  <p>{formatRelativeTime(agent.created_at)}</p>
                </div>
                <div className="flex items-center gap-1">
                  <Link href={`/dashboard/playground?agent=${agent.id}`}
                    onClick={(e) => e.stopPropagation()}
                    className="p-1.5 rounded-lg hover:bg-teal-accent/10 text-text-muted hover:text-teal-accent transition-colors"
                    title="Open in Playground">
                    <ExternalLink size={14} />
                  </Link>
                  <button
                    onClick={(e) => handleDelete(e, agent)}
                    disabled={deleting === agent.id}
                    className="p-1.5 rounded-lg hover:bg-error/10 text-text-muted hover:text-error transition-colors"
                    title="Delete agent">
                    {deleting === agent.id
                      ? <span className="w-3.5 h-3.5 border border-error/40 border-t-error rounded-full animate-spin block" />
                      : <Trash2 size={14} />}
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
