"use client";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import AgentForm from "@/app/components/agent/AgentForm";
import { useAgentsStore } from "@/lib/store/agents";
import { AgentCreatePayload } from "@/lib/api/client";
import { useState } from "react";

export default function NewAgentPage() {
  const router = useRouter();
  const { createAgent } = useAgentsStore();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (data: AgentCreatePayload) => {
    setLoading(true);
    const agent = await createAgent(data);
    setLoading(false);
    if (agent) router.push(`/dashboard/agents/${agent.id}`);
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <Link href="/dashboard/agents" className="btn-ghost text-sm mb-4 inline-flex">
          <ChevronLeft size={15} /> Back to Agents
        </Link>
        <h1 className="font-display font-bold text-2xl mb-1">Create Agent</h1>
        <p className="text-text-secondary text-sm">Configure a new AI agent with custom prompts and tools.</p>
      </div>

      <div className="card p-6">
        <AgentForm onSubmit={handleSubmit} isLoading={loading} submitLabel="Create Agent" />
      </div>
    </div>
  );
}
