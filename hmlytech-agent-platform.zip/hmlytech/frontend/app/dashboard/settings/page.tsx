"use client";
import { useState, useEffect } from "react";
import { User, Key, RefreshCw, Copy, Check, Shield, LogOut } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { authApi } from "@/lib/api/client";
import { toast } from "sonner";
import { formatDate } from "@/lib/utils";

export default function SettingsPage() {
  const { user, logout, fetchMe } = useAuthStore();
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [loadingKey, setLoadingKey] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showKey, setShowKey] = useState(false);

  useEffect(() => {
    authApi.getApiKey().then((r) => setApiKey(r.data.api_key));
  }, []);

  const regenerateKey = async () => {
    if (!confirm("Regenerate API key? Your existing key will stop working immediately.")) return;
    setLoadingKey(true);
    try {
      const res = await authApi.regenerateApiKey();
      setApiKey(res.data.api_key);
      toast.success("API key regenerated");
    } catch {
      toast.error("Failed to regenerate key");
    } finally {
      setLoadingKey(false);
    }
  };

  const copyKey = () => {
    if (!apiKey) return;
    navigator.clipboard.writeText(apiKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("API key copied");
  };

  const maskedKey = apiKey ? apiKey.slice(0, 8) + "•".repeat(24) + apiKey.slice(-4) : "";

  return (
    <div className="max-w-2xl space-y-8">
      <div>
        <h1 className="font-display font-bold text-2xl mb-1">Settings</h1>
        <p className="text-text-secondary text-sm">Manage your account and API credentials</p>
      </div>

      {/* Profile */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <User size={16} className="text-accent" />
          <h2 className="font-display font-semibold">Profile</h2>
        </div>
        <div className="flex items-center gap-4 mb-5 pb-5 border-b border-border">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent/30 to-teal-accent/20 border border-accent/20 flex items-center justify-center text-xl font-bold text-accent">
            {user?.full_name?.[0] || user?.username?.[0] || "?"}
          </div>
          <div>
            <p className="font-semibold">{user?.full_name || user?.username}</p>
            <p className="text-text-muted text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="badge-purple capitalize">{user?.plan} plan</span>
              {user?.is_verified && <span className="badge-teal">Verified</span>}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          {[
            { label: "Username", value: `@${user?.username}` },
            { label: "Member since", value: user?.created_at ? formatDate(user.created_at) : "—" },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-text-muted text-xs mb-0.5">{label}</p>
              <p className="font-medium">{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* API Key */}
      <div className="card p-6">
        <div className="flex items-center gap-3 mb-2">
          <Key size={16} className="text-accent" />
          <h2 className="font-display font-semibold">API Key</h2>
        </div>
        <p className="text-text-muted text-sm mb-5">
          Use this key to authenticate API requests. Keep it secret — treat it like a password.
        </p>

        <div className="bg-bg-secondary border border-border rounded-xl p-4 mb-4">
          <div className="flex items-center gap-2">
            <code className="flex-1 font-mono text-sm text-teal-accent break-all">
              {showKey ? apiKey : maskedKey}
            </code>
            <button onClick={() => setShowKey(!showKey)}
              className="btn-ghost text-xs px-2 py-1 flex-shrink-0">
              {showKey ? "Hide" : "Show"}
            </button>
            <button onClick={copyKey} className="btn-ghost text-xs px-2 py-1 flex-shrink-0">
              {copied ? <Check size={13} className="text-teal-accent" /> : <Copy size={13} />}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 p-3 bg-warning/5 border border-warning/20 rounded-lg mb-4">
          <Shield size={14} className="text-warning flex-shrink-0" />
          <p className="text-warning text-xs">Never share your API key publicly or commit it to version control.</p>
        </div>

        <button onClick={regenerateKey} disabled={loadingKey} className="btn-secondary text-sm">
          {loadingKey
            ? <span className="w-3.5 h-3.5 border border-accent/40 border-t-accent rounded-full animate-spin" />
            : <RefreshCw size={13} />}
          Regenerate Key
        </button>
      </div>

      {/* Usage */}
      <div className="card p-6">
        <h2 className="font-display font-semibold mb-4">Usage Example</h2>
        <pre className="bg-bg-secondary border border-border rounded-lg p-4 text-xs font-mono text-text-secondary overflow-x-auto">{`# Run any agent via REST API
curl -X POST "https://your-api.com/api/agent/{agent_id}/run/public" \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${showKey && apiKey ? apiKey : "YOUR_API_KEY"}" \\
  -d '{"input": "Hello, agent!"}'`}</pre>
      </div>

      {/* Danger */}
      <div className="card p-6 border-error/20">
        <h2 className="font-display font-semibold mb-4 text-error">Danger Zone</h2>
        <button onClick={logout} className="btn-danger">
          <LogOut size={14} /> Sign Out
        </button>
      </div>
    </div>
  );
}
