"use client";
import { useEffect } from "react";
import Link from "next/link";
import { Bot, Zap, Cpu, ArrowRight, Plus, Activity } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { useAgentsStore } from "@/lib/store/agents";
import { formatRelativeTime, formatNumber, MODEL_LABELS } from "@/lib/utils";

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { agents, stats, fetchAgents, fetchStats } = useAgentsStore();

  useEffect(() => {
    fetchAgents();
    fetchStats();
  }, [fetchAgents, fetchStats]);

  const recentAgents = agents.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl mb-1">
            Welcome back{user?.full_name ? `, ${user.full_name.split(" ")[0]}` : ""}
          </h1>
          <p className="text-text-secondary text-sm">Your AI agent platform overview</p>
        </div>
        <Link href="/dashboard/agents/new" className="btn-primary">
          <Plus size={15} /> New Agent
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Total Agents", value: stats?.total_agents ?? 0, icon: Bot, color: "accent", change: "Active agents" },
          { label: "Total Runs", value: stats?.total_runs ?? 0, icon: Zap, color: "teal-accent", change: "All time executions" },
          { label: "Tokens Used", value: stats?.total_tokens_used ?? 0, icon: Cpu, color: "accent", change: "Cumulative" },
        ].map((s) => (
          <div key={s.label} className="card p-5">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${s.color === "accent" ? "bg-accent/15" : "bg-teal-accent/15"}`}>
                <s.icon size={18} className={s.color === "accent" ? "text-accent" : "text-teal-accent"} />
              </div>
              <Activity size={13} className="text-text-muted" />
            </div>
            <p className="font-display font-bold text-2xl mb-0.5">{formatNumber(s.value)}</p>
            <p className="text-text-muted text-xs">{s.label}</p>
            <p className="text-text-muted text-xs mt-1">{s.change}</p>
          </div>
        ))}
      </div>

      {/* Recent Agents */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-semibold text-base">Recent Agents</h2>
          <Link href="/dashboard/agents" className="text-accent text-sm hover:text-accent-hover flex items-center gap-1 transition-colors">
            View all <ArrowRight size={13} />
          </Link>
        </div>

        {recentAgents.length === 0 ? (
          <div className="card p-12 text-center">
            <div className="w-14 h-14 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mx-auto mb-4">
              <Bot size={24} className="text-accent" />
            </div>
            <h3 className="font-display font-semibold mb-2">No agents yet</h3>
            <p className="text-text-secondary text-sm mb-5">Create your first AI agent to get started</p>
            <Link href="/dashboard/agents/new" className="btn-primary inline-flex">
              <Plus size={15} /> Create agent
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {recentAgents.map((agent) => (
              <Link key={agent.id} href={`/dashboard/agents/${agent.id}`}
                className="card-hover flex items-center gap-4 p-4 group">
                <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-accent/20 to-teal-accent/10 border border-accent/20 flex items-center justify-center flex-shrink-0">
                  <Bot size={16} className="text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm group-hover:text-accent transition-colors">{agent.name}</p>
                  <p className="text-text-muted text-xs truncate">{agent.description || "No description"}</p>
                </div>
                <div className="flex items-center gap-4 text-xs text-text-muted flex-shrink-0">
                  <span className="badge-gray">{MODEL_LABELS[agent.model] || agent.model}</span>
                  <span>{agent.total_runs} runs</span>
                  <span>{formatRelativeTime(agent.created_at)}</span>
                </div>
                <ArrowRight size={14} className="text-text-muted group-hover:text-accent group-hover:translate-x-0.5 transition-all" />
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="font-display font-semibold text-base mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Link href="/dashboard/agents/new" className="card-hover p-4 flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center">
              <Plus size={16} className="text-accent" />
            </div>
            <div>
              <p className="text-sm font-medium group-hover:text-accent transition-colors">Build an Agent</p>
              <p className="text-text-muted text-xs">Configure model, prompt and tools</p>
            </div>
          </Link>
          <Link href="/dashboard/playground" className="card-hover p-4 flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-lg bg-teal-accent/15 flex items-center justify-center">
              <Zap size={16} className="text-teal-accent" />
            </div>
            <div>
              <p className="text-sm font-medium group-hover:text-teal-accent transition-colors">Open Playground</p>
              <p className="text-text-muted text-xs">Chat with any of your agents</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
