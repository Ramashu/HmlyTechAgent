"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import { Send, Bot, User, Zap, RotateCcw, ChevronDown, Loader2, Square } from "lucide-react";
import { useAgentsStore } from "@/lib/store/agents";
import { executionApi } from "@/lib/api/client";
import { generateSessionId, MODEL_LABELS, formatNumber } from "@/lib/utils";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  tokens?: number;
  duration?: number;
  loading?: boolean;
}

export default function PlaygroundPage() {
  const searchParams = useSearchParams();
  const { agents, fetchAgents, selectedAgent, setSelectedAgent, fetchAgent } = useAgentsStore();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sessionId] = useState(generateSessionId);
  const [sending, setSending] = useState(false);
  const [totalTokens, setTotalTokens] = useState(0);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => { fetchAgents(); }, [fetchAgents]);

  useEffect(() => {
    const agentId = searchParams.get("agent");
    if (agentId) fetchAgent(parseInt(agentId));
  }, [searchParams, fetchAgent]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const autoResize = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
  }, []);

  const handleSend = async () => {
    if (!input.trim() || !selectedAgent || sending) return;

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: input.trim(),
    };
    const assistantMsg: Message = {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "",
      loading: true,
    };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setInput("");
    setSending(true);
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    const history = messages
      .filter((m) => !m.loading)
      .map((m) => ({ role: m.role, content: m.content }));

    try {
      const res = await executionApi.run(selectedAgent.id, {
        input: userMsg.content,
        session_id: sessionId,
        conversation_history: history,
      });

      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMsg.id
            ? { ...m, content: res.data.output, loading: false, tokens: res.data.tokens_used, duration: res.data.duration_ms }
            : m
        )
      );
      setTotalTokens((t) => t + (res.data.tokens_used || 0));
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail || "Execution failed";
      toast.error(msg);
      setMessages((prev) => prev.filter((m) => m.id !== assistantMsg.id));
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([]);
    setTotalTokens(0);
    toast.success("Chat cleared");
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] -mt-6 -mx-6 lg:-mt-8 lg:-mx-8">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-5 py-3 border-b border-border bg-bg-secondary flex-shrink-0">
        <div className="flex items-center gap-2 flex-1">
          <Bot size={16} className="text-accent" />
          <span className="font-display font-semibold text-sm">Playground</span>
          {selectedAgent && (
            <>
              <span className="text-text-muted">/</span>
              <span className="text-accent text-sm">{selectedAgent.name}</span>
              <span className="badge-gray text-xs">{MODEL_LABELS[selectedAgent.model] || selectedAgent.model}</span>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          {totalTokens > 0 && (
            <div className="flex items-center gap-1 text-text-muted text-xs">
              <Zap size={11} />
              <span>{formatNumber(totalTokens)} tokens</span>
            </div>
          )}

          {/* Agent selector */}
          <div className="relative">
            <select
              value={selectedAgent?.id || ""}
              onChange={(e) => {
                const agent = agents.find((a) => a.id === parseInt(e.target.value));
                setSelectedAgent(agent || null);
              }}
              className="input text-xs py-1.5 pr-7 appearance-none cursor-pointer min-w-[160px]">
              <option value="">Select agent…</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
            <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
          </div>

          {messages.length > 0 && (
            <button onClick={clearChat} className="btn-ghost text-xs py-1.5 px-2.5">
              <RotateCcw size={12} /> Clear
            </button>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5">
        {!selectedAgent ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center animate-fade-in">
              <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mx-auto mb-4">
                <Bot size={28} className="text-accent" />
              </div>
              <h3 className="font-display font-semibold mb-2">Select an Agent</h3>
              <p className="text-text-muted text-sm">Choose an agent from the dropdown to start chatting</p>
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center animate-fade-in max-w-sm">
              <div className="w-14 h-14 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mx-auto mb-4">
                <Bot size={22} className="text-accent" />
              </div>
              <h3 className="font-display font-semibold mb-1">{selectedAgent.name}</h3>
              <p className="text-text-muted text-sm mb-3">{selectedAgent.description || "Ready to chat"}</p>
              {selectedAgent.goal && (
                <p className="text-text-secondary text-xs bg-bg-secondary rounded-lg p-3 border border-border">
                  <span className="text-text-muted">Goal: </span>{selectedAgent.goal}
                </p>
              )}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className={`flex gap-3 animate-slide-up ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role === "assistant" && (
                <div className="w-8 h-8 rounded-lg bg-accent/15 border border-accent/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Bot size={15} className="text-accent" />
                </div>
              )}

              <div className={`max-w-[75%] ${msg.role === "user" ? "order-first" : ""}`}>
                <div className={`rounded-xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-accent text-white rounded-br-sm"
                    : "bg-bg-card border border-border rounded-bl-sm"
                }`}>
                  {msg.loading ? (
                    <div className="flex items-center gap-2 text-text-muted">
                      <Loader2 size={13} className="animate-spin" />
                      <span className="text-xs">Thinking…</span>
                    </div>
                  ) : msg.role === "assistant" ? (
                    <div className="prose-dark">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  )}
                </div>
                {!msg.loading && msg.tokens && (
                  <p className="text-text-muted text-xs mt-1 px-1">
                    {msg.tokens} tokens · {msg.duration}ms
                  </p>
                )}
              </div>

              {msg.role === "user" && (
                <div className="w-8 h-8 rounded-lg bg-bg-hover border border-border flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User size={14} className="text-text-secondary" />
                </div>
              )}
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t border-border bg-bg-secondary flex-shrink-0">
        <div className="max-w-4xl mx-auto flex gap-3 items-end">
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => { setInput(e.target.value); autoResize(); }}
              onKeyDown={handleKeyDown}
              placeholder={selectedAgent ? `Message ${selectedAgent.name}…` : "Select an agent first…"}
              disabled={!selectedAgent || sending}
              rows={1}
              className="input resize-none pr-3 leading-relaxed w-full"
              style={{ minHeight: "42px", maxHeight: "160px" }}
            />
          </div>
          <button
            onClick={sending ? () => abortRef.current?.abort() : handleSend}
            disabled={!selectedAgent || (!input.trim() && !sending)}
            className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              sending
                ? "bg-error/20 border border-error/30 text-error hover:bg-error/30"
                : "bg-accent hover:bg-accent-hover text-white disabled:opacity-40 disabled:cursor-not-allowed"
            }`}>
            {sending ? <Square size={15} /> : <Send size={15} />}
          </button>
        </div>
        <p className="text-text-muted text-xs text-center mt-2">
          Press <kbd className="font-mono bg-bg-hover border border-border px-1 rounded">Enter</kbd> to send,{" "}
          <kbd className="font-mono bg-bg-hover border border-border px-1 rounded">Shift+Enter</kbd> for newline
        </p>
      </div>
    </div>
  );
}
