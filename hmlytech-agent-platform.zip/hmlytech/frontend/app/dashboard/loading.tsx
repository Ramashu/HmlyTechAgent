export default function Loading() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="h-7 w-48 bg-bg-card rounded-lg" />
          <div className="h-4 w-32 bg-bg-card rounded" />
        </div>
        <div className="h-9 w-28 bg-bg-card rounded-lg" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="card p-5 space-y-3">
            <div className="w-9 h-9 bg-bg-hover rounded-lg" />
            <div className="h-7 w-16 bg-bg-hover rounded" />
            <div className="h-3 w-24 bg-bg-hover rounded" />
          </div>
        ))}
      </div>

      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <div key={i} className="card p-4 flex items-center gap-4">
            <div className="w-9 h-9 bg-bg-hover rounded-xl" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-1/4 bg-bg-hover rounded" />
              <div className="h-3 w-1/2 bg-bg-hover rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
