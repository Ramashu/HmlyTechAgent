"use client";
import { Bot, User, Loader2, Copy, Check } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { useState } from "react";
import { toast } from "sonner";

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
  loading?: boolean;
  tokens?: number;
  duration?: number;
}

export function MessageBubble({ role, content, loading, tokens, duration }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Copied");
  };

  return (
    <div className={`flex gap-3 animate-slide-up ${role === "user" ? "justify-end" : "justify-start"}`}>
      {role === "assistant" && (
        <div className="w-8 h-8 rounded-lg bg-accent/15 border border-accent/20 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot size={15} className="text-accent" />
        </div>
      )}

      <div className={`max-w-[76%] ${role === "user" ? "" : ""}`}>
        <div className={`group relative rounded-xl px-4 py-3 text-sm leading-relaxed ${
          role === "user"
            ? "bg-accent text-white rounded-br-sm"
            : "bg-bg-card border border-border rounded-bl-sm"
        }`}>
          {loading ? (
            <div className="flex items-center gap-2 text-text-muted">
              <Loader2 size={13} className="animate-spin" />
              <span className="text-xs">Thinking…</span>
            </div>
          ) : role === "assistant" ? (
            <>
              <div className="prose-dark">
                <ReactMarkdown>{content}</ReactMarkdown>
              </div>
              <button onClick={copy}
                className="absolute top-2 right-2 p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity hover:bg-bg-hover">
                {copied ? <Check size={11} className="text-teal-accent" /> : <Copy size={11} className="text-text-muted" />}
              </button>
            </>
          ) : (
            <p className="whitespace-pre-wrap">{content}</p>
          )}
        </div>
        {!loading && tokens && (
          <p className="text-text-muted text-xs mt-1 px-1">
            {tokens} tokens · {duration}ms
          </p>
        )}
      </div>

      {role === "user" && (
        <div className="w-8 h-8 rounded-lg bg-bg-hover border border-border flex items-center justify-center flex-shrink-0 mt-0.5">
          <User size={14} className="text-text-secondary" />
        </div>
      )}
    </div>
  );
}
