"use client";
import { cn, MODEL_LABELS, MODEL_PROVIDERS } from "@/lib/utils";

interface ModelSelectorProps {
  value: string;
  onChange: (model: string) => void;
}

export function ModelSelector({ value, onChange }: ModelSelectorProps) {
  const openaiModels = Object.entries(MODEL_LABELS).filter(
    ([k]) => MODEL_PROVIDERS[k] === "openai"
  );
  const anthropicModels = Object.entries(MODEL_LABELS).filter(
    ([k]) => MODEL_PROVIDERS[k] === "anthropic"
  );

  return (
    <div className="space-y-3">
      <div>
        <p className="text-xs text-text-muted uppercase tracking-wide mb-2">OpenAI</p>
        <div className="grid grid-cols-2 gap-2">
          {openaiModels.map(([model, label]) => (
            <button key={model} type="button" onClick={() => onChange(model)}
              className={cn(
                "p-3 rounded-lg border text-left text-sm transition-all",
                value === model
                  ? "border-accent bg-accent/10 text-text-primary"
                  : "border-border bg-bg-secondary hover:border-border-strong text-text-secondary"
              )}>
              <span className="font-medium block text-xs">{label}</span>
              <span className="text-xs opacity-50 font-mono">{model}</span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs text-text-muted uppercase tracking-wide mb-2">Anthropic</p>
        <div className="grid grid-cols-2 gap-2">
          {anthropicModels.map(([model, label]) => (
            <button key={model} type="button" onClick={() => onChange(model)}
              className={cn(
                "p-3 rounded-lg border text-left text-sm transition-all",
                value === model
                  ? "border-teal-accent bg-teal-accent/10 text-text-primary"
                  : "border-border bg-bg-secondary hover:border-border-strong text-text-secondary"
              )}>
              <span className="font-medium block text-xs">{label}</span>
              <span className="text-xs opacity-50 font-mono">{model.slice(0, 24)}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
