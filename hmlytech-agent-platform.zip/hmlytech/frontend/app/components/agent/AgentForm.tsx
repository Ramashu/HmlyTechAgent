"use client";
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Bot, ChevronDown, Plus, X, Wrench, Info, Sliders } from "lucide-react";
import { AgentCreatePayload, Agent } from "@/lib/api/client";
import { cn, MODEL_LABELS } from "@/lib/utils";

const MODELS = Object.entries(MODEL_LABELS);

const TOOL_TYPES = [
  { type: "http_request", name: "HTTP Request", desc: "Call external APIs" },
  { type: "web_search", name: "Web Search", desc: "Search the web" },
  { type: "calculator", name: "Calculator", desc: "Math expressions" },
];

const schema = z.object({
  name: z.string().min(2, "Min 2 characters").max(100),
  description: z.string().optional(),
  goal: z.string().optional(),
  system_prompt: z.string().min(10, "Min 10 characters"),
  model: z.string(),
  temperature: z.number().min(0).max(2),
  max_tokens: z.number().int().min(64).max(16000),
  is_public: z.boolean(),
  tags: z.array(z.string()),
  tools: z.array(z.any()),
});

type FormData = z.infer<typeof schema>;

interface Props {
  initial?: Partial<Agent>;
  onSubmit: (data: AgentCreatePayload) => Promise<void>;
  isLoading?: boolean;
  submitLabel?: string;
}

export default function AgentForm({ initial, onSubmit, isLoading, submitLabel = "Save Agent" }: Props) {
  const [tagInput, setTagInput] = useState("");
  const [tab, setTab] = useState<"basic" | "prompt" | "tools" | "advanced">("basic");

  const { register, handleSubmit, control, watch, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: initial?.name || "",
      description: initial?.description || "",
      goal: initial?.goal || "",
      system_prompt: initial?.system_prompt || "You are a helpful AI assistant. Answer questions clearly and concisely.",
      model: initial?.model || "gpt-4o",
      temperature: initial?.temperature ?? 0.7,
      max_tokens: initial?.max_tokens ?? 2048,
      is_public: initial?.is_public ?? false,
      tags: initial?.tags || [],
      tools: initial?.tools || [],
    },
  });

  const tags = watch("tags");
  const tools = watch("tools");
  const model = watch("model");
  const temperature = watch("temperature");
  const maxTokens = watch("max_tokens");

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !tags.includes(t) && tags.length < 8) {
      setValue("tags", [...tags, t]);
      setTagInput("");
    }
  };

  const removeTag = (t: string) => setValue("tags", tags.filter((x) => x !== t));

  const toggleTool = (toolType: string) => {
    const existing = tools.find((t: { type: string }) => t.type === toolType);
    if (existing) {
      setValue("tools", tools.filter((t: { type: string }) => t.type !== toolType));
    } else {
      const def = TOOL_TYPES.find((t) => t.type === toolType)!;
      setValue("tools", [...tools, { type: def.type, name: def.name, description: def.desc, config: {} }]);
    }
  };

  const TABS = [
    { id: "basic", label: "Basic" },
    { id: "prompt", label: "Prompt" },
    { id: "tools", label: "Tools" },
    { id: "advanced", label: "Advanced" },
  ] as const;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Tab nav */}
      <div className="flex gap-1 p-1 bg-bg-secondary rounded-xl border border-border w-fit">
        {TABS.map((t) => (
          <button key={t.id} type="button" onClick={() => setTab(t.id)}
            className={cn(
              "px-4 py-1.5 rounded-lg text-sm font-medium transition-all",
              tab === t.id ? "bg-bg-card text-text-primary shadow-sm border border-border" : "text-text-secondary hover:text-text-primary"
            )}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Basic */}
      {tab === "basic" && (
        <div className="space-y-4 animate-fade-in">
          <div>
            <label className="label">Agent Name *</label>
            <div className="relative">
              <Bot size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
              <input {...register("name")} placeholder="My Research Agent" className="input pl-9" />
            </div>
            {errors.name && <p className="text-error text-xs mt-1">{errors.name.message}</p>}
          </div>

          <div>
            <label className="label">Description</label>
            <input {...register("description")} placeholder="What does this agent do?" className="input" />
          </div>

          <div>
            <label className="label">Goal</label>
            <textarea {...register("goal")} rows={2}
              placeholder="What should this agent achieve?"
              className="input resize-none" />
          </div>

          <div>
            <label className="label">Model *</label>
            <div className="grid grid-cols-2 gap-2">
              {MODELS.map(([value, label]) => (
                <button key={value} type="button" onClick={() => setValue("model", value)}
                  className={cn(
                    "p-3 rounded-lg border text-left text-sm transition-all",
                    model === value
                      ? "border-accent bg-accent/10 text-text-primary"
                      : "border-border bg-bg-secondary hover:border-border-strong text-text-secondary"
                  )}>
                  <span className="font-medium block">{label}</span>
                  <span className="text-xs opacity-60">{value.startsWith("gpt") ? "OpenAI" : "Anthropic"}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="label">Tags</label>
            <div className="flex gap-2 flex-wrap mb-2">
              {tags.map((t) => (
                <span key={t} className="badge-purple flex items-center gap-1">
                  {t}
                  <button type="button" onClick={() => removeTag(t)}><X size={10} /></button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <input value={tagInput} onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                placeholder="Add tag…" className="input flex-1" />
              <button type="button" onClick={addTag} className="btn-secondary px-3">
                <Plus size={14} />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-bg-secondary rounded-lg border border-border">
            <Controller control={control} name="is_public" render={({ field }) => (
              <button type="button" onClick={() => field.onChange(!field.value)}
                className={cn("w-10 h-5 rounded-full transition-colors relative flex-shrink-0",
                  field.value ? "bg-accent" : "bg-bg-hover border border-border")}>
                <span className={cn("absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow-sm",
                  field.value ? "translate-x-5" : "translate-x-0.5")} />
              </button>
            )} />
            <div>
              <p className="text-sm font-medium">Public Agent</p>
              <p className="text-text-muted text-xs">Anyone with the API endpoint can call this agent</p>
            </div>
          </div>
        </div>
      )}

      {/* Prompt */}
      {tab === "prompt" && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-start gap-2 p-3 bg-accent/5 rounded-lg border border-accent/20 text-sm">
            <Info size={14} className="text-accent mt-0.5 flex-shrink-0" />
            <p className="text-text-secondary">
              The system prompt defines your agent's persona, behavior, and constraints.
              Be specific about tone, format, and what the agent should or shouldn't do.
            </p>
          </div>
          <div>
            <label className="label">System Prompt *</label>
            <textarea {...register("system_prompt")} rows={14}
              placeholder="You are a helpful assistant specialized in..."
              className="input resize-y font-mono text-xs leading-relaxed"
              style={{ minHeight: "260px" }}
            />
            {errors.system_prompt && <p className="text-error text-xs mt-1">{errors.system_prompt.message}</p>}
            <p className="text-text-muted text-xs mt-1.5">
              {watch("system_prompt")?.length || 0} characters
            </p>
          </div>
        </div>
      )}

      {/* Tools */}
      {tab === "tools" && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-start gap-2 p-3 bg-accent/5 rounded-lg border border-accent/20 text-sm">
            <Wrench size={14} className="text-accent mt-0.5 flex-shrink-0" />
            <p className="text-text-secondary">
              Tools extend what your agent can do. When enabled, the agent can call
              these functions during execution.
            </p>
          </div>
          <div className="grid gap-3">
            {TOOL_TYPES.map((tool) => {
              const enabled = tools.some((t: { type: string }) => t.type === tool.type);
              return (
                <div key={tool.type}
                  onClick={() => toggleTool(tool.type)}
                  className={cn(
                    "p-4 rounded-xl border cursor-pointer transition-all",
                    enabled ? "border-accent bg-accent/5" : "card hover:border-border-strong"
                  )}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{tool.name}</p>
                      <p className="text-text-muted text-xs mt-0.5">{tool.desc}</p>
                    </div>
                    <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors",
                      enabled ? "border-accent bg-accent" : "border-border")}>
                      {enabled && <span className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          {tools.length > 0 && (
            <p className="text-teal-accent text-xs">{tools.length} tool{tools.length !== 1 ? "s" : ""} enabled</p>
          )}
        </div>
      )}

      {/* Advanced */}
      {tab === "advanced" && (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-start gap-2 p-3 bg-bg-secondary rounded-lg border border-border text-sm">
            <Sliders size={14} className="text-text-muted mt-0.5 flex-shrink-0" />
            <p className="text-text-secondary">Fine-tune model parameters for this agent's behavior.</p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="label mb-0">Temperature</label>
              <span className="text-accent font-mono text-sm">{temperature}</span>
            </div>
            <Controller control={control} name="temperature" render={({ field }) => (
              <input type="range" min="0" max="2" step="0.05"
                value={field.value} onChange={(e) => field.onChange(parseFloat(e.target.value))}
                className="w-full accent-accent" />
            )} />
            <div className="flex justify-between text-xs text-text-muted mt-1">
              <span>Deterministic (0)</span>
              <span>Creative (2)</span>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="label mb-0">Max Tokens</label>
              <span className="text-accent font-mono text-sm">{maxTokens}</span>
            </div>
            <Controller control={control} name="max_tokens" render={({ field }) => (
              <input type="range" min="64" max="16000" step="64"
                value={field.value} onChange={(e) => field.onChange(parseInt(e.target.value))}
                className="w-full accent-accent" />
            )} />
            <div className="flex justify-between text-xs text-text-muted mt-1">
              <span>64</span>
              <span>16,000</span>
            </div>
          </div>
        </div>
      )}

      {/* Submit */}
      <div className="flex justify-end gap-3 pt-2 border-t border-border">
        <button type="submit" disabled={isLoading} className="btn-primary px-6">
          {isLoading ? (
            <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : submitLabel}
        </button>
      </div>
    </form>
  );
}
