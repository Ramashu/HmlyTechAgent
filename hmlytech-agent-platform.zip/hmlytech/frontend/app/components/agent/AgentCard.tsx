"use client";
import Link from "next/link";
import { Bot, Zap, Wrench, ArrowRight } from "lucide-react";
import { Agent } from "@/lib/api/client";
import { formatRelativeTime, MODEL_LABELS, truncate } from "@/lib/utils";

interface AgentCardProps {
  agent: Agent;
  compact?: boolean;
}

export function AgentCard({ agent, compact }: AgentCardProps) {
  return (
    <Link href={`/dashboard/agents/${agent.id}`}
      className="card-hover p-4 flex flex-col gap-3 group">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-accent/20 to-teal-accent/10 border border-accent/20 flex items-center justify-center flex-shrink-0">
          <Bot size={16} className="text-accent" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm group-hover:text-accent transition-colors leading-tight">
            {agent.name}
          </p>
          {!compact && (
            <p className="text-text-muted text-xs mt-0.5 leading-snug">
              {truncate(agent.description || "No description", 60)}
            </p>
          )}
        </div>
        <ArrowRight size={13} className="text-text-muted group-hover:text-accent group-hover:translate-x-0.5 transition-all flex-shrink-0 mt-0.5" />
      </div>

      {!compact && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="badge-gray text-xs">{MODEL_LABELS[agent.model] || agent.model}</span>
          {agent.tools?.length > 0 && (
            <span className="badge-gray text-xs flex items-center gap-1">
              <Wrench size={9} /> {agent.tools.length}
            </span>
          )}
          {agent.is_public && <span className="badge-teal text-xs">Public</span>}
        </div>
      )}

      <div className="flex items-center justify-between text-xs text-text-muted">
        <div className="flex items-center gap-1">
          <Zap size={10} className="text-teal-accent" />
          <span>{agent.total_runs} runs</span>
        </div>
        <span>{formatRelativeTime(agent.created_at)}</span>
      </div>
    </Link>
  );
}
