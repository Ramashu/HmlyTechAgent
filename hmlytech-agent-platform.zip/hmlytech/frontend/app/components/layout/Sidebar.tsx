"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bot, LayoutDashboard, Cpu, FlaskConical, Settings, LogOut, Key, ChevronRight } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/dashboard/agents", icon: Bot, label: "Agents" },
  { href: "/dashboard/playground", icon: FlaskConical, label: "Playground" },
  { href: "/dashboard/settings", icon: Settings, label: "Settings" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuthStore();

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-bg-secondary border-r border-border flex flex-col z-40">
      {/* Logo */}
      <div className="h-16 flex items-center gap-2.5 px-5 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center flex-shrink-0">
          <Bot size={16} className="text-white" />
        </div>
        <div>
          <span className="font-display font-bold text-sm block leading-none">HmlyTech</span>
          <span className="text-text-muted text-xs">Agent Platform</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV.map(({ href, icon: Icon, label }) => {
          const active = href === "/dashboard" ? pathname === href : pathname.startsWith(href);
          return (
            <Link key={href} href={href}
              className={cn(active ? "sidebar-item-active" : "sidebar-item")}>
              <Icon size={17} />
              <span className="flex-1">{label}</span>
              {active && <ChevronRight size={13} className="opacity-50" />}
            </Link>
          );
        })}
      </nav>

      {/* Status indicator */}
      <div className="px-4 py-3 border-t border-border">
        <div className="flex items-center gap-2 px-2 py-2 rounded-lg bg-teal-accent/5 border border-teal-accent/10 mb-3">
          <span className="glow-dot" />
          <span className="text-teal-accent text-xs font-medium">API Online</span>
        </div>

        {/* User */}
        <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-bg-hover transition-colors cursor-pointer group">
          <div className="w-8 h-8 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center flex-shrink-0 text-accent font-medium text-sm">
            {user?.full_name?.[0] || user?.username?.[0] || "?"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-text-primary text-xs font-medium truncate">{user?.full_name || user?.username}</p>
            <p className="text-text-muted text-xs truncate">{user?.email}</p>
          </div>
          <button onClick={logout} title="Sign out"
            className="opacity-0 group-hover:opacity-100 transition-opacity text-text-muted hover:text-error">
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
}
