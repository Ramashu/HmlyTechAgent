import { cn } from "@/lib/utils";

export function Spinner({ size = "sm", className }: { size?: "xs" | "sm" | "md"; className?: string }) {
  return (
    <span className={cn(
      "inline-block rounded-full border-2 border-accent/30 border-t-accent animate-spin",
      size === "xs" && "w-3 h-3",
      size === "sm" && "w-4 h-4",
      size === "md" && "w-6 h-6",
      className,
    )} />
  );
}
