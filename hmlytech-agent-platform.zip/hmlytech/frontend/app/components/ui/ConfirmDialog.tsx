"use client";
import { Modal } from "./Modal";
import { AlertTriangle } from "lucide-react";

interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  loading?: boolean;
}

export function ConfirmDialog({
  open, onClose, onConfirm, title, description,
  confirmLabel = "Confirm", loading,
}: ConfirmDialogProps) {
  return (
    <Modal open={open} onClose={onClose} size="sm">
      <div className="text-center">
        <div className="w-12 h-12 rounded-2xl bg-error/10 border border-error/20 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle size={20} className="text-error" />
        </div>
        <h3 className="font-display font-semibold mb-2">{title}</h3>
        <p className="text-text-secondary text-sm mb-6">{description}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button onClick={onConfirm} disabled={loading} className="btn-danger flex-1 justify-center">
            {loading
              ? <span className="w-3.5 h-3.5 border border-error/40 border-t-error rounded-full animate-spin" />
              : confirmLabel}
          </button>
        </div>
      </div>
    </Modal>
  );
}
