import { LucideIcon } from "lucide-react";
import Link from "next/link";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: { label: string; href: string };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="card p-14 text-center">
      <div className="w-14 h-14 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mx-auto mb-4">
        <Icon size={24} className="text-accent" />
      </div>
      <h3 className="font-display font-semibold mb-2">{title}</h3>
      <p className="text-text-secondary text-sm mb-5 max-w-xs mx-auto">{description}</p>
      {action && (
        <Link href={action.href} className="btn-primary inline-flex">
          {action.label}
        </Link>
      )}
    </div>
  );
}
