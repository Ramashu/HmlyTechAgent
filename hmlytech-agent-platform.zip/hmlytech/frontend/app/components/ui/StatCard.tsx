import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color?: "accent" | "teal";
  sub?: string;
}

export function StatCard({ label, value, icon: Icon, color = "accent", sub }: StatCardProps) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={cn(
          "w-9 h-9 rounded-lg flex items-center justify-center",
          color === "accent" ? "bg-accent/15" : "bg-teal-accent/15"
        )}>
          <Icon size={18} className={color === "accent" ? "text-accent" : "text-teal-accent"} />
        </div>
      </div>
      <p className="font-display font-bold text-2xl mb-0.5">{value}</p>
      <p className="text-text-secondary text-sm">{label}</p>
      {sub && <p className="text-text-muted text-xs mt-1">{sub}</p>}
    </div>
  );
}
