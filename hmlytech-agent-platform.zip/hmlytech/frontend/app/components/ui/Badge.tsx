import { cn } from "@/lib/utils";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "purple" | "teal" | "gray" | "error" | "warning";
  className?: string;
}

export function Badge({ children, variant = "gray", className }: BadgeProps) {
  return (
    <span className={cn(
      "badge",
      variant === "purple" && "badge-purple",
      variant === "teal" && "badge-teal",
      variant === "gray" && "badge-gray",
      variant === "error" && "bg-error/10 text-error border border-error/20",
      variant === "warning" && "bg-warning/10 text-warning border border-warning/20",
      className,
    )}>
      {children}
    </span>
  );
}
