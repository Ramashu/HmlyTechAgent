"use client";
import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Bot } from "lucide-react";
import { useAuthStore } from "@/lib/store/auth";
import { toast } from "sonner";

export default function AuthCallbackPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { setTokens, fetchMe } = useAuthStore();

  useEffect(() => {
    const access = params.get("access_token");
    const refresh = params.get("refresh_token");

    if (access && refresh) {
      setTokens(access, refresh);
      fetchMe().then(() => {
        toast.success("Signed in with Google!");
        router.replace("/dashboard");
      });
    } else {
      toast.error("Authentication failed");
      router.replace("/login");
    }
  }, [params, setTokens, fetchMe, router]);

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center">
      <div className="text-center animate-fade-in">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent to-teal-accent flex items-center justify-center mx-auto mb-4 animate-glow-pulse">
          <Bot size={28} className="text-white" />
        </div>
        <p className="text-text-secondary">Signing you in…</p>
        <div className="mt-4 flex gap-1 justify-center">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-2 h-2 rounded-full bg-accent animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    </div>
  );
}
