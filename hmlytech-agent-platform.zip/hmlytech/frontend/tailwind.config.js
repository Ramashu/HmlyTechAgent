/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: "#0a0a0f",
          secondary: "#111118",
          tertiary: "#16161f",
          card: "#1a1a24",
          hover: "#1e1e2a",
        },
        border: {
          DEFAULT: "#2a2a38",
          subtle: "#1e1e2c",
          strong: "#3a3a4e",
        },
        accent: {
          DEFAULT: "#6c63ff",
          hover: "#7c74ff",
          muted: "#6c63ff20",
          glow: "#6c63ff40",
        },
        teal: {
          accent: "#00d4aa",
          muted: "#00d4aa20",
        },
        text: {
          primary: "#f0f0f8",
          secondary: "#9898b0",
          muted: "#5a5a72",
          inverse: "#0a0a0f",
        },
        success: "#22c55e",
        warning: "#f59e0b",
        error: "#ef4444",
      },
      fontFamily: {
        sans: ["'DM Sans'", "system-ui", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
        display: ["'Space Grotesk'", "sans-serif"],
      },
      animation: {
        "fade-in": "fadeIn 0.3s ease-in-out",
        "slide-up": "slideUp 0.3s ease-out",
        "slide-in": "slideIn 0.25s ease-out",
        pulse_slow: "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "glow-pulse": "glowPulse 2s ease-in-out infinite",
        shimmer: "shimmer 1.5s infinite",
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: "translateY(10px)" }, to: { opacity: 1, transform: "translateY(0)" } },
        slideIn: { from: { opacity: 0, transform: "translateX(-10px)" }, to: { opacity: 1, transform: "translateX(0)" } },
        glowPulse: { "0%, 100%": { boxShadow: "0 0 5px #6c63ff40" }, "50%": { boxShadow: "0 0 20px #6c63ff80" } },
        shimmer: { from: { backgroundPosition: "-200% 0" }, to: { backgroundPosition: "200% 0" } },
      },
      boxShadow: {
        glow: "0 0 20px #6c63ff30",
        "glow-sm": "0 0 10px #6c63ff20",
        card: "0 4px 24px rgba(0,0,0,0.4)",
      },
    },
  },
  plugins: [],
};
